package edu.mayo.informatics.lexwiki.lexwikitab;

import java.net.URL;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;
import net.sourceforge.jwbf.actions.http.mw.*;

import java.io.*;
import java.util.*;

public class NCBOAnnotatorServiceTesting {
	

  
  public static final String PROD_URL = "http://rest.bioontology.org/obs/annotator?email=example@example.org&#34";

  private static String wiki_url = "http://informatics.mayo.edu/conOpDemo/index.php";
  
  private static String text = "Melanoma is a malignant tumor of melanocytes which are found predominantly in skin but also in the bowel and the eye";
  
  public static void main( String[] args ) {
     System.out.println("********************* NCBO ANNOTATOR CLIENT TEST ************************* \n");
     try {
    	 
			URL url = new URL(wiki_url);
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			//MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "cshare", "xTu$$9");
			wikiBot.login("Admin", "conop");
			Iterator it = wikiBot.readCategory("Category:Testing");
			while(it.hasNext()){
				String articleName = (String) it.next();
				String articleContent = wikiBot.readContentOf(articleName).getText();
				System.out.println(articleContent);
				
			
			
    	 
    	 
       HttpClient client = new HttpClient();
       PostMethod method = new PostMethod(PROD_URL);

       // Configure the form parameters
       method.addParameter("longestOnly", "true");
       method.addParameter("wholeWordOnly", "false");
       method.addParameter("stopWords", "choubala");
       method.addParameter("withDefaultStopWords", "true");
       method.addParameter("scored", "true");
       //method.addParameter("ontologiesToExpand", "38802,13578,NCI,SNOMEDCT");
       method.addParameter("ontologiesToKeepInResult", "NCI");
       method.addParameter("semanticTypes", "T047,T048,T191");
       method.addParameter("semanticTypes", "T060");
       //method.addParameter("levelMax", "50");
       method.addParameter("mappingTypes", "null");
       method.addParameter("textToAnnotate", articleContent);
       method.addParameter("format", "tabDelimited");
       
       // Execute the POST method
        int statusCode = client.executeMethod(method);
         if( statusCode != -1 ) {
           String contents = method.getResponseBodyAsString();
           method.releaseConnection();
           System.out.println(contents);
           String annotations = getUniqueAnnotations(contents);
           SimpleArticle sa = new SimpleArticle();
           sa.setLabel(articleName);
           sa.setText(articleContent + "\n==Annotations==\n" + annotations);
           wikiBot.writeContent(sa);
         }  
     }
     }
     catch( Exception e ) {
       e.printStackTrace();
     }
   }
  
  public static String getUniqueAnnotations(String contents){
	  StringBuffer sb = new StringBuffer();
	  Collection annotations = new ArrayList();
	  String[] rows = contents.split("\\n");
	  for(int i=0; i < rows.length; i++){
		  String[] tokens = rows[i].split("\\t");
		  String annotation = "* [[has annotation::" + tokens[2] + "]]\n";
		  if(!annotations.contains(annotation)){
			  annotations.add(annotation);
			  sb.append(annotation);
		  }
	  }
	  
	  return sb.toString();
  
  }

}