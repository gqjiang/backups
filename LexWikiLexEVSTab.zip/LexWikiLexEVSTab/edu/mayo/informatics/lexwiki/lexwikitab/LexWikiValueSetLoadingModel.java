package edu.mayo.informatics.lexwiki.lexwikitab;

import java.util.*;
import java.sql.*;

public class LexWikiValueSetLoadingModel {

	private Connection con = null;


	public LexWikiValueSetLoadingModel() {

	}
	
	public void updateValueset (
			String prefix, 
			String url, 
			String user, 
			String password,
			Collection Valuesets,
			String source,
			String ns){
		
//		String sqlEntryNS = this.getSQLInsertValue(prefix);
		
		int cur_entryNS = this.getLastestEntryNamespace(prefix, url, user, password);
	    int entry_namespace = cur_entryNS + 2;
	    int entry_ispreferred = 1;	    
		try {
			this.establishConnection(url, user, password);
			
			// for attributes
			Statement stmt = con.createStatement();
			
			
			for(Iterator it = Valuesets.iterator(); it.hasNext();){
			    String valueentry = (String) it.next();
			    String[] pair = valueentry.split("\\|");
			    String entry_code = pair[0];
			    String entry_title = pair[1];
			    
			    String page_title = ns + "_" 
			                      + this.mangle(entry_title) + "("
			                      + this.mangle(entry_code) + ")";
			    
		
			    
			    String entry_source = ns + "_" + source;


			    String sql = this.getSQLInsertValues(prefix, entry_namespace, 
			    		page_title, this.mangle(entry_title), this.mangle(entry_code), entry_source, entry_ispreferred);
			    
			    //System.out.println(sql);
			
			   //stmt.execute(sql);
			   stmt.executeUpdate(sql);
			}

			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}


	public void insertValuesetEntry (
			String prefix, 
			String url, 
			String user, 
			String password,
			String page_title,
			String entry_title,
			String entry_code,
			String entry_source,
			int entry_ispreferred){
		
//		String sqlEntryNS = this.getSQLInsertValue(prefix);
		
		int cur_entryNS = this.getLastestEntryNamespace(prefix, url, user, password);
		int entry_namespace = cur_entryNS + 2;
		
		try {
			this.establishConnection(url, user, password);
			

			
			// for attributes
			Statement stmt = con.createStatement();
			

			String sql = this.getSQLInsertValues(prefix, entry_namespace, 
			    		page_title, entry_title, entry_code, entry_source, entry_ispreferred);
			    
			
			stmt.execute(sql);
			

			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}	
	
	private int getLastestEntryNamespace(
			String prefix, String url, String user, String password) {
		int entryNS = 1000;
		String sqlEntryNS = this.getSQLSelectEntryNamespace(prefix);

		try {
			this.establishConnection(url, user, password);
			// for attributes
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlEntryNS);
			while (rs.next()) {
				entryNS = rs.getInt("entry_namespace");
                break;
			}
			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
		return entryNS;
	}

	private String getSQLSelectEntryNamespace(String prefix) {
		String vsTable = prefix + "lw_valueset";
		String sqlEntryNS = "SELECT entry_namespace FROM " + vsTable
				+ " ORDER BY entry_id DESC LIMIT 1";

		return sqlEntryNS;
	}
	
	private String getSQLInsertValues(String prefix,
			int entry_namespace,
			String page_title,
			String entry_title,
			String entry_code,
			String entry_source,
			int entry_ispreferred){
		String vsTable = prefix + "lw_valueset";
		String sqlInsertValues = "INSERT INTO " + vsTable
              + " (entry_namespace, page_title, entry_title, entry_code, entry_source, entry_ispreferred) VALUES ("
              + entry_namespace + ", " 
              + "\"" + page_title + "\", "
              + "\"" + entry_title + "\", "
              + "\"" + entry_code + "\", "
              + "\"" + entry_source + "\", "
              + entry_ispreferred + ")";

		return sqlInsertValues;
	}	

	private void establishConnection(String url, String user, String password) {
		try {
			Class.forName("org.gjt.mm.mysql.Driver").newInstance();

			con = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void closeConnection() {
		try {
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		//lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		//lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "_");

		// 3) Remove leading and trailing "_"
		//lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");
		
		lwn = lwn.replaceAll("\\[","(");
		lwn = lwn.replaceAll("\\]",")");
		lwn = lwn.replaceAll("<","(");
		lwn = lwn.replaceAll(">",")");
		//lwn = lwn.replaceAll("\\'", "_");
		
		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}
	
	
}
