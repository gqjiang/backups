package edu.mayo.informatics.lexwiki.lexwikitab;

import java.io.*;
import java.util.*;

import edu.mayo.informatics.lexwiki.cadsr.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;



public class CADSRXMLParserTest {
	
	//final String xmlfile = "C:\\cadsr\\cadsr\\bridg21.xml";
	final String xmlfile = "C:\\cadsr\\cadsr_released1.xml";	
	//final String xmlfile = "C:\\cadsr\\ctep_typeofdiseases.xml";	
	//final String xmlfile = "C:\\cadsr\\ctep_typeof_categories.xml";	
	
	final String nci_sty = "C:\\cadsr\\ncisty.txt";
	
	private Frequency freqPrimaryObjectClasses = new Frequency();
	private Frequency freqPrimaryPropertyConcepts = new Frequency();

	private Frequency freqSingleObj = new Frequency();
	private Frequency freqSingleProp = new Frequency();
	private Frequency freqSingle = new Frequency();
	
	private Frequency freqPatternObj = new Frequency();
	private Frequency freqPatternProp = new Frequency();
	private Frequency freqPattern = new Frequency();
	
	private Frequency freqNciSty = new Frequency();
	
	private Map mapObjClses = new HashMap();
	private Map mapPropClses = new HashMap();
	
	
	public void processingCadsrXmlFile(){
		
		Map ncisty = this.getNCISty();
		String outputFileNameSingle = "C:\\cadsr\\cadsr_frequency_single.txt";
		String outputFileNamePattern = "C:\\cadsr\\cadsr_frequency_pattern.txt";

		
		
		try{
		    JAXBContext jc = JAXBContext.newInstance( "edu.mayo.informatics.lexwiki.cadsr" );
		    Unmarshaller u = jc.createUnmarshaller();
		    DataElementsList deList = (DataElementsList)u.unmarshal(new FileInputStream(new File(xmlfile)));
		    List dataElements = deList.getDataElement();
		    int index = 0;
		    for(ListIterator it = dataElements.listIterator(); it.hasNext();){
		    	DataElement dataElement = (DataElement) it.next();
		    	
		    	String longName = dataElement.getLONGNAME();
		    	
		    	//System.out.println(index++ + "|" + dataElement.getPUBLICID());
		    	DATAELEMENTCONCEPT deConcepts = dataElement.getDATAELEMENTCONCEPT();
		    	ObjectClass objClass = deConcepts.getObjectClass();
		    	ConceptDetails objDetails = objClass.getConceptDetails();
		    	List objItems = objDetails.getConceptDetailsITEM();
		    	Collection nonPrimaryObjClses = new ArrayList();
		    	String primaryObjCls = "";
		    	for(ListIterator it1 = objItems.listIterator(); it1.hasNext();){
		    		ConceptDetailsITEM conItem = (ConceptDetailsITEM) it1.next();
		    		String flag = conItem.getPRIMARYFLAGIND();
		    		String conCode = conItem.getPREFERREDNAME();
		    		String conName = conItem.getLONGNAME();
	    			String conCodeName = conCode + "$" + conName;
		    		
		    		if(flag.equals("Yes")){
		    			primaryObjCls = conCodeName;
		    			
		    			//this.freqPrimaryObjectClasses.add(primaryObjCls);
		    			//System.out.println(index++ + "|" + "obj:" + conCode + "$" + conName);
		    		}else{
		    			if(!nonPrimaryObjClses.contains(conCodeName))
		    				nonPrimaryObjClses.add(conCodeName);
		    		}
		    		
		    	}
		    	
		    	if(nonPrimaryObjClses.size() > 1){
		    		addIntoMapContainer(primaryObjCls, nonPrimaryObjClses, mapObjClses);
		    	}
		    	
		    	
		        Property propClass = deConcepts.getProperty();
		        ConceptDetails propDetails = propClass.getConceptDetails();
		        List propItems = propDetails.getConceptDetailsITEM();
		        
		        Collection nonPrimaryPropClses = new ArrayList();
		        String primaryPropCls = "";
		        
		    	for(ListIterator it2 = propItems.listIterator(); it2.hasNext();){
		    		ConceptDetailsITEM conItem = (ConceptDetailsITEM) it2.next();
		    		String flag = conItem.getPRIMARYFLAGIND();
		    		String conCode = conItem.getPREFERREDNAME();
		    		String conName = conItem.getLONGNAME();
		    		String conCodeName = conCode + "$" + conName;
		    		if(flag.equals("Yes")){
		    			primaryPropCls = conCodeName;
		    			//this.freqPrimaryPropertyConcepts.add(primaryPropCls);
		    			//System.out.println("prop:" + conCode + ":" + conName);
		    		}else{
		    			if(!nonPrimaryPropClses.contains(conCodeName))
		    				nonPrimaryPropClses.add(conCodeName);
		    		}
		    		
		    	}	
		    	
		    	if(nonPrimaryPropClses.size() > 1){
		    		addIntoMapContainer(primaryPropCls, nonPrimaryPropClses, mapPropClses);
		    	}
		    	
		    	if(primaryObjCls.length() > 0 && primaryPropCls.length() > 0){
		    		String[] objCodeName = primaryObjCls.split("\\$");
		    		String[] propCodeName = primaryPropCls.split("\\$");
		    		//this.freqPrimaryObjectClasses.add(primaryObjCls);
		    		//this.freqPrimaryPropertyConcepts.add(primaryPropCls);
		    		
		    		String indexSTY = "T032";
		    		
		    		if(this.isSemanticType(indexSTY, objCodeName[0], ncisty)){
		    			StringBuffer sb = new StringBuffer();
		    				    		
		    			sb.append(longName + "|" + objCodeName[0] + "|" + objCodeName[1] + "|" + propCodeName[0] + "|" + propCodeName[1]);
		    			
		    			for(Iterator itnon = nonPrimaryPropClses.iterator(); itnon.hasNext();){
		    				String nonpripropcls = (String)itnon.next();
		    				String[] nonPropCodeName = nonpripropcls.split("\\$");
		    				//sb.append("|" + nonPropCodeName[0] + "|" + nonPropCodeName[1]);	    				
		    			}
		    			
		    			System.out.println(sb.toString());
		    		}
		    		
		    		
		    		//this.countFrequencyNameCodePlus(objCodeName[1], objCodeName[0], propCodeName[1], propCodeName[0], ncisty);
		    		//this.countFrequencyNameCode(objCodeName[1], objCodeName[0], propCodeName[1], propCodeName[0], ncisty);
		    				    		
		    	    index++;
		    	
		    	}
		    	
		    	
		    	
		    }
			//this.printOutFrequency(outputFileNameSingle, freqNciSty, freqSingleObj, freqSingleProp);
		    
			//this.printOutFrequency(outputFileNameSingle, freqSingle, freqSingleObj, freqSingleProp);
			//this.printOutFrequency(outputFileNamePattern, freqPattern, freqPatternObj, freqPatternProp);
			
			
		    //System.out.println("objclass: " + this.freqPrimaryObjectClasses.getTypes());
		    //System.out.println("property: " + this.freqPrimaryPropertyConcepts.getTypes());
		    
		    //System.out.println(index + " Processing done!");
		    
		    
		    
		    

		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		
	}
	
	private void addIntoMapContainer(String primary, Collection nonPrimary, Map map){
		
		if(map.keySet().contains(primary)){
			Collection colNonPrimary = (Collection) map.get(primary);
			for(Iterator it = nonPrimary.iterator(); it.hasNext();){
				String nonPri = (String) it.next();
				if(!colNonPrimary.contains(nonPri)){
					colNonPrimary.add(nonPri);
				}
			}
			map.put(primary, colNonPrimary);
		}else{
			Collection colNonPrimary = new ArrayList();
			for(Iterator it = nonPrimary.iterator(); it.hasNext();){
				String nonPri = (String) it.next();
				if(!colNonPrimary.contains(nonPri)){
					colNonPrimary.add(nonPri);
				}
			}
			map.put(primary, colNonPrimary);
			
		}
		
		
	}
	
	
	public Map getNCISty(){
		
		Map ret = new HashMap();
		BufferedReader br = null;

		try{
			br = new BufferedReader(new FileReader(nci_sty));
			String line = br.readLine();
			while(line != null){
				String[] items = line.split("\\|");
				
				String parentNode = items[3];
				if(items[3].length() > 4){
					parentNode = parentNode.substring(0, 4);
				}
                
				if(!ret.keySet().contains(items[0])){
					Collection colSty = new ArrayList();
					
					
					
					colSty.add(items[2] + " / " + parentNode + "/" + items[3] + " / " + items[4] );
					
					freqNciSty.add(items[2] + " / " + parentNode + "/" + items[3] + " / " + items[4]);
					
					//colSty.add(items[3] + "|" + items[4]);

					ret.put(items[0], colSty);
				}else{
					Collection colSty = (Collection) ret.get(items[0]);
					if(!colSty.contains(items[2])){
						colSty.add(items[2] +  " / " + parentNode + "/" + items[3] + " / " + items[4] );
						freqNciSty.add(items[2] + " / " + parentNode + "/" + items[3] + " / " + items[4]);

						//colSty.add(items[3] + "|" + items[4] );
					}
					ret.put(items[0], colSty);
				}

				
				line = br.readLine();
				
			}
			br.close();

		}catch(IOException ie){
			ie.printStackTrace();
		}		
		
		return ret;
		
	}
	
	
	private void printOutFrequency(String output, Frequency all, Frequency freqobj, Frequency freqprop){
		BufferedWriter bw = null;
		try{
			bw = new BufferedWriter(new FileWriter(output));
			for(Iterator it = all.iterator(); it.hasNext();){
				String sty = (String) it.next();
				int countall = all.getFreq(sty);
				int countobj = freqobj.getFreq(sty);
				int countprop = freqprop.getFreq(sty);
				bw.write(sty + "|" + countall + "|" + countobj + "|" + countprop + "\n");
			}
			
			bw.close();
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	private boolean isSemanticType(String styCode, String clsCode, Map ncisty){
		boolean ret = false;
		
		Collection stys = (Collection) ncisty.get(clsCode);
		if(stys != null){
			for(Iterator it = stys.iterator(); it.hasNext();){
				String sty = (String) it.next();

				String[] styItems = sty.split("\\/");
				if(styItems[0].indexOf(styCode) >= 0) {
					//System.out.println("sty:" + sty);
					ret = true;
					break;
				}
			
			}
		}
		
		
		return ret;
		
	}
	

	private void countFrequencyNameCodePlus(String objClsName, String objCls, String propClsName, String propCls, Map ncisty){
		//Map ncisty = this.getNCISty();
		//String[] objs = objCls.split(":");
		
		StringBuffer sbobjprop = new StringBuffer();
		
		int index = 0;
		
    	StringBuffer sbobj = new StringBuffer();
        //for(int i = 0; i < objs.length; i++){
        	String codeobj = objCls;
        	Collection stysobj = (Collection)ncisty.get(codeobj);
            if(stysobj != null){
        	for(Iterator it1 = stysobj.iterator(); it1.hasNext();){
        		String sty = (String) it1.next();
        		
        		String[] styItems = sty.split("\\/");
         		//if(styItems[0].indexOf("T061") >= 0){ // ||
         				//styItems[0].indexOf("T191") >= 0 ||
         				//styItems[0].indexOf("T101") >= 0 ||
         				//styItems[0].indexOf("T047") >= 0 ||
         				//styItems[0].indexOf("T059") >= 0 ||
         				//styItems[0].indexOf("T167") >= 0 ||
         				//styItems[0].indexOf("T023") >= 0 ||
         				//styItems[0].indexOf("T016") >= 0 ||
         				//styItems[0].indexOf("T060") >= 0 ||
         				//styItems[0].indexOf("T121") >= 0){
         				
            		//freqSingleObj.add(sty + "|" + objCls + "$" + objClsName);
            		//freqSingle.add(sty + "|" + objCls + "$" + objClsName);
        			
         				
         				
         				
         				
         			
                	Collection stysprop = (Collection)ncisty.get(propCls);
                	if(stysprop != null){
                	for(Iterator it2 = stysprop.iterator(); it2.hasNext();){
                		String styProp = (String) it2.next();
                		
                		
         			
       		
                		//freqSingleObj.add(styProp + "|" + propCls + "$" + propClsName + "|" + objCls + "$" + objClsName);
                		//freqSingle.add(styProp + "|" + propCls + "$" + propClsName + "|" + objCls + "$" + objClsName);
                		freqSingleObj.add(styProp + "|" + propCls + "$" + propClsName );
                		freqSingle.add(styProp + "|" + propCls + "$" + propClsName);

                	
                	}
                	}
        			
         		//}
         		
        	
        		
        		if(stysobj.size() == 1){
        		  sbobj.append(sty + "$");
        		  sbobjprop.append(sty + "|" + codeobj + "$" + objClsName + "|");
        		}else{
        			sbobj.append(sty + "$");
        			sbobjprop.append(sty + "&" + codeobj + "$" + objClsName + "&");
        		}
        	}
            }else{
        		//freqSingleObj.add("UNKNOWN|" + propCls + "$" + propClsName + "|" + objCls + "$" + objClsName);
        		//freqSingle.add("UNKNOWN|" + propCls + "$" + propClsName + "|" + objCls + "$" + objClsName);
        		freqSingleObj.add("UNKNOWN|" + propCls + "$" + propClsName);
        		freqSingle.add("UNKNOWN|" + propCls + "$" + propClsName);

        		
        		sbobj.append("UNKNOWN" + "$");
        		sbobjprop.append("UNKNOWN|" + codeobj + "$" + objClsName + "|");

            	//System.out.println(code + "|objcls");
            }
        //}
        //if(sbobj.length() > 1){
        //freqPatternObj.add(sbobj.toString() + "|" + objs.length);
        //freqPattern.add(sbobj.toString() + "|" + objs.length);
        //}
        
        String[] props = propCls.split(":");
        StringBuffer sbprop = new StringBuffer();
        //for(int j = 0; j < props.length; j++){
        	String codeprop = propCls;
        	Collection stysprop = (Collection)ncisty.get(codeprop);
        	if(stysprop != null){
        	for(Iterator it2 = stysprop.iterator(); it2.hasNext();){
        		String sty = (String) it2.next();
                
        			//freqSingleProp.add(sty+ "|" + codeprop+ "$" + propClsName);
        			//freqSingle.add(sty+ "|" + codeprop+ "$" + propClsName);
         		
   
        		
        		if(stysprop.size() == 1){
        		  sbprop.append(sty + "$");
           		  sbobjprop.append(sty + "|" + codeprop+ "$" + propClsName + "|");
           		  
        		
        		}else{
        		  sbprop.append(sty + "$");
           		  sbobjprop.append(sty + "&" + codeprop + "$" + propClsName + "&");
        		  
        		}
        	}
        	}else{

        		//freqSingleProp.add("UNKNOWN"+ "|" + codeprop+ "$" + propClsName);
        		//freqSingle.add("UNKNOWN"+ "|" + codeprop+ "$" + propClsName);
        		sbprop.append("UNKNOWN" + "$");
        		sbobjprop.append("UNKNOWN|" + codeprop + "$" + propClsName + "|");        		
        		//System.out.println(code + "|propcls");
            }
        //}
        if(sbobjprop.length() > 1){
        freqPatternProp.add(sbobjprop.toString());
        freqPattern.add(sbobjprop.toString());
        }

	}	
	
	
	private void countFrequencyNameCode(String objClsName, String objCls, String propClsName, String propCls, Map ncisty){
		//Map ncisty = this.getNCISty();
		//String[] objs = objCls.split(":");
		
		StringBuffer sbobjprop = new StringBuffer();
		
    	StringBuffer sbobj = new StringBuffer();
        //for(int i = 0; i < objs.length; i++){
        	String codeobj = objCls;
        	Collection stysobj = (Collection)ncisty.get(codeobj);
            if(stysobj != null){
        	for(Iterator it1 = stysobj.iterator(); it1.hasNext();){
        		String sty = (String) it1.next();
        		freqSingleObj.add(sty);
        		freqSingle.add(sty);
        		
        		if(stysobj.size() == 1){
        		  sbobj.append(sty + "$");
        		  sbobjprop.append(sty + "|" + codeobj + "$" + objClsName + "|");
        		}else{
        			sbobj.append(sty + "$");
        			sbobjprop.append(sty + "&" + codeobj + "$" + objClsName + "&");
        		}
        	}
            }else{
        		freqSingleObj.add("UNKNOWN");
        		freqSingle.add("UNKNOWN");
        		sbobj.append("UNKNOWN" + "$");
        		sbobjprop.append("UNKNOWN|" + codeobj + "$" + objClsName + "|");

            	//System.out.println(code + "|objcls");
            }
        //}
        //if(sbobj.length() > 1){
        //freqPatternObj.add(sbobj.toString() + "|" + objs.length);
        //freqPattern.add(sbobj.toString() + "|" + objs.length);
        //}
        
        String[] props = propCls.split(":");
        StringBuffer sbprop = new StringBuffer();
        //for(int j = 0; j < props.length; j++){
        	String codeprop = propCls;
        	Collection stysprop = (Collection)ncisty.get(codeprop);
        	if(stysprop != null){
        	for(Iterator it2 = stysprop.iterator(); it2.hasNext();){
        		String sty = (String) it2.next();
        		
        		freqSingleProp.add(sty);
        		freqSingle.add(sty);
        		
        		if(stysprop.size() == 1){
        		  sbprop.append(sty + "$");
           		  sbobjprop.append(sty + "|" + codeprop+ "$" + propClsName + "|");
        		
        		}else{
        		  sbprop.append(sty + "$");
           		  sbobjprop.append(sty + "&" + codeprop + "$" + propClsName + "&");
        		  
        		}
        	}
        	}else{

        		freqSingleProp.add("UNKNOWN");
        		freqSingle.add("UNKNOWN");
        		sbprop.append("UNKNOWN" + "$");
        		sbobjprop.append("UNKNOWN|" + codeprop + "$" + propClsName + "|");        		
        		//System.out.println(code + "|propcls");
            }
        //}
        if(sbobjprop.length() > 1){
        freqPatternProp.add(sbobjprop.toString());
        freqPattern.add(sbobjprop.toString());
        }

	}	
	
	public static void main(String[] args){
		CADSRXMLParserTest parser = new CADSRXMLParserTest();
		parser.processingCadsrXmlFile();
	}

}
