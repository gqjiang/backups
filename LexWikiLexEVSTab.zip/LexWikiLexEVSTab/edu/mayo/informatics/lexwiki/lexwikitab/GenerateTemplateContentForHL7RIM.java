package edu.mayo.informatics.lexwiki.lexwikitab;

import org.LexGrid.codingSchemes.CodingScheme;
import org.LexGrid.commonTypes.Property;
import org.LexGrid.commonTypes.PropertyQualifier;
import org.LexGrid.concepts.*;

import org.LexGrid.naming.SupportedAssociation;
import org.LexGrid.naming.SupportedHierarchy;
import org.LexGrid.naming.SupportedProperty;
import org.LexGrid.valueDomains.ValueDomainDefinition;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.Impl.testUtility.ServiceHolder;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.Extensions.Generic.LexBIGServiceConvenienceMethods;
//import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
//import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
//import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
//import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
//import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;
//import org.lexgrid.extension.valuedomain.LexEVSPickListServices;
//import org.lexgrid.extension.valuedomain.LexEVSValueDomainServices;
//import org.lexgrid.extension.valuedomain.impl.LexEVSPickListServicesImpl;
//import org.lexgrid.extension.valuedomain.impl.LexEVSValueDomainServicesImpl;

import edu.stanford.smi.protege.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;


//first implementation of new lexwiki templates
public class GenerateTemplateContentForHL7RIM {
	
	//private LexBIGService lbsm_ = null;
	//private LexEVSValueDomainServices vds_;
	//private LexEVSPickListServices pls_;
	
	private Map superClasses = new HashMap();
	private Collection propertyNames = new ArrayList();
	private KnowledgeBase kb = null;
	
	public GenerateTemplateContentForHL7RIM() {

	}

	public Map getSuperClasses() {
		return superClasses;
	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();
			

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();

			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				String version = csrs[i].getCodingSchemeSummary().getRepresentsVersion();
				vecCodeSystems.add(localName + "|" + version);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {
			
			//ValueDomainDefinition vdd = new ValueDomainDefinition();
			
			
			//getValueDomainService().

			LexBIGService lbs = new LexBIGServiceImpl();
			
			

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURI(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURI(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}
	
	

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				
				
				
				String code = ref.getConceptCode();
				
				String description = ref.getEntityDescription().getContent();
				
				if(isDataType(ref)){
				
					ret.add(code + "|" + description);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}
	
	private void printResults(String fileName, Collection results){
		BufferedWriter bw = null;
		try{
			bw = new BufferedWriter(new FileWriter(fileName));
			for(Iterator it = results.iterator(); it.hasNext();){
				String entry = (String) it.next();
				bw.write(entry + "\n");
			}
			bw.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	private Collection getSubsetCodes(String fileName){
		Collection ret = new ArrayList();
		BufferedReader br = null;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while(line != null){
				ret.add(line.trim());
				line = br.readLine();
			}
			
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}
	
	private Collection results = new ArrayList();

	private boolean isSource(ResolvedConceptReference entry, Collection subset) {
		boolean ret = false;
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getReferencedEntry().getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getReferencedEntry().getPresentation(ip);
			if(pres.getSourceCount() > 0){
			if(pres.getSource(0).getContent().indexOf("NCI") >=0){
				int pqc = pres.getPropertyQualifierCount();
				for(int i = 0; i < pqc; i++){
					PropertyQualifier pq = (PropertyQualifier)pres.getPropertyQualifier(i);
					
					if(pq.getPropertyQualifierName().indexOf("source-code") >= 0){
						String sourcecode = pq.getValue().getContent();
						if(subset.contains(sourcecode)){
							results.add(sourcecode + "|" + 
									entry.getCode() + "|" + entry.getEntityDescription().getContent());
							
							break;
						}
					}
				}
			}
			}
		}

		return ret;

	}	
	
	public Collection getAllConceptCodesForSource(String localName) {
        
		String input1 = "/home/m005994/ncisubset.txt";
		String output1 = "/home/m005994/ncioutput.txt";
		String input2 = "/home/m005994/icd10subset.txt";
		String output2 = "/home/m005994/icd10output.txt";
		String input3 = "/home/m005994/mdrsubset.txt";
		String output4 = "/home/m005994/mdroutput.txt";
		
		Collection ret = new ArrayList();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				
				
				
				String code = ref.getConceptCode();
				
				String description = ref.getEntityDescription().getContent();
				
				Collection subset = this.getSubsetCodes(input1);
				if(this.isSource(ref, subset)){
					System.out.println(code + "|" + description);
				}
				
				//if(isDataType(ref)){
				
					//ret.add(code + "|" + description);
				//}
			}
			
			this.printResults(output1, results);
			ret = results;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}	
	
	public Collection getAllConceptCodesValuesets(String localName) {

		Collection ret = new ArrayList();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				
				
				
				String code = ref.getConceptCode();
				
				String description = ref.getEntityDescription().getContent();
				
				//if(isDataType(ref)){
				
					ret.add(code + "|" + description);
				//}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}
	public Object[] getAllRootNodes(String localName) {
		Vector ret = new Vector();

		String codingScheme = "";
		LexBIGServiceConvenienceMethods lbscm = null;		
		
		try {

			LexBIGService lbs = new LexBIGServiceImpl();
			
			lbscm = (LexBIGServiceConvenienceMethods) lbs.getGenericExtension("LexBIGServiceConvenienceMethods");
			

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					CodingSchemeSummary css = csrs[i].getCodingSchemeSummary();
					String urn = css.getCodingSchemeURI();
					String version = css.getRepresentsVersion();
					CodingSchemeVersionOrTag csVorT =
						Constructors.createCodingSchemeVersionOrTagFromVersion(version);
					CodingScheme cs = lbs.resolveCodingScheme(urn, csVorT);
					
					ResolvedConceptReferenceList refList = lbscm.getHierarchyRoots(localName, csVorT, null);					
                    
					Iterator rcrIt = refList.iterateResolvedConceptReference();
					while (rcrIt.hasNext()) {
						ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
								.next();
						
						
						
						String code = ref.getConceptCode();
						
						String description = ref.getEntityDescription().getContent();

						
						ret.add(code + "|" + description);

						
						

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}		
	
	public Object[] getAllConceptCodesForRootBranch(String localName, String rootName, int maxDepth) {
		Vector ret = new Vector();

		String codingScheme = "";
		LexBIGServiceConvenienceMethods lbscm = null;	
		
		String[] rootPair = rootName.split("\\|");
		
		try {

			LexBIGService lbs = new LexBIGServiceImpl();
			
			lbscm = (LexBIGServiceConvenienceMethods) lbs.getGenericExtension("LexBIGServiceConvenienceMethods");
			

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			
			String hierarchyID = this.getSupportedHierarchyForCodingScheme(localName);

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					CodingSchemeSummary css = csrs[i].getCodingSchemeSummary();
					String urn = css.getCodingSchemeURI();
					String version = css.getRepresentsVersion();
					CodingSchemeVersionOrTag csVorT =
						Constructors.createCodingSchemeVersionOrTagFromVersion(version);
					CodingScheme cs = lbs.resolveCodingScheme(urn, csVorT);
					
					ResolvedConceptReferenceList refList = lbscm.getHierarchyRoots(localName, csVorT, null);					
                    Iterator rcrIt = refList.iterateResolvedConceptReference();
					while (rcrIt.hasNext()) {
						ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
								.next();
						
						
						
						String code = ref.getConceptCode();
						
						String description = ref.getEntityDescription().getContent();

						
						//ret.add(code + "|" + description);
						if(code.equals(rootPair[0])){
							this.printHierarchyBranch(lbscm, localName, csVorT, hierarchyID, ref, 1, maxDepth, null, ret);
						    break;
						}
						
						

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}	
	
	
    public void printHierarchyBranch(LexBIGServiceConvenienceMethods lbscm, String scheme,
            CodingSchemeVersionOrTag csvt, String hierarchyID, ResolvedConceptReference branchRoot, int currentDepth,
            int maxDepth, String assocName, Vector allConcepts) throws LBException {
    	
    	//Vector ret = new Vector();

        String code = branchRoot.getConceptCode();
        String desc = branchRoot.getEntityDescription().getContent();
        allConcepts.add(code + "|" + desc);
        // Print each association and recurse ...
        if (currentDepth < maxDepth) {
            AssociationList assocList = lbscm.getHierarchyLevelNext(scheme, csvt, hierarchyID, code, false, null);
            if (assocList != null)
                for (int i = 0; i < assocList.getAssociationCount(); i++) {
                    Association assoc = assocList.getAssociation(i);
                    AssociatedConceptList nodes = assoc.getAssociatedConcepts();
                    for (Iterator<AssociatedConcept> subsumed = nodes.iterateAssociatedConcept(); subsumed.hasNext();) {
                        printHierarchyBranch(lbscm, scheme, csvt, hierarchyID, subsumed.next(), currentDepth + 1,
                                maxDepth, assoc.getDirectionalName(), allConcepts);
                    }
                }
        }
    }	
	
	
	
	//this should be called before any loading
	public Collection getPropertyNames(){
		Collection ret = new ArrayList();
		for(Iterator it = propertyNames.iterator(); it.hasNext();){
			String propertyName = (String)it.next();
			String label = "Property:" + propertyName;
			String text = "[[has type::Type:String]]";
			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(label);
			sa.setText(text);
			ret.add(sa);
		}
		
		return ret;
	}



	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				//CodedEntry entry = ref.getReferencedEntry();

				String code = ref.getConceptCode();

				if (code.equals(code_)) {
										

					sb.append(this.getHeaderBasicData());
					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(ref));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(ref));

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(ref));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(ref, ns));

					sb.append(this.getCodedEntryURI(ref, localName));
					
					sb.append(this.getTrailerBasicData());

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(ref, ns));

					// sb.append("== Comment ==\n");
					//sb.append(this.getCodedEntryComment(entry));

				
					
					sb.append(this.getTrailerProperties());

					
					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));

					
					sb.append(this.getTrailerAssoications());

					//sb.append(this.getHeaderAssociationsGraph());

					//sb.append("== Associations Graph ==\n");
					//sb.append(this.getCodedEntryAssociationsGraph(ref,
					//		localName, ns));

                    //sb.append(this.getTrailerAssociationsGraph());
					
					sb.append(this.getDefaultForm(ns));

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public Collection getContentForCodeSet(Collection codeSet,
			String localName, String ns) {
		
		Collection codeSetContents = new ArrayList();

		
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				//CodedEntry entry = ref.getReferencedEntry();
				String code = ref.getConceptCode();
				String description = ref.getEntityDescription().getContent();

				if (codeSet.contains(code)) {
					StringBuffer sb = new StringBuffer();
					SimpleArticle sa = new SimpleArticle();
					sa.setLabel("Category:" + ns + " " + description +
							"(" + code + ")");
					

					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(ref));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(ref));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(ref));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(ref, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(ref, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(ref));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm(ns));

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));
					
					sa.setText(sb.toString());
					codeSetContents.add(sa);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codeSetContents;
	}	
	
	public String getContentForDebug(String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				//CodedEntry entry = ref.getReferencedEntry();
				String code = ref.getConceptCode();

				String description = ref.getEntityDescription().getContent();
				sb.append(this.getCodedEntryAssociations(ref, localName, ns));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();

	}

    public String getAllRootNodesWithoutPAR(String localName,
			String ns){
    	StringBuffer sb = new StringBuffer();
    	
		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				//CodedEntry entry = ref.getReferencedEntry();
				String code = ref.getConceptCode();

				String description = ref.getEntityDescription().getContent();
                String conceptLabel = "Category:" + this.mangle(ns + " " + description) + "(" + this.mangle(code)
				+ ")";
                
                if(this.isRootNode(ref, localName, ns)){
				   sb.append(code + "|" + description + "\n");

                }



			}

		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	
    	return sb.toString();
    }

	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {


		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				//CodedEntry entry = ref.getReferencedEntry();
				String code = ref.getConceptCode();

				String description = ref.getEntityDescription().getContent();
                String conceptLabel = "Category:" + this.mangle(ns + " " + description) + "(" + this.mangle(code)
				+ ")";
                
                if(this.isDataType(ref)){
				
				System.out.println(conceptLabel);
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel(conceptLabel);

				
				StringBuffer sb = new StringBuffer();
				sb.append(this.getHeaderBasicData());
				// sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(ref));

				// sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(ref));

				// sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName));

				// sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(ref));

				// sb.append("== Presentations ==\n");
				sb.append(this.getCodedEntryPresentations(ref, ns));

				sb.append(this.getCodedEntryURI(ref, localName));
				
				sb.append(this.getTrailerBasicData());

				sb.append(this.getHeaderProperties());

				// sb.append("== Concept Property ==\n");
				sb.append(this.getCodedEntryConceptProperty(ref, ns));

				// sb.append("== Comment ==\n");
				//sb.append(this.getCodedEntryComment(entry));

			
				
				sb.append(this.getTrailerProperties());

				
				sb.append(this.getHeaderAssoications());

				// sb.append("== Associations ==\n");

				sb.append(this.getCodedEntryAssociations(ref,
							localName, ns));

				
				sb.append(this.getTrailerAssoications());

				//sb.append(this.getHeaderAssociationsGraph());

				//sb.append("== Associations Graph ==\n");
				//sb.append(this.getCodedEntryAssociationsGraph(ref,
				//		localName, ns));

                //sb.append(this.getTrailerAssociationsGraph());
				
				sb.append(this.getDefaultForm(ns));

				sb.append(this.getCodedEntryIncludeOnly(ref,
								localName, ns));


				sa.setText(sb.toString());
				allContents.add(sa);
                }



			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURI();
					
					break;
				}
			}

			sb.append("{{LexWiki inScheme|" + codingScheme
					+ "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	
	private String getCodingSchemeName(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURI();
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codingScheme;
	}
	
	
	public Collection getSupportedPropertiesForCodingScheme(String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		Collection ret = new ArrayList();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					CodingSchemeSummary css = csrs[i].getCodingSchemeSummary();
					String urn = css.getCodingSchemeURI();
					String version = css.getRepresentsVersion();
					CodingSchemeVersionOrTag csVorT =
						Constructors.createCodingSchemeVersionOrTagFromVersion(version);
					CodingScheme cs = lbs.resolveCodingScheme(urn, csVorT);
					SupportedProperty[] properties = cs.getMappings().getSupportedProperty();
					
					for(int j = 0; j < properties.length; j++){
						SupportedProperty property = properties[j];
						//SimpleArticle sa = new SimpleArticle();
						//sa.setLabel(ns + "_" + property.getContent());
						//sa.setText("[[has type::Type:String]]");
						//ret.add(sa);
						String propertyName = property.getLocalId();
						ret.add(propertyName);
					}
					
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	public Collection getSupportedAssociationsForCodingScheme(String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		Collection ret = new ArrayList();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					CodingSchemeSummary css = csrs[i].getCodingSchemeSummary();
					String urn = css.getCodingSchemeURI();
					String version = css.getRepresentsVersion();
					CodingSchemeVersionOrTag csVorT =
						Constructors.createCodingSchemeVersionOrTagFromVersion(version);
					CodingScheme cs = lbs.resolveCodingScheme(urn, csVorT);
					SupportedAssociation[] associations = cs.getMappings().getSupportedAssociation();
					
					for(int j = 0; j < associations.length; j++){
						SupportedAssociation property = associations[j];
						//SimpleArticle sa = new SimpleArticle();
						//sa.setLabel(ns + "_" + property.getContent());
						//sa.setText("[[has type::Type:Page]]");
						//ret.add(sa);
						String propertyName = property.getLocalId();
						ret.add(propertyName);
					}
					
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}	

	private String getSupportedHierarchyForCodingScheme(String localName) {
		//StringBuffer sb = new StringBuffer();
		//Collection ret = new ArrayList();
		String ret = "";
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					CodingSchemeSummary css = csrs[i].getCodingSchemeSummary();
					String urn = css.getCodingSchemeURI();
					String version = css.getRepresentsVersion();
					CodingSchemeVersionOrTag csVorT =
						Constructors.createCodingSchemeVersionOrTagFromVersion(version);
					CodingScheme cs = lbs.resolveCodingScheme(urn, csVorT);
					SupportedHierarchy[] hierarchies = cs.getMappings().getSupportedHierarchy();
					
					//for(int j = 0; j < hierarchies.length; j++){
					SupportedHierarchy property = hierarchies[0];
					//ret = property.getContent();
					ret = property.getAssociationNames(0);
					
					System.out.println("isaName:" + ret);
						//SimpleArticle sa = new SimpleArticle();
						//sa.setLabel(ns + "_" + property.getContent());
						//sa.setText("[[has type::Type:String]]");
						//ret.add(sa);
					//}
					
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}	
	
	private String getDefaultForm(String ns) {
		return "<noinclude>[[has default form::Form:LexWiki " + ns + " Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "<noinclude>{{LexWiki Basic Data Header}}</noinclude>\n";
	}
	private String getTrailerBasicData() {
		return "<noinclude>{{LexWiki Basic Data Trailer}}</noinclude>\n";
	}
	private String getHeaderProperties() {
		return "{{LexWiki Concept Property Header}}</noinclude>\n";
	}
	private String getTrailerProperties() {
		return "<noinclude>{{LexWiki Concept Property Trailer}}</noinclude>\n";
	}
	private String getHeaderAssoications() {
		return "<noinclude>{{LexWiki Association Header}}</noinclude>\n";
	}
	private String getTrailerAssoications() {
		return "<noinclude>{{LexWiki Association Trailer}}</noinclude>\n";
	}
	
	private String getHeaderReferences() {
		return "<noinclude>{{LexWiki Reference Header}}</noinclude>\n";
	}
	private String getTrailerReferences() {
		return "<noinclude>{{LexWiki Reference Trailer}}</noinclude>\n";
	}	
	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}
	private String getTrailerAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Trailer}}</noinclude>\n";
	}
	

	
	private String getCodedEntryCode(ResolvedConceptReference entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		code = this.mangle(code);
		sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryDescription(ResolvedConceptReference entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		description = this.mangle(description);
		sb.append("{{LexWiki Preferred Name|"
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryURI(ResolvedConceptReference entry, String localName) {
		StringBuffer sb = new StringBuffer();
		String scheme = this.getCodingSchemeName(localName);
		String code = entry.getConceptCode();
		code = this.mangle(code);
		sb.append("{{LexWiki URI|"
				+ scheme + ":" + code + "}}\n");
		return sb.toString();

	}	
	
	private String getCodedEntryDefinition(ResolvedConceptReference entry) {
		StringBuffer sb = new StringBuffer();

		int dIndex = entry.getReferencedEntry().getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			if(ii==0){
			sb.append("{{LexWiki Definition|"
					+ entry.getReferencedEntry().getDefinition(ii).getValue().getContent() + "}}\n");
			}else{
				sb.append("{{LexWiki AltDefinition|"
						+ entry.getReferencedEntry().getDefinition(ii).getValue().getContent() + "}}\n");
				
			}
		}

		return sb.toString();

	}

	private String getCodedEntryPresentations(ResolvedConceptReference entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getReferencedEntry().getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getReferencedEntry().getPresentation(ip);
			String propName = pres.getPropertyName();
			String nsPropName = ns + "_" + propName;
			if(!propertyNames.contains(nsPropName))
			    propertyNames.add(nsPropName);
			String text = pres.getValue().getContent();
			text = this.mangle(text);
			//text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			
			if(propName.indexOf("definition") >= 0){
				
				sb.append("{{LexWiki Definition|"
						+ text + "}}\n");
				
			}else{
			
			//if (isPref) {
				// String attrName = "Has Preferred " + propName;
				//sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
						//+ "}}\n");
			//} else {
				// String fidelity = pres.getDegreeOfFidelity();
				// String attrName = "Has " + fidelity + " "
				// + propName;
				sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
						+ text + "}}\n");
			}
		}

		return sb.toString();

	}
	
	private boolean isDataType(ResolvedConceptReference entry) {
		boolean ret = false;
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getReferencedEntry().getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getReferencedEntry().getPresentation(ip);
			if(pres.getSourceCount() > 0){
			if(pres.getSource(0).getContent().indexOf("DataType") >=0){
				ret = true;
				break;
			}
			}
		}

		return ret;

	}	

	private String getCodedEntryConceptProperty(ResolvedConceptReference entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getReferencedEntry().getPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			Property cp = entry.getReferencedEntry().getProperty(cpi);
			String cpName = ns + "_" + cp.getPropertyName();

			if(!propertyNames.contains(cpName))
			    propertyNames.add(cpName);
			
			String cpText = cp.getValue().getContent();
			sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
					+ "}}\n");
		}

		return sb.toString();
	}

	private String getCodedEntryComment(ResolvedConceptReference entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getReferencedEntry().getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|"
					+ entry.getReferencedEntry().getComment(j).getValue().getContent() + "}}\n");
		}

		return sb.toString();
	}

    private boolean isRootNode(ResolvedConceptReference ref,
			String localName, String ns){
    	boolean ret = false;
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURI()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				String hier = this.getSupportedHierarchyForCodingScheme(localName);
				
				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						//System.out.println("sourceOf-assName:" + assName);
					if(assName.equals("PAR")){
						isaIndex++;
						break;
					}
														 
							
					}
				}
			}

				if (isaIndex == 0) {
                   ret = true;
                   System.out.println("Root Node:" + ref.getCode() + "|" + ref.getEntityDescription().getContent());
				}

			

		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	
    	return ret;
    }

	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURI()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				String hier = this.getSupportedHierarchyForCodingScheme(localName);
				
				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						//if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if(ass.getDirectionalName() != null){
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("sourceOf-assDirecName:" + assDirectionalName);

						// do not need hasSubtype
						//if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
/*				
							 sb .append("{{LexWiki Association|" + ns + "_" +
							     assDirectionalName + "|" + ns + " " + this.mangle(assConcept
							     .getEntityDescription() .getContent()) + "(" +
							     assConcept.getConceptCode() + ")}}\n");
*/
														
								if (assDirectionalName.equals("hasSubtype")) {
									isaIndex++;
									
									//sb.append("<noinclude>{{LexWiki Parent|"
									//		+ ns
									//		+ " "
									//		+ this.mangle(assConcept.getEntityDescription()
									//				.getContent()) + "("
									//		+ this.mangle(assConcept.getConceptCode())
									//		+ ")}}</noinclude>\n");
	/*								
									sb.append("<noinclude>[[Category:"
											+ ns
											+ " "
											+ assConcept.getEntityDescription()
													.getContent() + "("
											+ assConcept.getConceptCode()
											+ ")]]</noinclude>\n");
	*/
								}else{
									 sb .append("{{LexWiki Association|" + ns + "_" +
										     assDirectionalName + "|" + ns + " " + this.mangle(assConcept
										     .getEntityDescription() .getContent()) + "(" +
										     this.mangle(assConcept.getConceptCode()) + ")}}\n");
									
								}
						}
														 
							
					}
				}
				 //}
				//}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);
						
						//if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:" + assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
/*
							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assDirectionalName
									+ "|"
									+ ns
									+ " "
									+ this.mangle(assConcept.getEntityDescription().getContent()) + "("
									+ assConcept.getConceptCode() + ")}}\n");

							
*/
							if (assDirectionalName.indexOf("hasSubtype") >= 0) {
								isaIndex++;
								
								sb.append("<noinclude>{{LexWiki Parent|"
										+ ns
										+ " "
										+ this.mangle(assConcept.getEntityDescription()
												.getContent()) + "("
										+ this.mangle(assConcept.getConceptCode())
										+ ")}}</noinclude>\n");
/*
								
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
*/
							
							
						}else{
								sb.append("<noinclude>{{LexWiki Inverse Association|"
										+ ns
										+ "_"
										+ assDirectionalName
										+ "|"
										+ ns
										+ "_"
										+ this.mangle(assConcept.getEntityDescription().getContent()) + "("
										+ this.mangle(assConcept.getConceptCode()) + ")}}</noinclude>\n");
								
							}

						}
						}
					}
				}
			//}



				if (isaIndex == 0) {
					sb.append("<noinclude>{{LexWiki Parent|" + localName
							+ "}}</noinclude>\n");

/*					
					sb.append("<noinclude>[[Category:" + localName
							+ "]]</noinclude>\n");
*/
				}

			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");
		

		String thisConcept = "Category:" + ns + "_" + thisConceptName + "("
				+ ref.getConceptCode() + ")";
		
		thisConcept = this.mangle(thisConcept);

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURI()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						//if (!assName.equals("hasSubtype")) {
						String assDirectionalName = assName;
						if(ass.getDirectionalName() != null){
							assDirectionalName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");
							thisAssEntityDescription = this.mangle(thisAssEntityDescription);
							
							sb.append("[ " + thisConcept + "] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
							   assDirectionalName + " --> {link:Relation:" +
							   ns + "_" + assDirectionalName + "; start: front, 0; } " + " [ Category:" + thisAssEntityDescription + "(" +
							   assConcept.getConceptCode() + ") ] " + "{ fill:3; link: Category:" + thisAssEntityDescription +
							   "(" + assConcept.getConceptCode() + "); }" +
							   "\n");
							 
						}

					}
				//}
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDirectionalName = assName;
						if(ass.getDirectionalName() != null){
							assDirectionalName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription().getContent().replaceAll(" ", "_");
							thisAssEntityDescription = this.mangle(thisAssEntityDescription);

/*							
						
							sb.append("[ " + thisConcept + "] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assDirectionalName
									+ " --> {link:Relation:" + ns + "_"
									+ assDirectionalName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");
*/
						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + " " + thisConceptName + "("
				+ ref.getConceptCode() + ")";
		
		thisConcept = this.mangle(thisConcept);

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}
	

	private String getLexWikiNameForConceptCode(String conceptCode,
			String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { conceptCode },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				//CodedEntry entry = ref.getReferencedEntry();

				String code = ref.getConceptCode();

				if (code.equals(conceptCode)) {
					String description = ref.getEntityDescription().getContent();
	                String conceptLabel = this.mangle(ns + " " + description) + "(" + code
					+ ")";
	                conceptLabel = this.mangle(conceptLabel);
	                sb.append(conceptLabel);
	                break;
					
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return sb.toString();
   }

	

		
	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		//lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		//lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "_");

		// 3) Remove leading and trailing "_"
		//lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");
		
		lwn = lwn.replaceAll("\\[","(");
		lwn = lwn.replaceAll("\\]",")");
		lwn = lwn.replaceAll("<","(");
		lwn = lwn.replaceAll(">",")");
		
		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}

	/*
	private LexBIGService getLexBIGService() {
		if (lbsm_ == null) {
			ServiceHolder.configureForSingleConfig();
			lbsm_ = ServiceHolder.instance().getLexBIGService();
		}

		return lbsm_;
	}
		
	private LexEVSValueDomainServices getValueDomainService(){
		if (vds_ == null) {
			vds_ = new LexEVSValueDomainServicesImpl();
		}
		return vds_;
	}
	

	private LexEVSPickListServices getPickListService(){
		if (pls_ == null) {
			pls_ = new LexEVSPickListServicesImpl();
		}
		return pls_;
	}	

*/
}
