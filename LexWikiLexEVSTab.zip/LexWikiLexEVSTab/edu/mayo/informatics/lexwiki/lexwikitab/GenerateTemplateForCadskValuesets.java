package edu.mayo.informatics.lexwiki.lexwikitab;


import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;
import java.net.URL;

import au.com.bytecode.opencsv.CSVReader;


public class GenerateTemplateForCadskValuesets {
	
	private final String fileName = "C:\\Temp\\cadsr\\cadsr_cde_lesion.csv"; 
	
	//private String urlstr = "http://bmidev3/cshare/index.php";
	private String urlstr = "http://informatics.mayo.edu/ndrc/index.php";
	private String userName = "Guoqian";
	private String password = "guoqian0331";
	
	private Collection colDataSetPages = new ArrayList(); 
	
	public void publishDataElementsToWiki(){
		Collection des = this.processingDataElements();


		try{
			URL url = new URL(urlstr);
			//MediaWikiBot wikiBot = new MediaWikiBot(url);
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "cshare", "xTu$$9");
			wikiBot.login(userName, password);
			wikiBot.writeMultContent(des.iterator());
			System.out.println("publishing done: " + des.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
        
	}
	

	public Collection processingDataElements(){
		
		Collection ret = new ArrayList();
		BufferedReader br = null;

		try{
			//br = new BufferedReader(new FileReader(fileName));
			CSVReader reader = new CSVReader(new FileReader(fileName));
			//String line = br.readLine();
			
			String[] names = reader.readNext();
			
			String[] nextline = reader.readNext();
			
			int index = 0;
			Map desMap = new HashMap();
			String codelist_temp = "";
			String vdcontext_temp = "";
			
			while(nextline != null){
				Map deMap = new HashMap();
				
				if(nextline.length > 1){
					String[] items = nextline;
					if(items.length > 50){
					if(items[0].length() > 0){
					//String source = "CADSR";
					String source = items[5];

					String domain = "Oncology";
					String dataset = "Lesion Measurement";
					String shortname = items[0];
					shortname = shortname.replaceAll(":", "_");
					String longname = items[1];
					String defintion = items[3];
					String datatype = "ANY";
					String unit = "NO_UNITS_SPECIFIED";
					String codelist = items[42];
					
					String objClses = items[20];
					String propClses = items[31];
					
					String vdContext = items[44];
					String vdType = items[46];
					if(vdType.equals("Non Enumerated")){
						codelist = "UNSPECIFIED";
					}
					
					codelist_temp = codelist;
					vdcontext_temp = vdContext;
					
					String vdDatatype = items[47];
					
					String validValue = items[71];
					String valueText = items[72];
					String valueDescription = items[73];
					String valueCode = items[74];
					

					if(!codelist.equals("UNSPECIFIED")){
						StringBuffer sb = new StringBuffer();
						String page = vdContext + " " + codelist + " Value Set";
						String subpage = validValue;
						sb.append(this.getPermissibleValue(page, subpage));
						sb.append(this.getPermissibleValueText(valueText, valueDescription, "", valueCode));
						sb.append(this.getPermissibleValueEnd());
						
						SimpleArticle savs = new SimpleArticle();
						
						//dataset added in page name
						savs.setLabel(vdContext + " " + codelist + " Value Set/" + subpage );
						savs.setText(sb.toString());
						ret.add(savs);
					}
					
					
						
						
					}else{
						String validValue = items[71];
						String valueText = items[72];
						String valueDescription = items[73];
						String valueCode = items[74];
						if(!codelist_temp.equals("UNSPECIFIED") && validValue.length() > 0){
							StringBuffer sb = new StringBuffer();
							String page = vdcontext_temp + " " + codelist_temp + " Value Set";
							String subpage = validValue;
							sb.append(this.getPermissibleValue(page, subpage));
							sb.append(this.getPermissibleValueText(valueText, valueDescription, "", valueCode));
							sb.append(this.getPermissibleValueEnd());
							
							SimpleArticle savs = new SimpleArticle();
							
							//dataset added in page name
							savs.setLabel(vdcontext_temp + " " + codelist_temp + " Value Set/" + subpage );
							savs.setText(sb.toString());
							ret.add(savs);
						}						
					}
					

				}
					
	            
				}
				
			    index++;
			    //if(index > 20) break;
				nextline = reader.readNext();

			}
			//br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}
	
	
	private String getPermissibleValue(String page, String subpage){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE Permissible Value|page=" + page + "|subpage=" + subpage + "}}\n");
		return sb.toString();
	}

	private String getPermissibleValueText(String text, String description, 
			String codesystem, String code){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE Permissible Value Text|value_meaning=" + text + 
				"|value_description=" + description + "|code_system=NCI|concept_code=" + code  + "}}\n");
		return sb.toString();
	}	
	
	private String getPermissibleValueEnd(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_Permissible_Value_End}}\n");
		return sb.toString();
	}	
	
	
	private void addDataSetPage(String source, String dataset){
		SimpleArticle sa = new SimpleArticle();
		sa.setLabel("Category:" + source + "_" + dataset);
		sa.setText("[[Category:CSHARE_" + dataset + "]]\n");
		if(!this.colDataSetPages.contains(sa)){
			this.colDataSetPages.add(sa);
		}
		SimpleArticle sa_de = new SimpleArticle();
		sa_de.setLabel("Category:" + source + "_Data_Element");
		sa_de.setText("[[Category:CSHARE_Data_Element]]\n");
		if(!this.colDataSetPages.contains(sa_de)){
			this.colDataSetPages.add(sa_de);
		}		
	}
	
	private String getDataElementFilterSourceDataset(String source, String dataset){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementFilterForSourceAndDataset|1=" +  source + 
				"|2=Oncology_" +  dataset + "}}\n");
		
		return sb.toString();
	}
	
	private String getLongName(String text, String supertext){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementLongName|1=" + text + "|2=" + supertext + "}}\n");
		return sb.toString();
	}
	
	private String getShortName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementShortName|1=" + text + "}}\n");
		return sb.toString();
	}

	private String getDataType(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDataType|1=DT_" + text + "}}\n");
		return sb.toString();
	}
	
	private String getUnit(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementUnit|1=" + text + "}}\n");
		return sb.toString();
	}	
	
	private String getDefinition(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDefinition|1=" + text + "}}\n");
		return sb.toString();
	}	

	private String getSourceName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementSourceName|1=" + text + "}}\n");
		return sb.toString();
	}		

	private String getDatasetName(String text, String domain, String cadsr){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDatasetName|1=" + text + 
				"|2=" + domain + "|3=" + cadsr +
		     "}}\n");
		return sb.toString();
	}		
/*	
	private String getDomainName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDomainName|1=" + text + "}}\n");
		return sb.toString();
	}
*/
	private String getDEDetailsHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDetailsHeader}}\n");
		return sb.toString();
	}	
	
	private String getDEDetailsTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDetailsTrailer}}\n");
		return sb.toString();
	}			
	
	private String getDEValuesetHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetHeader}}\n");
		return sb.toString();
	}			

	private String getDEValueset(String text, String source){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetBody|1=" + source + " " + text + " Value Set}}\n");
		return sb.toString();
	}			
	
	private String getDEValuesetTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetTrailer}}\n");
		return sb.toString();
	}			

	private String getDEConceptReferenceHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceHeader}}\n");
		return sb.toString();
	}		

	private String getDEConceptReference(String clses, String flag){
		String[] items = clses.split(":");
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < items.length; i++){
			String cls = items[i];
			sb.append("{{CSHARE_DataElementConceptReferenceBody|1=" + cls + "|2=" + flag +  "}}\n");
			
		}
		return sb.toString();
	}		
	
	private String getDEConceptReferenceTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceTrailer}}\n");
		return sb.toString();
	}			
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenerateTemplateForCadskValuesets model =
			new GenerateTemplateForCadskValuesets();
		model.publishDataElementsToWiki();
		//model.publishDataElementFiltersToWiki();

	}

}
