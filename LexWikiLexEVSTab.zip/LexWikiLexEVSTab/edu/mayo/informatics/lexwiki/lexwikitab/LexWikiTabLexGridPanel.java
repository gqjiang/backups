package edu.mayo.informatics.lexwiki.lexwikitab;


import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protegex.owl.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;
import java.net.MalformedURLException;
import java.net.URL;

//import conexp.core.*;
//import conexp.frontend.*;
//import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
//import edu.mayo.bmi.guoqian.fca.sct.*;

import org.LexGrid.LexBIG.DataModel.Collections.CodingSchemeRenderingList;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Impl.LexBIGServiceImpl;
import org.LexGrid.LexBIG.LexBIGService.*;

public class LexWikiTabLexGridPanel extends JPanel implements
		ActionListener {

	private KnowledgeBase kb;

	private JPanel leftPanel;

	private JPanel rightPanel;

	private JSplitPane mainPane;

	private JLabel urlLabel;

	private JTextField jtfURL;

	private JLabel unLabel;

	private JTextField jtfUserName;

	private JLabel pwLabel;

	private JPasswordField jtfPassWord;

	private JButton btnCreateContent;

	private JButton btnGenerateTemplateContent;

	private JButton btnReadFromWiki;

	private JButton btnDetectChanges;

	private JLabel jlUrl;

	private JLabel jlUser;

	private JLabel jlPassword;

	private JLabel jlPrefix;

	private JTextField jtfUrl;

	private JTextField jtfUser;

	private JPasswordField jpfPassword;

	private JTextField jtfPrefix;

	private JLabel labelCodeSystems;

	private JComboBox jcbCodeSystems;
	
	private JPanel rootNodesPanel;
	
	private JLabel labelRootNodes;
	
	private JComboBox jcbRootNodes;
	
	private JSpinner spinner;

	private JLabel labelNameSpaces;

	private JComboBox jcbNameSpaces;

	private JList listConcepts;

	private JScrollPane listScrollPane;

	private JButton btnGetCodeSet;
	
	private JButton btnGetRootNodes;

	private JTextField jtfCodeSetFromFile;

	private JButton btnCodeSetFromFile;

	private JLabel labelRDFUrl;

	private JTextField jtfRDFUrl;

	private JButton btnRDFParsing;

	private String defaultURL;

	private JTextArea textArea;

	private JScrollPane scrollPane;

	private JLabel contentLabel;

	private JButton btnExport;

	private JButton btnBatchExport;

	private JButton btnBatchExportForTemplateContent;

	private JButton btnSave;

	
	//private GenerateTemplateContentsForNPO model =
		//new GenerateTemplateContentsForNPO();
	

	private GenerateTemplateContentForHL7RIM model =
		new GenerateTemplateContentForHL7RIM();
	
	
	final String[] namespaces = { "NONE", "ICD11", "NPO", "HL7",  "ICD10", "ICD10Index", "ICD10AM", "ICD10CM",
			"ICECI", "Orphanet", "ICDO", "ICD9CM", "MT", "MU", "ICF", "NCI", "SN", "SCT",
			"SNOMEDCT", "ICD9", "ICD9d", "ICD9ei", "ICD9i", "ICD9n" };

	public LexWikiTabLexGridPanel(KnowledgeBase kb) {
		this.kb = kb;
		this.initUI();

	}

	private void initUI() {
		leftPanel = new JPanel(new BorderLayout());
		rightPanel = new JPanel(new BorderLayout());

		listConcepts = new JList();
		listConcepts
				.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		//listConcepts.addListSelectionListener(new ListSelectionChanged());

		listScrollPane = new JScrollPane(listConcepts);
		listScrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		// clsesPanel = new ClsesPanel(kb.getProject());
		leftPanel.add(listScrollPane, BorderLayout.CENTER);

		JPanel urlPanel = new JPanel();
		urlLabel = new JLabel("Wiki URL: ");
		jtfURL = new JTextField(40);
		// jtfURL.setText("http://wiktolog.com/index.php");
		jtfURL.setText("http://bmidev.mayo.edu/lexwiki/index.php");
		urlPanel.add(urlLabel);
		urlPanel.add(jtfURL);

		JPanel unPanel = new JPanel();
		unLabel = new JLabel("Login name: ");
		jtfUserName = new JTextField(10);
		jtfUserName.setText("LexWikiAdmin");
		unPanel.add(unLabel);
		unPanel.add(jtfUserName);

		JPanel pwPanel = new JPanel();
		pwLabel = new JLabel("Password: ");
		jtfPassWord = new JPasswordField(10);
		jtfPassWord.setText("lexlex");
		pwPanel.add(pwLabel);
		pwPanel.add(jtfPassWord);

		// JLabel projLabel = new JLabel("Project: ");

		JPanel codeSystemsPanel = new JPanel();
		labelCodeSystems = new JLabel("Availabe Code Systems");
		String[] tempCodes = { "UMLS SemNet", "NCI_Thesaurus" };
		jcbCodeSystems = new JComboBox(this.getAvailableCodeSystems());
		jcbCodeSystems.addActionListener(this);
		codeSystemsPanel.add(labelCodeSystems);
		codeSystemsPanel.add(jcbCodeSystems);
		btnGetRootNodes = new JButton("Get Root Nodes...");
		btnGetRootNodes.addActionListener(this);
		codeSystemsPanel.add(btnGetRootNodes);
		
	    rootNodesPanel = new JPanel();
		labelRootNodes = new JLabel ("Root Nodes");
		jcbRootNodes = new JComboBox();
		jcbRootNodes.addActionListener(this);
		spinner = new JSpinner();
		spinner.setValue(new Integer(1));
		btnGetCodeSet = new JButton("Get Code Set...");
		btnGetCodeSet.addActionListener(this);
		rootNodesPanel.add(labelRootNodes);
		rootNodesPanel.add(jcbRootNodes);
		rootNodesPanel.add(spinner);
		rootNodesPanel.add(btnGetCodeSet);
		

		JPanel unpwPanel = new JPanel(new GridLayout(1, 2));
		unpwPanel.add(unPanel);
		unpwPanel.add(pwPanel);

		JPanel upperPanel = new JPanel(new GridLayout(4, 1));
		upperPanel.add(urlPanel);
		upperPanel.add(unpwPanel);
		upperPanel.add(codeSystemsPanel);
		upperPanel.add(rootNodesPanel);

		leftPanel.add(upperPanel, BorderLayout.NORTH);

		JPanel btnPanel = new JPanel(new GridLayout(4, 1));

		JPanel nsPanel = new JPanel();
		labelNameSpaces = new JLabel("Namespace: ");
		jcbNameSpaces = new JComboBox(this.namespaces);
		jcbNameSpaces.addActionListener(this);
		nsPanel.add(labelNameSpaces);
		nsPanel.add(jcbNameSpaces);

		JPanel btnCreatePanel = new JPanel();
		btnCreatePanel.add(nsPanel);

		btnCreateContent = new JButton("Generate Wikitext...");
		btnCreateContent.addActionListener(this);
		btnCreatePanel.add(btnCreateContent);

		// JPanel btnGeneratePanel = new JPanel();
		btnGenerateTemplateContent = new JButton("Generate Template...");
		btnGenerateTemplateContent.addActionListener(this);
		btnCreatePanel.add(btnGenerateTemplateContent);

		JPanel btnReadPanel = new JPanel();
		// btnReadFromWiki = new JButton("Read from Wiki...");
		// btnReadFromWiki.addActionListener(this);
		// btnReadPanel.add(btnReadFromWiki);

		jlUrl = new JLabel("dburl:");
		jlPrefix = new JLabel("dbprefix:");
		jlUser = new JLabel("dbuser:");
		jlPassword = new JLabel("dbpassword:");

		jtfUrl = new JTextField(20);
		jtfUrl.setText("jdbc:mysql://bmidev.mayo.edu/lexwikidb");
		jtfPrefix = new JTextField(4);
		jtfPrefix.setText("lw_");
		jtfUser = new JTextField(10);
		jtfUser.setText("lexwikiuser");
		jpfPassword = new JPasswordField(10);
		jpfPassword.setText("lexlex");

		JPanel jpUrl = new JPanel();
		jpUrl.add(jlUrl);
		jpUrl.add(jtfUrl);
		jpUrl.add(jlPrefix);
		jpUrl.add(jtfPrefix);

		JPanel jpUser = new JPanel();
		jpUser.add(jlUser);
		jpUser.add(jtfUser);
		jpUser.add(jlPassword);
		jpUser.add(jpfPassword);

		btnDetectChanges = new JButton("Load Valuset...");
		btnDetectChanges.addActionListener(this);
		btnReadPanel.add(btnDetectChanges);

		btnPanel.add(btnCreatePanel);
		btnPanel.add(jpUrl);
		btnPanel.add(jpUser);
		// btnPanel.add(btnGeneratePanel);
		btnPanel.add(btnReadPanel);
		// btnPanel.add(btnExportPanel);

		leftPanel.add(btnPanel, BorderLayout.SOUTH);

		JPanel rightCodeSetPanel = new JPanel();
		JLabel labelCodeSet = new JLabel("    File: ");
		jtfCodeSetFromFile = new JTextField(40);

		String icdfilename = "C:\\whoproject\\icd10index.csv";
		jtfCodeSetFromFile.setText(icdfilename);

		JPanel btnCodeSetFromFilePanel = new JPanel();
		btnCodeSetFromFile = new JButton("Add CodeSet...");
		btnCodeSetFromFile.addActionListener(this);
		btnCodeSetFromFilePanel.add(btnCodeSetFromFile);

		rightCodeSetPanel.add(labelCodeSet);
		rightCodeSetPanel.add(jtfCodeSetFromFile);
		rightCodeSetPanel.add(btnCodeSetFromFilePanel);

		JPanel rdfUrlPanel = new JPanel();
		labelRDFUrl = new JLabel("URL:");
		jtfRDFUrl = new JTextField(60);
		defaultURL = "http://bmidev.mayo.edu/lexwiki/index.php/Special:ExportRDF";
		jtfRDFUrl.setText(defaultURL);
		JPanel btnRDFParsingPanel = new JPanel();
		btnRDFParsing = new JButton("Parse...");
		btnRDFParsing.addActionListener(this);
		btnRDFParsingPanel.add(btnRDFParsing);

		rdfUrlPanel.add(labelRDFUrl);
		rdfUrlPanel.add(jtfRDFUrl);
		rdfUrlPanel.add(btnRDFParsingPanel);

		JPanel upperRightPanel = new JPanel(new GridLayout(2, 1));
		upperRightPanel.add(rightCodeSetPanel);
		upperRightPanel.add(rdfUrlPanel);

		// contentLabel = new JLabel(" Contents: ");
		rightPanel.add(upperRightPanel, BorderLayout.NORTH);

		scrollPane = new JScrollPane();
		textArea = new JTextArea();
		scrollPane.getViewport().add(textArea);
		rightPanel.add(scrollPane, BorderLayout.CENTER);

		JPanel btnExportPanel = new JPanel();
		btnExport = new JButton("Export to Wiki...");
		btnExport.addActionListener(this);
		btnExportPanel.add(btnExport);

		btnBatchExport = new JButton("Batch Export...");
		btnBatchExport.addActionListener(this);
		btnExportPanel.add(btnBatchExport);

		btnBatchExportForTemplateContent = new JButton(
				"Batch Template Content...");
		btnBatchExportForTemplateContent.addActionListener(this);
		btnExportPanel.add(btnBatchExportForTemplateContent);
		btnSave = new JButton("Save...");
		btnSave.addActionListener(this);
		btnExportPanel.add(btnSave);

		rightPanel.add(btnExportPanel, BorderLayout.SOUTH);

		mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, leftPanel,
				rightPanel);
		mainPane.setOneTouchExpandable(true);

		this.setLayout(new BorderLayout());
		this.add(mainPane, BorderLayout.CENTER);

	}

	public void actionPerformed(ActionEvent e) {

		Object s = e.getSource();
		String ns = this.getNamespace();
		
		if(s == btnGetRootNodes){
			
		    this.getRootNodes();
		    
		}

		if (s == btnGetCodeSet) {
			
			    this.getCodeSet();
			
		}

		if (s == btnCreateContent) {
			
			    this.generateContent();
			
		}

		if (s == btnGenerateTemplateContent) {
			
			    this.generateTemplateContent();
			
		}

		// if(s == btnReadFromWiki){
		// this.readContentFromWiki();
		// }

		if (s == btnDetectChanges) {
			//this.detectChanges();
			
			//this.loadValueset();
			GenerateLexGridXMLForICD10CM lgxmlmodel = new GenerateLexGridXMLForICD10CM();
			lgxmlmodel.processingLexGridXML();
		}

		if (s == btnCodeSetFromFile) {
			this.getCodeSetFromFileToTextArea();
		}

		if (s == btnRDFParsing) {
			//this.getLexWikiRDFOutputParsed();
		}

		if (s == btnExport) {
			if(ns.equals("ICD10Index")){
				this.exportIndexContentToWiki();
			}else{
			    this.exportContentToWiki();
			}
		}

		if (s == btnBatchExport) {
			this.batchExportContentToWiki();
			// this.getAllAssociations();
		}

		if (s == btnBatchExportForTemplateContent) {
			this.batchExportTemplateContentToWiki();
		}

		if (s == btnSave) {
			this.saveContentToFile();
		}

	}
	

/*
	public class ListSelectionChanged implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent lse) {
			String selectedCode = (String) listConcepts.getSelectedValue();
			String[] pairs = selectedCode.split("\\|");
			String ns = getNamespace();
			String codedConcept = "/Category:" + ns + "_"
					+ model.mangle(pairs[1]) + "("
					+ pairs[0] + ")";
			

			String url = defaultURL + codedConcept;
			jtfRDFUrl.setText(url);
		}

	}
	
	*/



	private void getCodeSetFromFileToTextArea() {

		BufferedReader br = null;
		String fileName = jtfCodeSetFromFile.getText();
		StringBuffer sb = new StringBuffer();
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while (line != null) {
				sb.append(line + "\n");
				line = br.readLine();
			}

			br.close();
			textArea.setText(sb.toString());
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
	
	private void getRootNodes() {
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		String ns = this.getNamespace();
		Object[] rootNodes = model.getAllRootNodes(localName);
		
		jcbRootNodes.removeAllItems();
		
		jcbRootNodes.addItem("All");
		
		for(int i = 0; i < rootNodes.length; i++){
		    jcbRootNodes.addItem(rootNodes[i]);
		}
		//jcbRootNodes = new JComboBox(rootNodes);
		//rootNodesPanel.updateUI();
		//textArea.setText("root node number:" + rootNodes.length + "\n");
		model.getAllConceptCodesForSource(localName);
	   // textArea.setText(model.getAllRootNodesWithoutPAR(localName, ns));
		textArea.setText("done");
		
	}
	
	private void loadValueset(){
		String dburl = jtfUrl.getText();
		String dbprefix = jtfPrefix.getText();
		String dbuser = jtfUser.getText();
		String dbpassword = new String(jpfPassword.getPassword());
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		String ns = this.getNamespace();
		//String[] valuesets = (String[]) model.getAllConceptCodes(localName);
		Collection colValuesets = model.getAllConceptCodesValuesets(localName);
		LexWikiValueSetLoadingModel vsModel = new LexWikiValueSetLoadingModel();
		
	
		textArea.append("starting time:" + new Date() + "\n");
		textArea.append("Num of Valuesets;" + colValuesets.size() + "\n");
	
		vsModel.updateValueset(dbprefix, dburl, dbuser, dbpassword, colValuesets, "RIM", ns);

		textArea.append("ending time:" + new Date() + "\n");

	}


	private void getCodeSet() {
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		String rootName = (String) jcbRootNodes.getSelectedItem();
		int maxDepth = ((Integer) spinner.getValue()).intValue();

		
		Object[] codeSet = null;
		if(rootName.equals("All")){
		    codeSet = model.getAllConceptCodes(localName);
		}else{
			codeSet = model.getAllConceptCodesForRootBranch(localName, rootName, maxDepth);
		}
		listConcepts.setListData(codeSet);
		listScrollPane.getViewport().add(listConcepts);
		textArea.setText("concept number:" + codeSet.length + "\n");
		


	}

	private void getCodeSet_nciMetaModel() {
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String ns = this.getNamespace();
		if (ns == null) {
			ns = "NCI";
		}
		/*
		 * Object[] codeSet = model.getAllConceptCodes(localName);
		 * listConcepts.setListData(codeSet);
		 * listScrollPane.getViewport().add(listConcepts);
		 * textArea.setText("concept number:" + codeSet.length + "\n");
		 */

		// Object[] codeSet =
		// nciMetaModel.getAllConceptCodesForICD10(localName);
		// listConcepts.setListData(codeSet);
		// listScrollPane.getViewport().add(listConcepts);
		// textArea.setText("concept number:" + codeSet.length + "\n");
		// textArea.setText(nciMetaModel.getAllICD10Mappings(localName, "ICD10",
		// ns));
	}

	private String getNamespace() {
		String ns = (String) jcbNameSpaces.getSelectedItem();
		if (ns.equals("NONE")) {
			ns = "";
		}
		return ns;
	}
	


	private void generateContent() {

		String localName = (String) jcbCodeSystems.getSelectedItem();
		String selectedCode = (String) listConcepts.getSelectedValue();
		String ns = this.getNamespace();

		textArea.setText(model.getContentForConceptCode(selectedCode,
				localName, ns));

	}
	

	
	private String getLocatName (String displayName){
		String[] nameVersionPairs = displayName.split("\\|");
		String localName = nameVersionPairs[0];
		
		return localName;		
	}

	private void generateTemplateContent() {
		String ns = this.getNamespace();
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		
		String selectedCode = (String) listConcepts.getSelectedValue();
		StringBuffer sb = new StringBuffer();
		sb.append(model.getContentForConceptCode(selectedCode,
				localName, ns) + "\n");

		/*
		Collection properties = model.getSupportedPropertiesForCodingScheme(localName, ns);
		sb.append("Supported Properties:\n");
		for(Iterator it1 = properties.iterator(); it1.hasNext();){
			sb.append((String)it1.next() + "\n");
		}
		
		Collection associations = model.getSupportedAssociationsForCodingScheme(localName, ns);
		sb.append("Supported Associations:\n");
		for(Iterator it2 = associations.iterator(); it2.hasNext();){
			sb.append((String)it2.next() + "\n");
		}
		*/	
		
		textArea.setText(sb.toString());
		

	}

	private void readContentFromWiki() {

		String codedConcept = this.getSelectedConcept();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			textArea.setText(wikiBot.readContentOf(codedConcept).getText());

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}


	
	private void exportIndexContentToWiki(){
		String codedIndex = this.getSelectedIndex();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			//MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			//		"lexwiki", "lexlex");
			 MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(codedIndex);
			sa.setText(textArea.getText());
			wikiBot.writeContent(sa);

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}		
	}

	private void exportContentToWiki() {

		String codedConcept = this.getSelectedConcept();
		// codedConcept = templateModel.mangle(codedConcept);
		// normalization
		// codedConcept = codedConcept.replaceAll("\\[", "(");
		// codedConcept = codedConcept.replaceAll("\\]", ")");
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			//MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			//		"whodev", "icd11");
			 MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(codedConcept);
			System.out.println("label:" + codedConcept);
			sa.setText(textArea.getText());
			System.out.println("text:" + textArea.getText());			
			wikiBot.writeContent(sa);

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	/*
	 * private void getAllAssociations(){ StringBuffer sb = new StringBuffer();
	 * String ns = this.getNamespace(); String localName = (String)
	 * jcbCodeSystems.getSelectedItem(); String textCodes = textArea.getText();
	 * String[] codes = textCodes.split("\n"); Collection colCodes = new
	 * ArrayList(); for(int i = 0; i < codes.length; i++){
	 * colCodes.add(codes[i]); } Map allasses =
	 * templateModel.getAssociationContentForCodeSet(colCodes, localName, ns);
	 * for(Iterator it = allasses.keySet().iterator(); it.hasNext();){ String
	 * code = (String)it.next(); System.out.println(code); Collection asses =
	 * (Collection) allasses.get(code); for(Iterator it1 = asses.iterator();
	 * it1.hasNext();){ String ass = (String) it1.next(); sb.append(code + "|" +
	 * ass + "\n"); } }
	 * 
	 * textArea.setText(sb.toString()); }
	 */
	private void batchExportContentToWiki() {
		String ns = this.getNamespace();
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		String textCodes = textArea.getText();
		String[] codes = textCodes.split("\n");
		Collection colCodes = new ArrayList();
		for (int i = 0; i < codes.length; i++) {
			colCodes.add(codes[i]);
		}
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			// MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			// "lexwiki", "lexlex");
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			// Collection contents =
			// templateModel.getContentForCodeSet(colCodes, localName, ns);
			// wikiBot.writeMultContent(contents.iterator());

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	private void batchExportContentToWiki_bak08232007() {
		String ns = this.getNamespace();
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String selectedCode = (String) listConcepts.getSelectedValue();

		try {
			textArea.append("start time:" + new Date() + "\n");
			// textArea.append(templateModel.getContentForConceptCode(selectedCode,
			// localName, ns));

			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			// MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			// "lexwiki", "lexlex");
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			/*
			 * Collection allContents =
			 * templateModel.getContentArticleForConceptCode(selectedCode,
			 * localName, ns); for(Iterator it = allContents.iterator();
			 * it.hasNext();){ SimpleArticle sa = (SimpleArticle)it.next();
			 * 
			 * if(wikiBot.readContentOf(sa.getLabel()) == null){
			 * textArea.append("null:" + sa.getLabel() + "\n");
			 * //wikiBot.writeContent(sa); }else{ textArea.append("contents:" +
			 * sa.getLabel()); } }
			 * 
			 * //wikiBot.writeMultContent(allContents.iterator());
			 * textArea.append("Number of all contents: " + allContents.size() +
			 * "\n"); textArea.append("Number of all anonymous nodes: " +
			 * templateModel.getAnonymousNodesNumber() + "\n");
			 * textArea.append("ending time:" + new Date() + "\n");
			 */
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void batchExportContentToWiki_bak() {
		String ns = this.getNamespace();
		Collection allContents = new ArrayList();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			textArea.setText("Login...OK\n");

			// get content for selectedCls

			String localName = (String) jcbCodeSystems.getSelectedItem();

			allContents = model.getContentForConceptCodeForBatchExport(
					localName, ns);

			textArea.append("Content preparation...OK\n");

			// export all to wiki
			wikiBot.writeMultContent(allContents.iterator());

			textArea.append("Export to wiki...OK\n");

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	// for nciowl
	private void batchExportTemplateContentToWiki_nciowl() {

		Collection allContents = new ArrayList();
		try {
			textArea.append("start time:" + new Date() + "\n");

			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			// get content for selectedCls
			String ns = this.getNamespace();

			String localName = (String) jcbCodeSystems.getSelectedItem();

			allContents = model.getContentForConceptCodeForBatchExport(
					localName, ns);
			wikiBot.writeMultContent(allContents.iterator());

			textArea.append("Number of all contents: " + allContents.size()
					+ "\n");
			// textArea.append("Number of all anonymous nodes: " +
			// templateModel.getAnonymousNodesNumber() + "\n");
			textArea.append("ending time:" + new Date() + "\n");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	// for mayo table22
	private void batchExportTemplateContentToWiki() {

		Collection allContents = new ArrayList();
		Collection allProperties = new ArrayList();
		try {
			textArea.append("start time:" + new Date() + "\n");

			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			//MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			//		"whodev", "icd11");

			 MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			// textArea.setText("Login...OK\n");

			// get content for selectedCls
			String ns = this.getNamespace();

			String displayName = (String) jcbCodeSystems.getSelectedItem();
			String localName = this.getLocatName(displayName);

			allContents = model.getContentForConceptCodeForBatchExport(
					localName, ns);
			allProperties = model.getPropertyNames();

			// Collection nullCodes = templateModel.getNullConceptCodes();
			// for(Iterator it = nullCodes.iterator(); it.hasNext();){
			// String code = (String)it.next();
			// textArea.append(code + "\n");
			// }

			// textArea.append("Content preparation...OK\n");

			// export properties
			wikiBot.writeMultContent(allProperties.iterator());

			// export all to wiki
			wikiBot.writeMultContent(allContents.iterator());
			/*
			 * Map highLevelCodes = templateModel.getSuperClasses();
			 * for(Iterator it = highLevelCodes.keySet().iterator();
			 * it.hasNext();){ String code = (String) it.next();
			 * 
			 * Collection superCodes = (Collection)highLevelCodes.get(code);
			 * for(Iterator it1 = superCodes.iterator(); it1.hasNext();){ String
			 * superCode = (String)it1.next(); textArea.append(code + "|" +
			 * superCode + "\n"); }
			 *  }
			 * 
			 * Collection introCodes = templateModel.getIntroducedIcd9Codes();
			 * Map allDescriptionsICD9CM =
			 * templateModel.getAllDescriptionsICD9CM();
			 * textArea.append("=================================\n");
			 * for(Iterator it1 = introCodes.iterator(); it1.hasNext();){ String
			 * introCode = (String) it1.next(); String introDescription =
			 * (String)allDescriptionsICD9CM.get(introCode);
			 * textArea.append(introCode + "|" + introDescription + "\n"); }
			 * 
			 * //textArea.append("Export to wiki...OK\n");
			 */
			textArea.append("Number of all contents: " + allContents.size()
					+ "\n");
			textArea.append("ending time:" + new Date() + "\n");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	private void saveContentToFile() {
		try {
			BufferedWriter bw = new BufferedWriter(
					new FileWriter("content.txt"));
			bw.write(textArea.getText());
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private SimpleArticle getContentForEachClass(String code) {
		String ns = this.getNamespace();
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String coded = this.getSelectedConcept(code);
		SimpleArticle sa = new SimpleArticle();
		sa.setLabel(coded);
		sa.setText(model.getContentForConceptCode(code, localName, ns));
		return sa;
	}

	private String getSelectedConcept() {

		String selectedCode = (String) listConcepts.getSelectedValue();
		String[] pairs = selectedCode.split("\\|");
		String ns = this.getNamespace();
		String codedConcept = "";
		if(ns.equals("ICD11") ||
				ns.equals("ICD10CM")){
			
			codedConcept = "Category:"
				+ ns + "_(" + pairs[0] + ")_" + model.mangle(pairs[1]);			
		}else{
		    codedConcept = "Category:"
				+ model.mangle(ns + "_" + pairs[1]) + "(" + model.mangle(pairs[0])
				+ ")";
		}

		return codedConcept;
	}

	private String getSelectedIndex() {

		String idxName = (String) listConcepts.getSelectedValue();
		String codedIndex = "Index:"
				+ model.mangle(idxName);

		return codedIndex;
	}	
	
	private String getSelectedConcept(String code) {

		String[] pairs = code.split("\\|");
		String ns = this.getNamespace();
		String codedConcept = "Category: "
				+ model.mangle(ns + "_" + pairs[1]) + "(" + pairs[0]
				+ ")";

		return codedConcept;
	}
	
	private Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();
			

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();

			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				String version = csrs[i].getCodingSchemeSummary().getRepresentsVersion();
				vecCodeSystems.add(localName + "|" + version);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}
		

}
