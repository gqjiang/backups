package edu.mayo.informatics.lexwiki.lexwikitab;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import edu.mayo.informatics.lexwiki.claml.*;

import org.LexGrid.emf.base.xml.LgXMLResourceImpl;
import org.LexGrid.emf.codingSchemes.CodingScheme;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesFactoryImpl;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.commonTypes.Text;
import org.LexGrid.emf.concepts.Concept;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.Definition;
import org.LexGrid.emf.concepts.Presentation;
import org.LexGrid.emf.naming.Mappings;
import org.LexGrid.emf.naming.NamingFactory;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedDataType;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.impl.NamingFactoryImpl;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationSource;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.util.RelationsUtil;
import org.LexGrid.util.sql.DBUtility;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;


//first implementation of new lexwiki templates
public class GenerateLexGridXMLForICD10CM {

    private int rubricIndex = 1000000;
    
    private String icdFileName = "C:\\Temp\\icd10cm\\icd10cm.txt";
    private String icdNoteFileName = "C:\\Temp\\icd10cm\\icd10cm_notes.txt";
    //private String icdFileName = "/home/m005994/icd10cm/icd10cm.txt";
    //private String icdNoteFileName = "/home/m005994/icd10cm/icd10cm_notes.txt";

    private Map mapSuperClasses = new HashMap();
    private Collection colSupers = new ArrayList();
    private Map mapLabels = new HashMap();
    private Map mapSubClasses = new HashMap();
    private Map mapInclusions = new HashMap();
    private Map mapNotes = new HashMap();
    private Map mapExclusions1 = new HashMap();
    private Map mapExclusions2 = new HashMap();
    private Collection colChapters = new ArrayList();

    private ConceptsFactory conceptFactory = ConceptsFactory.eINSTANCE;
    private RelationsFactory relationsFactory = RelationsFactory.eINSTANCE;
    
    private org.LexGrid.emf.concepts.Entities allConcepts_ = null;
    
    private Association subClassOfAssocClass_ = null;
    private Association includesAssocClass_ = null;
    private Association excludes1AssocClass_ = null;
    private Association excludes2AssocClass_ = null;
    
    private List allCodedEntries_ = null;
    
	private NamingFactory nameFactory = new NamingFactoryImpl();
	private CodingschemesFactory csFactory = new CodingschemesFactoryImpl();
    private String RootCode = "@@";
    
    
	public GenerateLexGridXMLForICD10CM() {

	}
	
	public void processingLexGridXML(){
		System.out.println("starting..." + new Date());		
		this.processingSuperClasses();
		////System.out.println("superclasses:" + mapSuperClasses.size());
		System.out.println("chapters:" + colChapters.size());

		this.processingSubClasses();
		System.out.println("subclasses:" + mapSubClasses.keySet().size());
		
		this.processingInclusions();
		System.out.println("inclusions:" + mapInclusions.keySet().size());
		
		this.processingExclusions1();
		System.out.println("exclusions1:" + mapExclusions1.keySet().size());
		
		this.processingExclusions2();
		System.out.println("exclusions2:" + mapExclusions2.keySet().size());
		
		this.processingNotes();
		System.out.println("notes:" + mapNotes.keySet().size());		
		
		//String output = "C:\\Temp\\icd10cm\\lexgrid\\icd10cm_lexgrid.xml";	
		try {
			
			Collection colDuplicates = new ArrayList();
			
			BufferedReader br = new BufferedReader(new FileReader(icdFileName));
			
			CodingScheme csclass = this.getICD10CMCodingScheme();			
			this.prepareCSClassForConceptAndAssociations(csclass);
			this.populateSupportedProperties(csclass);
			this.populateSupportedAssociations(csclass);

			this.addConcept(RootCode, "ICD10CMROOT", RootCode, null, null, null, null, null);
            
			String line = br.readLine();
			line = br.readLine();
			int index = 0;
			while(line != null){
				String[] items = line.split("\\t");            
                //if(index <= 5000){
            //for(Iterator it1 = mapLabels.keySet().iterator(); it1.hasNext();){
            	//String code = (String) it1.next();
				String code = items[0].trim();
				System.out.println("code:" + code);
				
				if(code.length()  > 0){
				
				if(code.indexOf("\"") >= 0){
				   code = code.replaceAll("\"", "").trim();		
				}
				
				
				//check duplicate codes
				if(!colDuplicates.contains(code)){
					colDuplicates.add(code);
				
				
 
        		

        		
        		Collection colSubclasses = (Collection) mapSubClasses.get(code);
        		//if(colSubclasses != null){
        		//for(Iterator it2 = colSubclasses.iterator(); it2.hasNext();){
        		//	String subclassCode = (String) it2.next();
        		//}
        		//}
        		
        		
            	String label = (String) this.cleanupString(items[5]);
            	
        		
        		Collection colInclusions = (Collection) mapInclusions.get(code);
        		//if(colInclusions != null){
        		//for(Iterator it3 = colInclusions.iterator(); it3.hasNext();){
        		//	String inclusionLabel = (String) it3.next();
                //
        		 // }
        		//}
        		
        		Collection colExclusions1 = (Collection)mapExclusions1.get(code);
        		
        		if(colExclusions1 != null){
        		for(Iterator it4 = colExclusions1.iterator(); it4.hasNext();){
        			String exclusion1Label = (String) it4.next();

    				if(exclusion1Label.lastIndexOf("(") >=0){
    					int lindex = exclusion1Label.lastIndexOf("(");
    					String ecode = exclusion1Label.substring(lindex+1, exclusion1Label.length()-1);
    					
    					if(isCode(ecode)){
    						if(ecode.indexOf(",") >= 0 ||
    								ecode.endsWith("-") ||
    								ecode.length() > 8 ||
    								ecode.indexOf(" ") >= 0){
    						    continue;
    						}else{
    	    					String etext = exclusion1Label.substring(0, lindex-1);
    	    					ecode = ecode.replaceAll("\\)", "");
    	    					this.addRelationship(excludes1AssocClass_, code, ecode);
    						}
    					}
    					
    				}
        			
        		}
        		}
        		
        		Collection colExclusions2 = (Collection)mapExclusions2.get(code);
       		
        		if(colExclusions2 != null){
        		for(Iterator it5 = colExclusions2.iterator(); it5.hasNext();){
        			String exclusion2Label = (String) it5.next();

    				if(exclusion2Label.lastIndexOf("(") >=0){
    					int lindex = exclusion2Label.lastIndexOf("(");
    					String ecode = exclusion2Label.substring(lindex+1, exclusion2Label.length()-1);
    					if(isCode(ecode)){
    						if(ecode.indexOf(",") >= 0  ||
    								ecode.endsWith("-") ||
    								ecode.length() > 8  ||
    								ecode.trim().indexOf(" ") >= 0){
    				              continue;			
    						}else{
    	    					String etext = exclusion2Label.substring(0, lindex-1);
    	    					ecode = ecode.replaceAll("\\)", "");
    	    					this.addRelationship(excludes2AssocClass_, code, ecode);

    						}
    					}
    					
								
    				}
        			
        		} 
        		}

        		Collection colNotes = (Collection)mapNotes.get(code);
        		if(colNotes != null){
        		for(Iterator it6 = colNotes.iterator(); it6.hasNext();){
        			String noteLabel = (String) it6.next();
        			
        		}
        		
        		}
            	this.addConcept(code, label, label, "MISSING", 
            			colInclusions, colExclusions1, colExclusions2, colNotes);

            	String superclassCode = (String) items[3].trim();
        		if(superclassCode == null || superclassCode.length() < 1){
        			superclassCode = items[0].trim().substring(0, 5);
        			System.out.println(superclassCode + "|" + items[3].trim());
        		}
        		if(superclassCode.indexOf("\"") >= 0){
        			superclassCode = superclassCode.replaceAll("\"", "").trim();
        		}
        		
        		if(colChapters.contains(superclassCode)){
            		this.addRelationship(subClassOfAssocClass_, code, this.RootCode);
            		
        			
        		}else{
        		
        			this.addRelationship(subClassOfAssocClass_, code, superclassCode);
        		}

        		
				}
                }
				
				index++;
				
				System.out.println(index + " processed.");
				//if(index > 5000) break;
        		
        		line = br.readLine();
        		
            }
			
            
            this.writeLGXML(csclass);
			System.out.println(colDuplicates.size() + " ending..." + new Date());		
           
            
		}catch(Exception e){
			e.printStackTrace();
		}		
	}

	public void populateSupportedProperties(CodingScheme csclass) 
	{
        if (csclass == null)
            return;

        List suppProps = csclass.getMappings().getSupportedProperty();
        csclass.getMappings().getSupportedProperty();

        try 
        {
        	String sProperty[] = {"Preferred_Name", "DEFINITION", "Inclusion", "Exclusion1", "Exclusion2", "Note"};
        	
        	for (int i=0; i < sProperty.length; i++)
        	{
	        	SupportedProperty suppProp = nameFactory.createSupportedProperty();
	            suppProp.setUri(csclass.getCodingSchemeURI() + ":" + sProperty[i]);
		        suppProp.setLocalId(sProperty[i]);
		        suppProps.add(suppProp);
        	}        	
        } 
        catch (Exception ex) 
        {
            System.out.println("Failed while getting supported properties!");
        }
    }
	
	
	public void populateSupportedAssociations(CodingScheme csclass) 
	{
        try 
        {
            if (csclass == null)
                return;

            SupportedAssociation suppAss = nameFactory.createSupportedAssociation();
            suppAss.setUri(csclass.getCodingSchemeURI() + ":" + "CHD");
            suppAss.setLocalId("CHD");
            csclass.getMappings().getSupportedAssociation().add(suppAss);
            
            SupportedAssociation includes = nameFactory.createSupportedAssociation();
            includes.setUri(csclass.getCodingSchemeURI() + ":" + "Includes");
            includes.setLocalId("Includes");
            csclass.getMappings().getSupportedAssociation().add(includes);

            SupportedAssociation excludes1 = nameFactory.createSupportedAssociation();
            excludes1.setUri(csclass.getCodingSchemeURI() + ":" + "Excludes1");
            excludes1.setLocalId("Excludes1");
            csclass.getMappings().getSupportedAssociation().add(excludes1);

            SupportedAssociation excludes2 = nameFactory.createSupportedAssociation();
            excludes2.setUri(csclass.getCodingSchemeURI() + ":" + "Excludes2");
            excludes2.setLocalId("Excludes2");
            csclass.getMappings().getSupportedAssociation().add(excludes2);
            
        } 
        catch (Exception ex) 
        {
            ex.printStackTrace();
            System.out.println("Failed while getting supported associations!");
        }
    }
		
	public static int conceptCode = 100;
	private String addConcept(String code, 
								String name,
								String pref,
								String def, 
								Collection inclusions,
								Collection exclusions1,
								Collection exclusions2,
								Collection notes)
	{
		// Concept Basic
		Concept con = conceptFactory.createConcept();
		
		int pIndex = 100;
		
		if (isNull(code))
			con.setEntityCode("ICD10CM" + (conceptCode++));
		else
			con.setEntityCode(code);
		
		con.setEntityDescription(name);
		con.setIsActive(true);
		
		// Preferred Name
		Presentation tp = conceptFactory.createPresentation();
        Text txt1 = CommontypesFactory.eINSTANCE.createText();
       	txt1.setValue(name);
        tp.setValue(txt1);
        tp.setIsPreferred(new Boolean(true));
        tp.setPropertyName("Preferred_Name");
        tp.setPropertyId("P" + pIndex++);
        con.getPresentation().add(tp);
        
        if (("@".equalsIgnoreCase(code))||("@@".equalsIgnoreCase(code)))
        	con.setIsAnonymous(new Boolean(true));
        
        // Definition
		if (!isNull(def))
		{
			Definition defn = conceptFactory.createDefinition();
            Text txt2 = CommontypesFactory.eINSTANCE.createText();
            txt2.setValue(def);
            defn.setValue(txt2);
            defn.setPropertyName("DEFINITION");
            defn.setPropertyId("P" + pIndex++);
            defn.setIsPreferred(new Boolean(true));
            con.getDefinition().add(defn);
		}
		// Properties
		if (inclusions != null)
		{
			for(Iterator it1 = inclusions.iterator(); it1.hasNext();){
				String inclusion = (String) it1.next();
			    Property pc1 = CommontypesFactory.eINSTANCE.createProperty();
	            pc1.setPropertyName("Inclusion");
	            pc1.setPropertyId("P" + pIndex++);
	            Text txt3 = CommontypesFactory.eINSTANCE.createText();
	            txt3.setValue(inclusion);
	            pc1.setValue(txt3);
	            con.getProperty().add(pc1);
			}
		}
		
		if (exclusions1 != null)
		{
			for(Iterator it2 = exclusions1.iterator(); it2.hasNext();){
				String exclusion1 = (String) it2.next();
			    Property pc2 = CommontypesFactory.eINSTANCE.createProperty();
	            pc2.setPropertyName("Exclusion1");
	            pc2.setPropertyId("P" + pIndex++);
	            Text txt4 = CommontypesFactory.eINSTANCE.createText();
	            txt4.setValue(exclusion1);
	            pc2.setValue(txt4);
	            con.getProperty().add(pc2);
			}
		}

		if (exclusions2 != null)
		{
			for(Iterator it3 = exclusions2.iterator(); it3.hasNext();){
				String exclusion2 = (String) it3.next();
			    Property pc3 = CommontypesFactory.eINSTANCE.createProperty();
	            pc3.setPropertyName("Exclusion2");
	            pc3.setPropertyId("P" + pIndex++);
	            Text txt5 = CommontypesFactory.eINSTANCE.createText();
	            txt5.setValue(exclusion2);
	            pc3.setValue(txt5);
	            con.getProperty().add(pc3);
			}
		}
		
		if (notes != null)
		{
			for(Iterator it4 = notes.iterator(); it4.hasNext();){
				String note = (String) it4.next();
			    Property pc4 = CommontypesFactory.eINSTANCE.createProperty();
	            pc4.setPropertyName("Note");
	            pc4.setPropertyId("P" + pIndex++);
	            Text txt6 = CommontypesFactory.eINSTANCE.createText();
	            txt6.setValue(note);
	            pc4.setValue(txt6);
	            con.getProperty().add(pc4);
			}
		}		
		
		allCodedEntries_.add(con);
		
		return con.getEntityCode();
	}
	
	private void addRelationship(Association association, 
			                     String source, 
			                     String target) 
	{
		if ((isNull(source))||(isNull(target)))
		{
			System.out.println("Error in setting up Parent child relation, value is null");
			return;
		}
		
		AssociationSource aI = relationsFactory.createAssociationSource();
        aI.setSourceEntityCode(source);
        aI.setSourceEntityCodeNamespace("ICD-10-CM");
        aI = RelationsUtil.subsume(association, aI);
        
        AssociationTarget aT = relationsFactory.createAssociationTarget();
        aT.setTargetEntityCode(target);
        aT.setTargetEntityCodeNamespace("ICD-10-CM");
        RelationsUtil.subsume(aI, aT);
    }
	
	private boolean isNull(String str)
	{
		return ((str == null)||("".equals(str.trim()))||("null".equalsIgnoreCase(str.trim())));
	}
	
	public void prepareCSClassForConceptAndAssociations(CodingScheme csclass)
	{
		allConcepts_ = csclass.getEntities();

        if (allConcepts_ == null) {
            allConcepts_ = conceptFactory.createEntities();
            csclass.setEntities(allConcepts_);
        }

        allCodedEntries_ = allConcepts_.getEntity();

        // Relations
        Relations allRelations_ = relationsFactory.createRelations();
        allRelations_.setContainerName(SQLTableConstants.TBLCOLVAL_DC_RELATIONS);
        List allAssociations = allRelations_.getAssociation();
        
        // Add subClassOf
        subClassOfAssocClass_ = relationsFactory.createAssociation();
        subClassOfAssocClass_.setEntityCode("CHD");
        subClassOfAssocClass_.setForwardName("CHD");
        subClassOfAssocClass_.setReverseName("PAR");
        subClassOfAssocClass_.setIsTransitive(new Boolean(true));
        subClassOfAssocClass_.setIsSymmetric(new Boolean(true));
        subClassOfAssocClass_.setIsReflexive(new Boolean(true));
        
        allAssociations.add(subClassOfAssocClass_);

        // Add includes
        includesAssocClass_ = relationsFactory.createAssociation();
        includesAssocClass_.setEntityCode("Includes");
        includesAssocClass_.setForwardName("Includes");
        includesAssocClass_.setReverseName("isIncluded");
        includesAssocClass_.setIsTransitive(new Boolean(true));
        includesAssocClass_.setIsSymmetric(new Boolean(true));
        includesAssocClass_.setIsReflexive(new Boolean(true));
        
        allAssociations.add(includesAssocClass_);

        // Add excludes1
        excludes1AssocClass_ = relationsFactory.createAssociation();
        excludes1AssocClass_.setEntityCode("Excludes1");
        excludes1AssocClass_.setForwardName("Excludes1");
        excludes1AssocClass_.setReverseName("isExcluded1");
        excludes1AssocClass_.setIsTransitive(new Boolean(true));
        excludes1AssocClass_.setIsSymmetric(new Boolean(true));
        excludes1AssocClass_.setIsReflexive(new Boolean(true));
        
        allAssociations.add(excludes1AssocClass_);

        // Add excludes2
        excludes2AssocClass_ = relationsFactory.createAssociation();
        excludes2AssocClass_.setEntityCode("Excludes2");
        excludes2AssocClass_.setForwardName("Excludes2");
        excludes2AssocClass_.setReverseName("isExcluded2");
        excludes2AssocClass_.setIsTransitive(new Boolean(true));
        excludes2AssocClass_.setIsSymmetric(new Boolean(true));
        excludes2AssocClass_.setIsReflexive(new Boolean(true));
        
        allAssociations.add(excludes2AssocClass_);

        csclass.getRelations().add(allRelations_);
	}
	
	private void writeLGXML(CodingScheme csclass)
	{
		//String output_filename = "file:///C:/Temp/icd10cm/lexgrid/icd10cm_lexgrid.xml";
		String output_filename = "/home/m005994/icd10cm/icd10cm_lexgrid.xml";
		org.eclipse.emf.common.util.URI output_uri = org.eclipse.emf.common.util.URI.createURI(output_filename);
		LgXMLResourceImpl xml = null;
        try {

            xml = new LgXMLResourceImpl(output_uri);
            xml.getContents().add(csclass);

            // Perform the save ...
            xml.save();
        } 
        catch (Exception e) 
        {
            System.out.println("Failed");
            e.printStackTrace();
        }
        System.out.println("Successfully Created LGXML at " + output_uri.toString());
	}
	
	public CodingScheme getICD10CMCodingScheme() 
	{
        CodingScheme csclass = null;
        try 
        {
            csclass = csFactory.createCodingScheme();
            csclass.setMappings((Mappings) nameFactory.createMappings());
            csclass.setCodingSchemeName("ICD-10-CM");
            csclass.setFormalName("ICD-10-CM");
            csclass.setCodingSchemeURI("ICD-10-CM");
            csclass.setDefaultLanguage("en");
            csclass.setRepresentsVersion("July 2007");
            csclass.getLocalName().add("ICD-10-CM");

            List supportedLanguages = csclass.getMappings().getSupportedLanguage();
            prepareSupportedLanguages(supportedLanguages);

            List supportedFormats = csclass.getMappings().getSupportedDataType();
            prepareSupportedFormats(supportedFormats);
            prepareSupportedCodingScheme(csclass);
            prepareSupportedHierarchy(csclass);
            
            // EList supportedDataTypes = csclass.getSupportedDataType();
            // prepareSupportedDataTypes(supportedDataTypes);
        } catch (Exception e) {
            System.out.println("Failed while preparing for Coding Scheme Class");
            e.printStackTrace();
        }

        return csclass;
    }
	
    private void prepareSupportedLanguages(List suppLang) 
    {
        try 
        {
            SupportedLanguage lang = nameFactory.createSupportedLanguage();
            lang.setLocalId("en");
            lang.setUri("urn:iso:2.16.840.1.113883.6.99:en");
            suppLang.add(lang);
        } 
        catch (Exception e) 
        {
            System.out.println("Failed while setting supported languages...");
            e.printStackTrace();
        }
    }
    
    private void prepareSupportedCodingScheme(CodingScheme csclass) 
    {
        try 
        {
            List suppCodingScheme = csclass.getMappings().getSupportedCodingScheme();
            SupportedCodingScheme scs = nameFactory.createSupportedCodingScheme();
            scs.setLocalId(csclass.getCodingSchemeName());
            scs.setUri(csclass.getCodingSchemeURI());
            suppCodingScheme.add(scs);
        } catch (Exception e) 
        {
            System.out.println("Failed while setting supported codingScheme...");
            e.printStackTrace();
        }
    }
    
    
    public void prepareSupportedHierarchy(CodingScheme csclass) 
    {
        try 
        {
            List suppHierarchy = csclass.getMappings().getSupportedHierarchy();
            org.LexGrid.emf.naming.SupportedHierarchy shr = nameFactory.createSupportedHierarchy();
            shr.setLocalId("CHD");
            shr.setUri(null);
            shr.setValue("CHD");
            shr.setIsForwardNavigable(true);
            shr.setRootCode(RootCode);
            suppHierarchy.add(shr);
            shr.setAssociationNames(
                    Arrays.asList(new String[] { "CHD" }));
        } 
        catch (Exception e) 
        {
            System.out.println("Failed while setting supported Hierarchy...");
            e.printStackTrace();
        }
    }

    private void prepareSupportedFormats(List suppFmt) 
    {
        SupportedDataType fmt = nameFactory.createSupportedDataType();
        fmt.setLocalId("text/plain");
        fmt.setUri("text/plain");
        suppFmt.add(fmt);
    }	
	
	public void processingClaMLXML(){
		
		System.out.println("starting..." + new Date());		
		this.processingSuperClasses();
		////System.out.println("superclasses:" + mapSuperClasses.size());
		System.out.println("chapters:" + colChapters.size());
		this.processingSubClasses();
		System.out.println("subclasses:" + mapSubClasses.keySet().size());
		
		this.processingInclusions();
		System.out.println("inclusions:" + mapInclusions.keySet().size());
		
		this.processingExclusions1();
		System.out.println("exclusions1:" + mapExclusions1.keySet().size());
		
		this.processingExclusions2();
		System.out.println("exclusions2:" + mapExclusions2.keySet().size());
		
		this.processingNotes();
		System.out.println("notes:" + mapNotes.keySet().size());		
		
		String output = "C:\\Temp\\icd10cm\\claml\\icd10cm_claml.xml";	
		try {
			
			BufferedReader br = new BufferedReader(new FileReader(icdFileName));
			
			FileOutputStream fos = new FileOutputStream(output);
			ObjectFactory factory = new ObjectFactory();
			
            ClaML claml = factory.createClaML();
            claml.setVersion("2.0.0");
            
            Title title = factory.createTitle();
            title.setDate("2009-06-28");
            title.setName("ICD-10-CM");
            title.setVersion("July 2007");
            
            claml.setTitle(title);
            
            Identifier identifier = factory.createIdentifier();
            identifier.setAuthority("WHO");
            identifier.setUid("id-to-be-added-later");
            claml.getIdentifier().add(identifier);
            
            Meta meta = factory.createMeta();
            meta.setName("lang");
            meta.setValue("en");
            claml.getMeta().add(meta);
            
            ClassKinds clsKinds = factory.createClassKinds();
			ClassKind cKind1 = factory.createClassKind();
			cKind1.setName("chapter");
			clsKinds.getClassKind().add(cKind1);
			ClassKind cKind2 = factory.createClassKind();
			cKind2.setName("block");
			clsKinds.getClassKind().add(cKind2);
			ClassKind cKind3 = factory.createClassKind();
			cKind3.setName("category");
			clsKinds.getClassKind().add(cKind3);
            claml.setClassKinds(clsKinds);
            
            UsageKinds useKinds = factory.createUsageKinds();
            UsageKind useKind = factory.createUsageKind();
            useKind.setMark("!");
            useKind.setName("optional");
            useKinds.getUsageKind().add(useKind);
            claml.setUsageKinds(useKinds);
            
            RubricKinds rubKinds = factory.createRubricKinds();
            RubricKind rKind1 = factory.createRubricKind();
            rKind1.setInherited("false");
            rKind1.setName("preferred");
            rubKinds.getRubricKind().add(rKind1);
            RubricKind rKind2 = factory.createRubricKind();
            rKind2.setInherited("false");
            rKind2.setName("inclusion");
            rubKinds.getRubricKind().add(rKind2);
            RubricKind rKind3 = factory.createRubricKind();
            rKind3.setInherited("false");
            rKind3.setName("exclusion1");
            rubKinds.getRubricKind().add(rKind3);
            RubricKind rKind4 = factory.createRubricKind();
            rKind4.setInherited("false");
            rKind4.setName("exclusion2");
            rubKinds.getRubricKind().add(rKind4);
            RubricKind rKind5 = factory.createRubricKind();
            rKind5.setInherited("false");
            rKind5.setName("note");
            rubKinds.getRubricKind().add(rKind5);
            claml.setRubricKinds(rubKinds);
            
			String line = br.readLine();
			line = br.readLine();
			int index = 0;
			while(line != null){
				String[] items = line.split("\\t");            
            
            //for(Iterator it1 = mapLabels.keySet().iterator(); it1.hasNext();){
            	//String code = (String) it1.next();
				String code = items[0].trim();
				
				if(code.length()  > 0){
				
				if(code.indexOf("\"") >= 0){
				   code = code.replaceAll("\"", "").trim();		
				}
				
            	edu.mayo.informatics.lexwiki.claml.Class cls = factory.createClass();
            	cls.setCode(code);
        		if(colChapters.contains(code)){
        			ClassKind cKind = factory.createClassKind();
        			cKind.setName("chapter");
        			cls.setKind(cKind);
        			clsKinds.getClassKind().add(cKind);

        		}else if(code.indexOf("-") >= 0){
        			ClassKind cKind = factory.createClassKind();
        			cKind.setName("block");
        			cls.setKind(cKind);
        		}else{
        			ClassKind cKind = factory.createClassKind();
        			cKind.setName("category");
        			cls.setKind(cKind);
        		} 
        		
        		String superclassCode = (String) items[3].trim();
        		if(superclassCode == null || superclassCode.length() < 1){
        			superclassCode = items[0].trim().substring(0, 5);
        			System.out.println(superclassCode + "|" + items[3].trim());
        		}
        		if(superclassCode.indexOf("\"") >= 0){
        			superclassCode = superclassCode.replaceAll("\"", "").trim();
        		}
        		SuperClass superclass = factory.createSuperClass();
        		superclass.setCode(superclassCode);
        		cls.getSuperClass().add(superclass);
        		
        		//for (Iterator it = colSupers.iterator(); it.hasNext();){
        		//	String item = (String) it.next();
        		//	String[] pair = item.split("\\|");
        		//	if(code.equals(pair[0])){
                //		SuperClass superclass = factory.createSuperClass();
                //		superclass.setCode(pair[1]);
                //		break;       				
        		//	}
        		//}
        		
        		Collection colSubclasses = (Collection) mapSubClasses.get(code);
        		if(colSubclasses != null){
        		for(Iterator it2 = colSubclasses.iterator(); it2.hasNext();){
        			String subclassCode = (String) it2.next();
        			//System.out.println(code + "|" + subclassCode);
        			SubClass subclass = factory.createSubClass();
        			subclass.setCode(subclassCode);
        			cls.getSubClass().add(subclass);
        		}
        		}
        		
        		
            	String label = (String) this.cleanupString(items[5]);
            	Rubric rubricLabel = factory.createRubric();
        		rubricLabel.setId("id-to-be-added-later-" + rubricIndex++);
        		ClassKind cKind = factory.createClassKind();
        		cKind.setName("preferred");
        		rubricLabel.setKind(cKind);

        		Label clsLabel = factory.createLabel();
        		clsLabel.setLang("en");
        		clsLabel.setSpace("default");
        		clsLabel.getContent().add(label);
        		rubricLabel.getLabel().add(clsLabel);
        		cls.getRubric().add(rubricLabel);
        		
        		Collection colInclusions = (Collection) mapInclusions.get(code);
        		if(colInclusions != null){
        		for(Iterator it3 = colInclusions.iterator(); it3.hasNext();){
        			String inclusionLabel = (String) it3.next();
    				Rubric rubricInclusion = factory.createRubric();
    				rubricInclusion.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindInclusion = factory.createClassKind();
    				cKindInclusion.setName("inclusion");
    				rubricInclusion.setKind(cKindInclusion);
    				Label labelInclusion = factory.createLabel();
    				labelInclusion.setLang("en");
    				labelInclusion.setSpace("default");
    				labelInclusion.getContent().add(inclusionLabel);
    				rubricInclusion.getLabel().add(labelInclusion);
                    cls.getRubric().add(rubricInclusion);

        		}
        		}
        		
        		Collection colExclusions1 = (Collection)mapExclusions1.get(code);
        		
        		if(colExclusions1 != null){
        		for(Iterator it4 = colExclusions1.iterator(); it4.hasNext();){
        			String exclusion1Label = (String) it4.next();
    				Rubric rubricExclusion1 = factory.createRubric();
    				rubricExclusion1.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindExclusion1 = factory.createClassKind();
    				cKindExclusion1.setName("exclusion1");
    				rubricExclusion1.setKind(cKindExclusion1);
    				Label labelExclusion1 = factory.createLabel();
    				labelExclusion1.setLang("en");
    				labelExclusion1.setSpace("default");

    				if(exclusion1Label.lastIndexOf("(") >=0){
    					int lindex = exclusion1Label.lastIndexOf("(");
    					String ecode = exclusion1Label.substring(lindex+1, exclusion1Label.length()-1);
    					
    					if(isCode(ecode)){
    						if(ecode.indexOf(",") >= 0 ||
    								ecode.endsWith("-") ||
    								ecode.length() > 8 ||
    								ecode.indexOf(" ") >= 0){
    							labelExclusion1.getContent().add(exclusion1Label);
    							rubricExclusion1.getLabel().add(labelExclusion1);
    							cls.getRubric().add(rubricExclusion1);    						
    						}else{
    	    					String etext = exclusion1Label.substring(0, lindex-1);
    	    					ecode = ecode.replaceAll("\\)", "");
    	    					edu.mayo.informatics.lexwiki.claml.Reference reference = factory.createReference();
    	    					reference.setClazz("in brackets");
    	    					reference.setContent(ecode);
    	    					
    	    					//if(ecode.endsWith("-")){
    	    					//	ecode = ecode.substring(0, ecode.length()-1);
    	    					//}
    	    					reference.setCode(ecode);
    	    					labelExclusion1.getContent().add(etext);
    	    					labelExclusion1.getContent().add(reference);
    	    					rubricExclusion1.getLabel().add(labelExclusion1);
    	    					cls.getRubric().add(rubricExclusion1);									
   							
    						}
    					}else{
    							labelExclusion1.getContent().add(exclusion1Label);
    							rubricExclusion1.getLabel().add(labelExclusion1);
    							cls.getRubric().add(rubricExclusion1);    						
    						
    					}
    					
    				}else{    				
    				
    					labelExclusion1.getContent().add(exclusion1Label);
    					rubricExclusion1.getLabel().add(labelExclusion1);
    					cls.getRubric().add(rubricExclusion1);
    				}
        			
        		}
        		}
        		
        		Collection colExclusions2 = (Collection)mapExclusions2.get(code);
        		
        		if(colExclusions2 != null){
        		for(Iterator it5 = colExclusions2.iterator(); it5.hasNext();){
        			String exclusion2Label = (String) it5.next();
    				Rubric rubricExclusion2 = factory.createRubric();
    				rubricExclusion2.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindExclusion2 = factory.createClassKind();
    				cKindExclusion2.setName("exclusion2");
    				rubricExclusion2.setKind(cKindExclusion2);
    				Label labelExclusion2 = factory.createLabel();
    				labelExclusion2.setLang("en");
    				labelExclusion2.setSpace("default");

    				if(exclusion2Label.lastIndexOf("(") >=0){
    					int lindex = exclusion2Label.lastIndexOf("(");
    					String ecode = exclusion2Label.substring(lindex+1, exclusion2Label.length()-1);
    					if(isCode(ecode)){
    						if(ecode.indexOf(",") >= 0  ||
    								ecode.endsWith("-") ||
    								ecode.length() > 8  ||
    								ecode.trim().indexOf(" ") >= 0){
    	    					labelExclusion2.getContent().add(exclusion2Label);
    	    					rubricExclusion2.getLabel().add(labelExclusion2);
    	    					cls.getRubric().add(rubricExclusion2);
    							
    						}else{
    	    					String etext = exclusion2Label.substring(0, lindex-1);
    	    					ecode = ecode.replaceAll("\\)", "");

    	    					edu.mayo.informatics.lexwiki.claml.Reference reference = factory.createReference();
    	    					reference.setClazz("in brackets");
    	    					reference.setContent(ecode);
    	    					
    	    					//if(ecode.endsWith("-")){
    	    					//	ecode = ecode.substring(0, ecode.length()-1);
    	    					//}
    	    					reference.setCode(ecode);

    	    					labelExclusion2.getContent().add(etext);
    	    					labelExclusion2.getContent().add(reference);
    	    					rubricExclusion2.getLabel().add(labelExclusion2);
    	    					cls.getRubric().add(rubricExclusion2);	    							
    						}
    					}else{
        					labelExclusion2.getContent().add(exclusion2Label);
        					rubricExclusion2.getLabel().add(labelExclusion2);
        					cls.getRubric().add(rubricExclusion2);
    						
    					}
    					
								
    				}else{    				
    					labelExclusion2.getContent().add(exclusion2Label);
    					rubricExclusion2.getLabel().add(labelExclusion2);
    					cls.getRubric().add(rubricExclusion2);
    				}
        			
        		} 
        		}
/*
        		Collection colNotes = (Collection)mapNotes.get(code);
        		if(colNotes != null){
        		for(Iterator it6 = colNotes.iterator(); it6.hasNext();){
        			String noteLabel = (String) it6.next();
    				Rubric rubricNote = factory.createRubric();
    				rubricNote.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindNote = factory.createClassKind();
    				cKindNote.setName("note");
    				rubricNote.setKind(cKindNote);
    				Label labelNote = factory.createLabel();
    				labelNote.setLang("en");
    				labelNote.setSpace("default");
    				labelNote.getContent().add(noteLabel);
    				rubricNote.getLabel().add(labelNote);
                    cls.getRubric().add(rubricNote);
        			
        		}
        		
        		}
*/        		
        		claml.getClazz().add(cls);
				}
        		
        		line = br.readLine();
        		
            }
            
			JAXBContext jaxbContext = JAXBContext.newInstance("edu.mayo.bmi.guoqian.claml");
			Marshaller marshaller = jaxbContext.createMarshaller();
	
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal( claml, fos );
			System.out.println("ending..." + new Date());		
           
            
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	private boolean isCode(String code){
		boolean ret = false;
		if (code.indexOf("0") >= 0 ||
				code.indexOf("1") >= 0 ||
				code.indexOf("2") >= 0 ||
				code.indexOf("3") >= 0 ||
				code.indexOf("4") >= 0 ||
				code.indexOf("5") >= 0 ||
				code.indexOf("6") >= 0 ||
				code.indexOf("7") >= 0 ||
				code.indexOf("8") >= 0 ||
				code.indexOf("9") >= 0){
			ret = true;
		}
		
		
		return ret;
	}
	
	private void processingSuperClasses(){
		BufferedReader br = null;
		//Collection colSuperClasses = new ArrayList();
		try{
			br = new BufferedReader(new FileReader(icdFileName));
			String line = br.readLine();
			line = br.readLine();
			int index = 0;
			while(line != null){
				String[] items = line.split("\\t");
				
				//superclasses
				//if(items[0] != null){
                    
					//mapSuperClasses.put(new String(items[0].trim()), new String(items[3].trim()));
					//colSupers.add(items[0] + "|" + items[3]);
					//index++;
					//System.out.println(index + "|" + items[0] + "|" + mapSuperClasses.size());

				//}
				
				//labels
				//if(items[0] != null && items[5] != null)
					//mapLabels.put(items[0].trim(), this.cleanupString(items[5]));
				
				
				//chapter code
				if(items[1].trim().equals("MH")){
					if(!colChapters.contains(items[2].trim())){
						colChapters.add(items[2].trim());
					}
				}
				line = br.readLine();
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	private String cleanupString(String label){
		String ret = label;
		if(label.startsWith("\"")){ 
			label = label.substring(1);
			label = label.substring(0, label.length()-1);
			ret = label.trim();
	    }else{
	    	ret = label.trim();
	    }
		
		return ret;
	}
	
	private void processingSubClasses(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdFileName));
			String line = br.readLine();
			line = br.readLine();
			while(line != null){
				String[] items = line.split("\\t");

				
				if(items[3] != null && items[0] != null && items[0].trim().length() > 1){
					
					String subcode = items[0].trim();
					if(subcode.indexOf("\"") >= 0){
						subcode = subcode.replaceAll("\"", "").trim();
					}
					String supercode = items[3].trim();
					if(supercode.indexOf("\"") >= 0){
						supercode = supercode.replaceAll("\"", "");
					}
					
					if(!mapSubClasses.containsKey(supercode)){
						Collection colSubs = new ArrayList();
						if(!colSubs.contains(subcode)){						
							colSubs.add(subcode);
						}
						mapSubClasses.put(supercode, colSubs);
					}else{
						Collection colSubs = (Collection) mapSubClasses.get(supercode);
					    if(!colSubs.contains(subcode))
					    	colSubs.add(subcode);
					    mapSubClasses.put(supercode, colSubs);
					}
				}

				line = br.readLine();
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	private void processingInclusions(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
					if(items[2].equals("1")){
                        if(items[3].startsWith("Includes")){
                	     
                	     this.addInclusions(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0] + "|" + items[2] + "|" + this.removeHeader(items[3]));
                	     isInclusion = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  		if (items[3].startsWith("Excludes1") ||
	                		   items[3].startsWith("Excludes2") ||
								items[3].startsWith("The following") ||
	                		   items[3].startsWith("Notes")){
                  			
                  		}else{
                   	     
                   	     this.addInclusions(items[0].trim(), this.removeHeader(items[3]));
                   	     //System.out.println(items[0] + "|" + items[2] + "|" + this.removeHeader(items[3]));
                   	     isInclusion = true;    
                   	     previousCode = items[0];                  			
                  		}
                      }
				}else{
					 if(items[0].equals(previousCode)){
						if(items[3].indexOf("Excludes1") >= 0 ||
		                		   items[3].indexOf("Excludes2") >= 0 ||
									items[3].startsWith("The following") ||
		                		   items[3].indexOf("Notes") >= 0){
							isInclusion = false;
						}
						if(isInclusion){
							this.addInclusions(items[0].trim(), this.removeHeader(items[3]));
	                	    // System.out.println(items[0] + "2|" + items[2] + "|" + this.removeHeader(items[3]));
					 }
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 100) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}

	private void processingExclusions1(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
                       if(items[3].startsWith("Excludes1")){
                	     
                	     this.addExclusions1(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0] + "|" + items[2] + "|" + items[3]);
                	     isExcludes1 = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  
					 if(items[0].equals(previousCode)){
						if(isExcludes1){
							
							if(items[3].startsWith("Excludes2") ||
									items[3].startsWith("Notes") ||
									items[3].startsWith("The following") ||									
									items[3].length() < 1){
								isExcludes1 = false;
							}else{
							
							this.addExclusions1(items[0].trim(), this.removeHeader(items[3]));
	                	     //System.out.println(items[0] + "2|" + items[2] + "|" + this.removeHeader(items[3]));
							}
						}
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 100) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}	

	private void processingExclusions2(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
                       if(items[3].startsWith("Excludes2")){
                	     
                	     this.addExclusions2(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0] + "|" + items[2] + "|" + items[3]);
                	     isExcludes2 = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  
					 if(items[0].equals(previousCode)){
						if(isExcludes2){
							
							if(items[3].startsWith("Excludes1") ||
									items[3].startsWith("Notes") ||
									items[3].startsWith("The following") ||
									items[3].length() < 1){
								isExcludes2 = false;
							}else{
							
							this.addExclusions2(items[0].trim(), this.removeHeader(items[3]));
	                	     //System.out.println(items[0] + "2|" + items[2] + "|" + this.removeHeader(items[3]));
							}
						}
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 1000) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}	

	private void processingNotes(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			boolean isNote = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
                       if(items[3].startsWith("Note") ||
                    		   items[3].startsWith("The following")){
                	     
                	     this.addNotes(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0].trim() + "|" + items[2] + "|" + items[3]);
                	     isNote = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  
					 if(items[0].equals(previousCode)){
						if(isNote){
							
							if(items[3].startsWith("Excludes1") ||
									items[3].startsWith("Excludes2") ||
									items[3].length() < 1){
								isNote = false;
							}else{
							
							this.addNotes(items[0].trim(), this.removeHeader(items[3]));
	                	     //System.out.println(items[0].trim() + "2|" + items[2] + "|" + this.removeHeader(items[3]));
							}
						}
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 1000) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}		
	
	private String removeHeader(String note){
		String ret = note;
		if(note.startsWith("Includes:")){
			ret = note.substring(10);
		}else if(note.startsWith("Excludes1:")){
			ret = note.substring(11);
		}else if(note.startsWith("Excludes2:")){
			ret = note.substring(11);
		}else if(note.startsWith("Note:")){
			ret = note.substring(6);
		}
		
		return ret;
	}
	
	private void addInclusions(String code, String inclusion){
        if(!mapInclusions.containsKey(code)){
     	   Collection colInclusions = new ArrayList();
     	   if(!colInclusions.contains(inclusion))
     		   colInclusions.add(inclusion);
     	   mapInclusions.put(code, colInclusions);
        }else{
        	Collection colInclusions = (Collection) mapInclusions.get(code);
        	if(!colInclusions.contains(inclusion))
        		colInclusions.add(inclusion);
        	mapInclusions.put(code, colInclusions);
        }
	}

	private void addExclusions1(String code, String exclusion){
        if(!mapExclusions1.containsKey(code)){
     	   Collection colExclusions = new ArrayList();
     	   if(!colExclusions.contains(exclusion))
     		  colExclusions.add(exclusion);
     	   mapExclusions1.put(code, colExclusions);
        }else{
        	Collection colExclusions = (Collection) mapExclusions1.get(code);
        	if(!colExclusions.contains(exclusion))
        		colExclusions.add(exclusion);
        	mapExclusions1.put(code, colExclusions);
        }
	}	

	private void addExclusions2(String code, String exclusion){
        if(!mapExclusions2.containsKey(code)){
     	   Collection colExclusions = new ArrayList();
     	   if(!colExclusions.contains(exclusion))
     		   colExclusions.add(exclusion);
     	   mapExclusions2.put(code, colExclusions);
        }else{
        	Collection colExclusions = (Collection) mapExclusions2.get(code);
        	if(!colExclusions.contains(exclusion))
        		colExclusions.add(exclusion);
        	mapExclusions2.put(code, colExclusions);
        }
	}		

	private void addNotes(String code, String note){
        if(!mapNotes.containsKey(code)){
     	   Collection colNotes = new ArrayList();
     	   if(!colNotes.contains(note))
     	     colNotes.add(note);
     	   mapNotes.put(code, colNotes);
        }else{
        	Collection colNotes = (Collection) mapNotes.get(code);
        	if(!colNotes.contains(note))
        		colNotes.add(note);
        	mapNotes.put(code, colNotes);
        }
	}
	
	
	public static void main(String[] args){
		GenerateLexGridXMLForICD10CM model = new GenerateLexGridXMLForICD10CM();
		//model.processingInclusions();
		//model.processingExclusions1();
		//model.processingExclusions2();
		//model.processingNotes();
		//model.processingClaMLXML();
		model.processingLexGridXML();
	}
	
}