package edu.mayo.informatics.lexwiki.lexwikitab;

/**
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;
import java.io.*;

public class Frequency {

  private Map storage;
  /**
   * No of tokens.
   */
  private int total = 0;

  public Frequency() {
    storage = new HashMap();
  }//constructor

  public void putWordFreq(String word, int[] freq){
    storage.put(word, freq);
  }

  /**
   * Adds word and frequency to the Map storage.
   * Note that the value is a one-slot int array, since the Map requires an
   * object (and not an int).
   */
  public void add(String word) {
    int value[] = (int[])storage.get(word);
    if (value == null) {
      //one-slot array since this is an "object", as opposed to data type int!
      value = new int[1];
      storage.put(word, value);
    }
    value[0]++;
    total++;
  }//add

  public void add(Integer integer){
    int value[] = (int[])storage.get(integer);
    if (value == null) {
      //one-slot array since this is an "object", as opposed to data type int!
      value = new int[1];
      storage.put(integer, value);
    }
    value[0]++;
    total++;
  }

  /**
   * Returns the frequency of the given word.
   */
  public int getFreq(String word) {
    int retval = 0;
    int value[] = (int[])storage.get(word);
    if (value != null) {
      retval = value[0];
    }
    return retval;
  }//getFreq


  public int getFreq(Integer integer) {
    int retval = 0;
    int value[] = (int[])storage.get(integer);
    if (value != null) {
      retval = value[0];
    }
    return retval;

  }
  /**
   * We only want to iterate over the keys.
   */
  public Iterator iterator() {
    return(storage.keySet().iterator());
  }//iterator

  /**
   * Returns the number of tokens.
   */
  public int getTokens() {
    return this.total;
  }//getTotal

  /**
   * Returns the number of types.
   */
  public int getTypes() {
    return this.storage.size();
  }//getTypes
  
}

