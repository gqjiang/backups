package edu.mayo.informatics.lexwiki.lexwikitab;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;
import java.net.URL;

import au.com.bytecode.opencsv.CSVReader;


public class GenerateTemplateForCadsrDataElements {
	
	private final String fileName = "C:\\Temp\\cadsr\\cadsr_cde_lesion.csv"; 
	
	//private String urlstr = "http://bmidev3/cshare/index.php";
	private String urlstr = "http://informatics.mayo.edu/ndrc/index.php";
	private String userName = "Guoqian";
	private String password = "guoqian0331";
	
	private Collection colDataSetPages = new ArrayList(); 
	
	public void publishDataElementsToWiki(){
		Collection des = this.processingDataElements();


		try{
			URL url = new URL(urlstr);
			//MediaWikiBot wikiBot = new MediaWikiBot(url);
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "cshare", "xTu$$9");
			wikiBot.login(userName, password);
			wikiBot.writeMultContent(des.iterator());
			System.out.println("publishing done: " + des.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
        
	}
	

	public Collection processingDataElements(){
		
		Collection ret = new ArrayList();
		BufferedReader br = null;

		try{
			//br = new BufferedReader(new FileReader(fileName));
			CSVReader reader = new CSVReader(new FileReader(fileName));
			//String line = br.readLine();
			
			String[] names = reader.readNext();
			
			String[] nextline = reader.readNext();
			
			int index = 0;
			Map desMap = new HashMap();
			while(nextline != null){
				StringBuffer sb = new StringBuffer();
				Map deMap = new HashMap();
				
				if(nextline.length > 1){
					String[] items = nextline;
					if(items.length > 50){
					if(items[0].length() > 0){
					//String source = "CADSR";
					String source = items[5];

					String domain = "Oncology";
					String dataset = "Lesion Measurement";
					String shortname = items[0];
					shortname = shortname.replaceAll(":", "_");
					String longname = items[1];
					String defintion = items[3];
					String datatype = "ANY";
					String unit = "NO_UNITS_SPECIFIED";
					String codelist = items[42];
					
					String objClses = items[20];
					String propClses = items[31];
					
					String vdContext = items[44];
					String vdType = items[46];
					if(vdType.equals("Non Enumerated")){
						codelist = "UNSPECIFIED";
					}
					
					String vdDatatype = items[47];
					
					sb.append(this.getDEDetailsHeader());
					sb.append(this.getLongName(longname, ""));
					sb.append(this.getShortName(shortname));
					sb.append(this.getDefinition(defintion));
					sb.append(this.getSourceName(source));
					sb.append(this.getDataType(vdDatatype));
					sb.append(this.getUnit(unit));
					sb.append(this.getDatasetName(dataset, domain, "cadsr"));
					//sb.append(this.getDomainName(domain));
					sb.append(this.getDEDetailsTrailer());
					
					//valueset
					sb.append(this.getDEValuesetHeader());
					if(!codelist.equals("UNSPECIFIED")){
						sb.append(this.getDEValueset(codelist, vdContext));
						SimpleArticle savs = new SimpleArticle();
						
						//dataset added in page name
						savs.setLabel(vdContext + " " + codelist + " Value Set");
						savs.setText("{{CSHARE_Value_Set}}\n");
						ret.add(savs);
					}
					sb.append(this.getDEValuesetTrailer());
					
					//concept reference
					sb.append(this.getDEConceptReferenceHeader());
					sb.append(this.getDEConceptReference(objClses, "objectClass"));
					sb.append(this.getDEConceptReference(propClses, "property"));
					
					sb.append(this.getDEConceptReferenceTrailer());
					
					//this.addDataSetPage(source, dataset);
					SimpleArticle sa = new SimpleArticle();
					
					//dataset added in page name
					sa.setLabel(source + "_" + dataset + "_" + longname);
					sa.setText(sb.toString());
					ret.add(sa);
					//if(index > 5) break;
					index++;
					}
					}
				}
			
				nextline = reader.readNext();

			}
			//br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}
	
	

	
	private void addDataSetPage(String source, String dataset){
		SimpleArticle sa = new SimpleArticle();
		sa.setLabel("Category:" + source + "_" + dataset);
		sa.setText("[[Category:CSHARE_" + dataset + "]]\n");
		if(!this.colDataSetPages.contains(sa)){
			this.colDataSetPages.add(sa);
		}
		SimpleArticle sa_de = new SimpleArticle();
		sa_de.setLabel("Category:" + source + "_Data_Element");
		sa_de.setText("[[Category:CSHARE_Data_Element]]\n");
		if(!this.colDataSetPages.contains(sa_de)){
			this.colDataSetPages.add(sa_de);
		}		
	}
	
	private String getDataElementFilterSourceDataset(String source, String dataset){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementFilterForSourceAndDataset|1=" +  source + 
				"|2=Oncology_" +  dataset + "}}\n");
		
		return sb.toString();
	}
	
	private String getLongName(String text, String supertext){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementLongName|1=" + text + "|2=" + supertext + "}}\n");
		return sb.toString();
	}
	
	private String getShortName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementShortName|1=" + text + "}}\n");
		return sb.toString();
	}

	private String getDataType(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDataType|1=DT_" + text + "}}\n");
		return sb.toString();
	}
	
	private String getUnit(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementUnit|1=" + text + "}}\n");
		return sb.toString();
	}	
	
	private String getDefinition(String text){
		StringBuffer sb = new StringBuffer();
		text = text.replaceAll("\\[", "(");
		text = text.replaceAll("\\]", ")");
		sb.append("{{CSHARE_DataElementDefinition|1=" + text + "}}\n");
		return sb.toString();
	}	

	private String getSourceName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementSourceName|1=" + text + "}}\n");
		return sb.toString();
	}		

	private String getDatasetName(String text, String domain, String cadsr){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDatasetName|1=" + text + 
				"|2=" + domain + "|3=" + cadsr +
		     "}}\n");
		return sb.toString();
	}		
/*	
	private String getDomainName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDomainName|1=" + text + "}}\n");
		return sb.toString();
	}
*/
	private String getDEDetailsHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDetailsHeader}}\n");
		return sb.toString();
	}	
	
	private String getDEDetailsTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDetailsTrailer}}\n");
		return sb.toString();
	}			
	
	private String getDEValuesetHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetHeader}}\n");
		return sb.toString();
	}			

	private String getDEValueset(String text, String source){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetBody|1=" + source + " " + text + " Value Set}}\n");
		return sb.toString();
	}			
	
	private String getDEValuesetTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetTrailer}}\n");
		return sb.toString();
	}			

	private String getDEConceptReferenceHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceHeader}}\n");
		return sb.toString();
	}		

	private String getDEConceptReference(String clses, String flag){
		String[] items = clses.split(":");
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < items.length; i++){
			String cls = items[i];
			sb.append("{{CSHARE_DataElementConceptReferenceBody|1=" + cls + "|2=" + flag +  "}}\n");
			
		}
		return sb.toString();
	}		
	
	private String getDEConceptReferenceTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceTrailer}}\n");
		return sb.toString();
	}			
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenerateTemplateForCadsrDataElements model =
			new GenerateTemplateForCadsrDataElements();
		model.publishDataElementsToWiki();
		//model.publishDataElementFiltersToWiki();

	}

}
