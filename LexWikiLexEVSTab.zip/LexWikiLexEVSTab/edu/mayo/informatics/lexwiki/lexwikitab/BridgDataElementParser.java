package edu.mayo.informatics.lexwiki.lexwikitab;

import java.util.*;
import java.io.*;

public class BridgDataElementParser {
	
	
	final String fileName = "C:\\Temp\\bridg\\bridg22.txt";
	
	
	public void processAttributes(){
		
		Collection allclasses = this.getAllStaticClass();
		for(Iterator it = allclasses.iterator(); it.hasNext();){
			String clsname = (String) it.next();
			//System.out.println(clsname + ":");
			System.out.println(this.processAttributesForClass(clsname));
			
		}
		
	}
	
	public String processAttributesForClass(String clsname){
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;
		try{
			br = new BufferedReader(new FileReader(fileName));
			
			String line = br.readLine().trim();
			while(line != null){
				if(line.indexOf(clsname + " Attributes") >= 0){
					line = br.readLine().trim();
					line = br.readLine().trim();
					//line = br.readLine().trim();
					while(line.length() > 1){
						if(line.startsWith(" ")){
							String nextline = br.readLine();
							if(nextline.startsWith(" ")){
								System.out.println(clsname + "\t" + line);
								nextline += br.readLine();
								System.out.println(clsname + "\t" + nextline);
								
							}else{
								line += nextline;
								System.out.println(clsname + "\t" + line);
							}
							
						}
						line = br.readLine();
					}
					break;
				}
				
				line = br.readLine();
			}
			
			br.close();
			
			
			
		}catch(IOException io){
			io.printStackTrace();
		}
		
		
		
		return sb.toString();
		
	}
	
	public Collection getAllStaticClass(){
		Collection allclasses = new ArrayList();
		BufferedReader br = null;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while(!line.equals("//")){
				String[] items = line.split("\\t");
				//System.out.println("class: " + items[0]);
				allclasses.add(items[0]);
				line = br.readLine();
			}
			//System.out.println("class: " + allclasses.size());
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return allclasses;
	}
	
	
	
	public static void main(String[] args){
		BridgDataElementParser parser = new BridgDataElementParser();
		parser.processAttributes();
	}

}
