package edu.mayo.informatics.lexwiki.lexwikitab;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;
import java.net.URL;



public class GenerateTemplateForCshareConcept {

	private final String fileNameCon = "C:\\Temp\\cshare\\concepts1.txt";
	private final String fileNameVar = "C:\\Temp\\cshare\\concepts2.txt";
	private final String fileNameConCon = "C:\\Temp\\cshare\\concepts3.txt";
	
	//private final String fileName = "C:\\Temp\\bridg\\bridgattrs_01.txt"; 
	//private String urlstr = "http://bmidev3/cshare/index.php";
	private String urlstr = "http://informatics.mayo.edu/cshare/index.php";
	private String userName = "Guoqian";
	private String password = "guoqian0331";
	
	public void publishConceptsToWiki(){
		Collection des = this.processingConcepts();
		try{
			URL url = new URL(urlstr);
			//MediaWikiBot wikiBot = new MediaWikiBot(url);
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "cshare", "xTu$$9");
			wikiBot.login(userName, password);
			wikiBot.writeMultContent(des.iterator());
			//wikiBot.writeMultContent(this.colDataSetPages.iterator());
			System.out.println("publishing done: " + des.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
        
	}	
	
	private Collection processingConcepts(){
		Collection ret = new ArrayList();
		
		Map cons = this.getItemsFromFile(fileNameCon);
		Map conv = this.getItemsFromFile2(fileNameVar);
		Map conc = this.getItemsFromFile2(fileNameConCon);
		int index = 0;
		for(Iterator it = cons.keySet().iterator(); it.hasNext();){
			String code = (String) it.next();
			String[] items = (String[]) cons.get(code);
			StringBuffer sb = new StringBuffer();
			
			sb.append(this.getHeaderBasicData());
			sb.append(this.getConceptCode(code));
			sb.append(this.getPreferredName(items[4]));
			sb.append(this.getShortName(items[3]));
			sb.append(this.getLongName(items[4]));
			sb.append(this.getDefinition(items[1]));
			sb.append(this.getTrailerBasicData());
			sb.append(this.getHeaderProperties());
			sb.append(this.getProperty("hasType", items[2]));
			sb.append(this.getTrailerProperties());
			sb.append(this.getHeaderAssoications());
			sb.append(this.getParent());
			
			Collection attributes = this.getAttributes(code, conv);
			for(Iterator it1 = attributes.iterator(); it1.hasNext();){
				String attr = (String) it1.next();
				String[] attrs = attr.split("\\|");
				sb.append(this.getVariableinConcept(attrs[0], attrs[1]));
			}
			
			if(items[2].equals("Complex")){
			Collection components = this.getComponents(code, conc);
			for(Iterator it2 = components.iterator(); it2.hasNext();){
				String comp = (String) it2.next();
				String[] comps = comp.split("\\|");
				String[] consitems = (String[]) cons.get(comps[0]);
				sb.append(this.getConceptinConcept(consitems[4], comps[1]));
			}
			}
			
			String mapping = items[7];
			if(!items[7].equals("UNSPECIFIED")){
				if(mapping.indexOf("=") >= 0)
					sb.append(this.getBRIDGMapping(items[5], items[6], "PerformedObservation", "PerformedObservation.nameCode.CD.displayName", items[4]));
				else{
					sb.append(this.getBRIDGMapping(items[5], items[6], "", "", ""));
				
				}
			}
			
			sb.append(this.getTrailerAssoications());
			sb.append(this.getDefaultForm("VitalSigns"));
			
			SimpleArticle sa = new SimpleArticle();
			sa.setLabel("Concept:CSHARE " + items[4]);
			sa.setText(sb.toString());
			ret.add(sa);
			
			index++;
			//if(index > 0) break;
			
		}

		
		
		return ret;
	}
	
	private Collection getAttributes(String code, Map map){
		Collection ret = new ArrayList();
		Collection vars = (Collection) map.get(code);
		if(vars != null){
		for(Iterator it = vars.iterator(); it.hasNext();){
			String[] items = (String[]) it.next();
			ret.add(items[3] + "|" + items[2]);
		}
		}
		return ret;
	}
	
	private Collection getComponents(String code, Map map){
		Collection ret = new ArrayList();
		Collection vars = (Collection) map.get(code);
		for(Iterator it = vars.iterator(); it.hasNext();){
			String[] items = (String[]) it.next();
			ret.add(items[1] + "|" + items[2]);
		}
		return ret;
	}	
	
	private Map getItemsFromFile(String fileName){
		Map ret = new HashMap();
		BufferedReader br = null;
		try{
			
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while(line != null){
				String[] items = line.split("\\t");
				ret.put(items[0], items);
				
				line = br.readLine();
			}
			
			br.close();
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}
	
	private Map getItemsFromFile2(String fileName){
		Map ret = new HashMap();
		BufferedReader br = null;
		try{
			
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while(line != null){
				String[] items = line.split("\\t");

				if(ret.containsKey(items[0])){
					Collection vars = (Collection) ret.get(items[0]);
					vars.add(items);
					ret.put(items[0], vars);
				}else{
					Collection newvars = new ArrayList();
					newvars.add(items);
					ret.put(items[0], newvars);
				}

				
				line = br.readLine();
			}
			
			br.close();
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}	
	
	private String getDefaultForm(String ns) {
		return "<noinclude>[[has default form::Form:LexWiki " + ns + " Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "<noinclude>{{LexWiki Basic Data Header}}</noinclude>\n";
	}
	private String getTrailerBasicData() {
		return "<noinclude>{{LexWiki Basic Data Trailer}}</noinclude>\n";
	}
	private String getHeaderProperties() {
		return "{{LexWiki Concept Property Header}}</noinclude>\n";
	}
	private String getTrailerProperties() {
		return "<noinclude>{{LexWiki Concept Property Trailer}}</noinclude>\n";
	}
	private String getHeaderAssoications() {
		return "<noinclude>{{LexWiki Association Header}}</noinclude>\n";
	}
	private String getTrailerAssoications() {
		return "<noinclude>{{LexWiki Association Trailer}}</noinclude>\n";
	}

	
	private String getConceptCode(String code){
		StringBuffer sb = new StringBuffer();
		
		sb.append("{{LexWiki_Concept_Code|1=" + code + "}}\n");
		return sb.toString();
	}
	
	private String getPreferredName(String name){
		StringBuffer sb = new StringBuffer();
		
		sb.append("{{LexWiki_Preferred_Name|1=" + name + "}}\n");
		return sb.toString();
	}
	
	private String getShortName(String name){
		StringBuffer sb = new StringBuffer();		
		sb.append("{{LexWiki_Presentation|1=11179_shortName|2=" + name + "|source=CSHARE|language=ENG|label=true}}\n");
		return sb.toString();
	}

	private String getLongName(String name){
		StringBuffer sb = new StringBuffer();		
		sb.append("{{LexWiki_Presentation|1=11179_longName|2=" + name + "|source=CSHARE|language=ENG|label=true}}\n");
		return sb.toString();
	}	
	
	private String getDefinition(String name){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki_Definition|1=" + name + "}}\n");
		return sb.toString();
	}
	
	private String getProperty(String name, String value){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki_Concept_Property|1=" + name + "|2=" + value + "}}\n");
		return sb.toString();
	}
	
	
	private String getBRIDGMapping(String bridg, String ver, String obj, String attr, String value){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki_Association_bridg|1=hasBRIDGMapping|2=" + bridg + "_" + obj + "|3=" + attr + "|4=" + value +  "}}\n");
		return sb.toString();		
	}

	private String getParent(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki_Parent_woc|1=CSHARE_Proposed_Concept}}\n");
		return sb.toString();		
	}		
	
	private String getVariableinConcept(String target, String mo){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki_Association_cde|1=hasAttribute|2=CDE_Vital_Signs_" + target + "|mo=" + mo +  "}}\n");
		return sb.toString();		
	}	
	
	
	private String getConceptinConcept(String target, String mo){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki_Association_concept|1=hasComponent|2=CSHARE_" + target + "|mo=" + mo +  "}}\n");
		return sb.toString();		
	}	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenerateTemplateForCshareConcept model =
			new GenerateTemplateForCshareConcept();
		model.publishConceptsToWiki();
		//model.publishDataElementFiltersToWiki();

	}
	
}
