package edu.mayo.informatics.lexwiki.lexwikitab;

public class LexWikiTabProtegePanel {

}
