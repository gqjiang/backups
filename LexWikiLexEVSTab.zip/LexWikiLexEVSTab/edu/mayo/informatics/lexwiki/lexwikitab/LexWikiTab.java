package edu.mayo.informatics.lexwiki.lexwikitab;

import java.awt.*;
import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protegex.owl.model.*;


public class LexWikiTab extends AbstractTabWidget {
	
	private LexWikiTabLexGridPanel lexgridPanel;
	//private LexWikiTabProtegePanel protegePanel;
	
	private JTabbedPane tabbedPane;
	
	
	public LexWikiTab(){
	
		
	}
	
	public void initialize(){
		this.intiUI();
	}
	
	public void intiUI(){
		setLabel("LexWiki Tab");
		KnowledgeBase kb = getKnowledgeBase();
				
		tabbedPane = new JTabbedPane();

		lexgridPanel = new LexWikiTabLexGridPanel(kb);		
		tabbedPane.add("Lexgrid Format", lexgridPanel);
		
		//protegePanel = new LexWikiTabProtegePanel(kb);
		//tabbedPane.add("Protege Format", protegePanel);
		//setLayout(new BorderLayout());
		add(tabbedPane, BorderLayout.CENTER);
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		edu.stanford.smi.protege.Application.main(args);

	}

}

