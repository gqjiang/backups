package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


//import Protege-2000 API
import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.ui.*;

import conexp.core.*;

public class FormalAttributesFinder {

    private KnowledgeBase kb;
    private String clsName;

    private Collection formalObjects;
    private Collection allTemplateSlots;

    public FormalAttributesFinder(KnowledgeBase kb, String clsName) {
        this.kb = kb;
        this.clsName = clsName;
        formalObjects = getFormalObjects();
        allTemplateSlots = getAllTemplateSlots();
    }

    private Vector getSlotsWithBooleanType(){
        Vector results = new Vector();
        Iterator it = allTemplateSlots.iterator();
        while(it.hasNext()){
            Slot slot = (Slot) it.next();
            if(slot.getValueType() == ValueType.BOOLEAN){
                results.add(slot.getBrowserText());
            }
        }
        return results;
    }

    private Vector getSlotsWithMultipleInstanceType(){
        Vector results = new Vector();
        Iterator it = allTemplateSlots.iterator();
        while(it.hasNext()){
            Slot slot = (Slot) it.next();
            if(slot.getValueType() == ValueType.INSTANCE &&
               slot.getAllowsMultipleValues()){
                results.add(slot.getBrowserText());
            }
        }
        return results;
    }

    public String[] getPossibleFormatAttributesForBoolean(){
        Vector slots = this.getSlotsWithBooleanType();
        String[] results = new String[slots.size()];
        slots.copyInto(results);
        return results;
    }

    public String[] getPossibleFormalAttributesForMultiple(){
        Vector slots = this.getSlotsWithMultipleInstanceType();
        String[] results = new String[slots.size()];
        slots.copyInto(results);
        return results;
    }

    public Collection getFormalObjects(){
        Cls cls = kb.getCls(clsName);
        Collection instances = cls.getDirectInstances();
        return instances;
    }

    public Collection getSubClses(){
      Cls cls = kb.getCls(clsName);
      Collection clses = cls.getDirectSubclasses();
      return clses;
    }

    private Collection getAllTemplateSlots(){
        Cls cls = kb.getCls(clsName);
        Collection templateSlots = cls.getTemplateSlots();
        return templateSlots;
    }

}















