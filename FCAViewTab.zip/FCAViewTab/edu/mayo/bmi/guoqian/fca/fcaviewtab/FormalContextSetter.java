package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;

public class FormalContextSetter {

  private FormalContextAdapter adapter;
  private KnowledgeBase kb;

  public FormalContextSetter(KnowledgeBase kb,
                             Collection objects,
                             String[] attributes,
                             int typeIndex,
                             String insstr) {
    this.kb = kb;
    adapter = new FormalContextAdapter();
    if (typeIndex == 0) {
      this.setContextForBoolean(objects, attributes);
    }
    else if (typeIndex == 1) {
      this.setContextForMultiple(objects, attributes);
    }else if (typeIndex == 2){
      this.setContextForSubclassBoolean(objects, attributes, insstr);
    }else if (typeIndex == 3){
      this.setContextForSubClassMultiple(objects, attributes, insstr);
    }
  }

  private void setContextForBoolean(Collection objects, String[] attributes) {
    Iterator it = objects.iterator();
    while (it.hasNext()) {
      Instance instance = (Instance) it.next();
      adapter.addFormalObject(instance);
      for (int i = 0; i < attributes.length; i++) {
        Slot slot = kb.getSlot(attributes[i]);
        adapter.addFormalAttribute(slot);
        Collection values = instance.getDirectOwnSlotValues(slot);
        if (!values.isEmpty()) {
          Boolean b = (Boolean) instance.getDirectOwnSlotValue(slot);
          if (b.booleanValue()) {
            adapter.setRelation(instance, slot);
          }
        }
      }
    }
  }

  private void setContextForMultiple(Collection objects, String[] attributes) {
    Iterator it = objects.iterator();
    while (it.hasNext()) {
      Instance instance = (Instance) it.next();
      adapter.addFormalObject(instance);
      for (int i = 0; i < attributes.length; i++) {
        Slot slot = kb.getSlot(attributes[i]);
        Collection values = instance.getDirectOwnSlotValues(slot);
        if (!values.isEmpty()) {
          Iterator itv = values.iterator();
          while (itv.hasNext()) {
            Instance slotIns = (Instance) itv.next();
            adapter.addFormalAttribute(slotIns);
            adapter.setRelation(instance, slotIns);
          }
        }
      }
    }

  }

  private void setContextForSubclassBoolean(Collection objects,
                                            String[] attributes,
                                            String inskey) {
    Iterator it = objects.iterator();
    while (it.hasNext()) {
      Cls cls = (Cls) it.next();
      adapter.addFormalObject(cls);
      Collection instances = cls.getDirectInstances();
      Iterator it1 = instances.iterator();
      while (it1.hasNext()) {
        Instance instance = (Instance) it1.next();
        if (instance.getBrowserText().equals(inskey)) {
          for (int i = 0; i < attributes.length; i++) {
            Slot slot = kb.getSlot(attributes[i]);
            adapter.addFormalAttribute(slot);
            Collection values = instance.getDirectOwnSlotValues(slot);
            if (!values.isEmpty()) {
              Boolean b = (Boolean) instance.getDirectOwnSlotValue(slot);
              if (b.booleanValue()) {
                adapter.setRelation(cls, slot);
              }
            }
          }
        }
      }
    }
  }

  private void setContextForSubClassMultiple(Collection objects,
                                             String[] attributes,
                                             String inskey) {
    Iterator it = objects.iterator();
    while (it.hasNext()) {
      Cls cls = (Cls) it.next();
      adapter.addFormalObject(cls);
      Collection instances = cls.getDirectInstances();
      Iterator it1 = instances.iterator();
      while (it1.hasNext()) {
        Instance instance = (Instance) it1.next();
        if (instance.getBrowserText().equals(inskey)) {
          for (int i = 0; i < attributes.length; i++) {
            Slot slot = kb.getSlot(attributes[i]);
            adapter.addFormalAttribute(slot);
            Collection values = instance.getDirectOwnSlotValues(slot);
            if (!values.isEmpty()) {
              Iterator itv = values.iterator();
              while (itv.hasNext()) {
                Instance slotIns = (Instance) itv.next();
                adapter.addFormalAttribute(slotIns);
                adapter.setRelation(cls, slotIns);
              }
            }
          }
        }
      }
    }
  }

  public FormalContextAdapter getContextAdapter() {
    return this.adapter;
  }
}
