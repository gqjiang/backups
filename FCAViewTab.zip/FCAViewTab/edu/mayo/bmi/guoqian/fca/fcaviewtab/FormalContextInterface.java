package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontology building using formal concept analysis </p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

//import the Protege API
import edu.stanford.smi.protege.model.*;

public abstract class FormalContextInterface {

  public abstract void addFormalObject(Instance object);
  public abstract void addFormalAttribute(Slot attribute);
  public abstract void setRelation(Instance object, Slot attribute);
}
