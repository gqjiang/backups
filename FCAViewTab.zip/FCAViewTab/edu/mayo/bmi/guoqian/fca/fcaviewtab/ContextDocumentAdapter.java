package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;

import conexp.core.*;
import conexp.frontend.*;
import conexp.frontend.latticeeditor.*;

public class ContextDocumentAdapter
    extends ContextDocument {
  private Context context;
  //private LatticeDrawingAdapter
      //lnkLatticeDrawingAdapter;

  public ContextDocumentAdapter(Context context) {
    super(context);
    this.context = context;
  }

  public void activateLatticeView() {
    //super.getLatticeComponent().calculateAndLayoutPartialLattice();
    super.getOrCreateDefaultLatticeComponent().calculateAndLayoutLattice();
    super.activateView(this.VIEW_LATTICE);
  }

  public JPanel getOptionPane() {
    JPanel leftPanel = new JPanel();
    LatticeDrawingAdapter drawAdapter = new LatticeDrawingAdapter();
    leftPanel.setLayout(new BorderLayout());
    LatticeDrawingOptions drawingOptions = new LatticeDrawingOptions();

    PainterOptionsPaneEditor optionPane = new PainterOptionsPaneEditor(
        //this.getLatticeComponent().
    	this.getOrCreateDefaultLatticeComponent().getDrawing().getPainterOptions(),
        drawingOptions.getEditableDrawingOptions(),
        drawAdapter.getParams());

//    OptionPaneViewChangeListener viewlistener = new OptionPaneViewChangeListener(optionpane);
//    this.addViewChangeListener(viewlistener);

    leftPanel.add(optionPane, BorderLayout.CENTER);
    return leftPanel;

  }

  public Context getContext() {
    return this.context;
  }

}
