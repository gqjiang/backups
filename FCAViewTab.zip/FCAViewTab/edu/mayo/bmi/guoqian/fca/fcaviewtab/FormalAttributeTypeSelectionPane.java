package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FormalAttributeTypeSelectionPane
    extends JDialog implements ActionListener {

  private JLabel attrLabel;
  private JLabel objLabel;

  private JRadioButton jrbBoolean;
  private JRadioButton jrbMultiple;

  private JRadioButton jrbTheClass;
  private JRadioButton jrbSubClass;
  private JRadioButton jrbInsSubClass;

  private ButtonGroup bg;
  private ButtonGroup bgClass;

  private JButton btnOK;

  private int typeIndex;

  public FormalAttributeTypeSelectionPane() {

    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      initUI();
      this.setSize(400, 300);
      this.setResizable(true);
      this.setTitle("Type Selection...");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void initUI() throws Exception {
    this.getContentPane().setLayout(new BorderLayout());
    attrLabel = new JLabel("  Attribute Type: ");
    objLabel = new JLabel("  Object Type: ");

    jrbBoolean = new JRadioButton("Slots with Boolean Type");
    jrbBoolean.setSelected(true);
    jrbMultiple = new JRadioButton("Slots with Multiple Instance Type");
    bg = new ButtonGroup();
    bg.add(jrbBoolean);
    bg.add(jrbMultiple);

    jrbTheClass = new JRadioButton("Instances of the Selected Class");
    jrbTheClass.setSelected(true);
    jrbSubClass = new JRadioButton("Subclasses of the Selected Class");
//    jrbInsSubClass = new JRadioButton("Instances of the Subclass");
    bgClass = new ButtonGroup();
    bgClass.add(jrbTheClass);
    bgClass.add(jrbSubClass);
//    bgClass.add(jrbInsSubClass);

    JPanel jrbAttrPanel = new JPanel(new GridLayout(2, 1));
    jrbAttrPanel.add(jrbBoolean);
    jrbAttrPanel.add(jrbMultiple);



    JPanel jrbClassPanel = new JPanel(new GridLayout(2,1));
    jrbClassPanel.add(jrbTheClass);
    jrbClassPanel.add(jrbSubClass);
//    jrbClassPanel.add(jrbInsSubClass);

    JPanel upperPanel = new JPanel(new BorderLayout());
    upperPanel.add(objLabel, BorderLayout.NORTH);
    upperPanel.add(jrbClassPanel, BorderLayout.CENTER);

    JPanel bottomPanel = new JPanel(new BorderLayout());
    bottomPanel.add(attrLabel, BorderLayout.NORTH);
    bottomPanel.add(jrbAttrPanel, BorderLayout.CENTER);

    JPanel jrbPanel = new JPanel(new GridLayout(2,1));
    jrbPanel.add(upperPanel);
    jrbPanel.add(bottomPanel);

    btnOK = new JButton("OK...");
    btnOK.addActionListener(this);
    JPanel okPanel = new JPanel();
    okPanel.add(btnOK);

    this.getContentPane().add(jrbPanel, BorderLayout.CENTER);
    this.getContentPane().add(okPanel, BorderLayout.SOUTH);
  }

  //�E�B���h�E������ꂽ�Ƃ��ɏI������悤�ɃI�[�o�[���C�h
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  //�_�C�A���O�����
  void cancel() {
    dispose();
  }

  public void actionPerformed(ActionEvent e) {
    Object s = e.getSource();

    if (s == btnOK) {

      if (jrbTheClass.isSelected() && jrbBoolean.isSelected()) {
        typeIndex = 0;
      }
      if (jrbTheClass.isSelected() && jrbMultiple.isSelected()) {
        typeIndex = 1;
      }

      if (jrbSubClass.isSelected() && jrbBoolean.isSelected()) {
        typeIndex = 2;
      }

      if (jrbSubClass.isSelected() && jrbMultiple.isSelected()) {
        typeIndex = 3;
      }
/*
      if (jrbInsSubClass.isSelected() && jrbBoolean.isSelected()) {
       typeIndex = 4;
     }
     if (jrbInsSubClass.isSelected() && jrbMultiple.isSelected()) {
       typeIndex = 5;
     }
*/

    }

    cancel();
  }

  public int getTypeIndex() {
    return typeIndex;
  }

}
