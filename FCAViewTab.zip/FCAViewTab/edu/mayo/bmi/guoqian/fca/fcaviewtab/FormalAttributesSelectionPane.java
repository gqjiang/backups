package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class FormalAttributesSelectionPane
    extends JDialog implements ActionListener  {


  private JLabel listLabel;

  private JList itemList;
  private Object[] listData;
  private JScrollPane scrollPane;

  private JButton btnOK;
  private JButton btnSelectAll;
  private JPanel btnPanel;

  private CheckBoxListModel cblm;
  private CheckBoxCellRenderer cbcr;

  private String[] selectedItems = null;

  private String label;

  public FormalAttributesSelectionPane(Object[] listData) {
     this.listData = listData;
    Arrays.sort(listData);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      initUI();
      this.setSize(300,600);
      this.setTitle("Select Attributes...");
      this.label = "  Possible Attributes: ";
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public FormalAttributesSelectionPane(Object[] listData,
                                       String title,
                                       String label){
    this.listData = listData;

    Arrays.sort(listData);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      this.setTitle(title);
      this.label = label;
      initUI();
      this.setSize(300,600);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void initUI() throws Exception{
    this.getContentPane().setLayout(new BorderLayout());
    listLabel = new JLabel(label);

    cblm = new CheckBoxListModel();
    for(int i=0; i < listData.length; i++)
      cblm.addElement(listData[i]);

    cbcr = new CheckBoxCellRenderer();

    itemList = new JList();

    itemList.addMouseListener(new ListChecker(itemList, cbcr));
    itemList.setModel(cblm);
    itemList.setCellRenderer(new CheckBoxCellRenderer());
    itemList.setFont(new Font(null));
    scrollPane = new JScrollPane();
    scrollPane.getViewport().add(itemList);
    scrollPane.setVisible(true);

    btnOK = new JButton("Confirm...");
    btnOK.addActionListener(this);
    JPanel okPanel = new JPanel();
    okPanel.add(btnOK);

    btnSelectAll = new JButton("Select All...");
    btnSelectAll.addActionListener(this);
    JPanel selectPanel = new JPanel();
    selectPanel.add(btnSelectAll);

    btnPanel = new JPanel(new GridLayout(1,2));
    btnPanel.add(selectPanel);
    btnPanel.add(okPanel);


    this.getContentPane().add(listLabel, BorderLayout.NORTH);
    this.getContentPane().add(scrollPane, BorderLayout.CENTER);
    this.getContentPane().add(btnPanel, BorderLayout.SOUTH);
  }

  //�E�B���h�E������ꂽ�Ƃ��ɏI������悤�ɃI�[�o�[���C�h
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }
  //�_�C�A���O�����
  void cancel() {
    dispose();
  }

  public void actionPerformed(ActionEvent e){
    Object s = e.getSource();
    if(s == btnSelectAll){
      for(int i=0; i < listData.length; i++){
        cblm.setSelectedAt(i, true);
      }
      itemList.repaint();
    }
    if(s == btnOK){
      Vector vecItems = new Vector();
      for(int i = 0; i < listData.length; i++){
        if(cblm.isSelectedAt(i)){
          vecItems.add(listData[i]);
        }
      }
      if(vecItems != null){
        selectedItems = new String[vecItems.size()];
        vecItems.copyInto(selectedItems);
      }
      cancel();

    }

  }

  public String[] getSelectedItems(){
    return selectedItems;
  }

  /**
   * This class is from
   * @version 1.0.1 2002-01-26
   * @author Takashi KOBAYASHI
   */

  class ListChecker extends MouseAdapter {
    private JList jl;
    private CheckBoxCellRenderer ccr;

    public ListChecker( JList l, CheckBoxCellRenderer c ) {
      jl = l;
      ccr = c;
    }

    public void mouseClicked( MouseEvent e ) {
      Point p = e.getPoint();
      int idx = jl.locationToIndex( p );
      CheckBoxListModel clm = (CheckBoxListModel)jl.getModel();
      try {
        if( idx > -1 && idx < jl.getModel().getSize()
            && clm.getElementAt( idx ) != null
            && clm.isEnabledAt( idx )
            && (e.getModifiers() & InputEvent.BUTTON1_MASK) != 0
            && (
            ccr.isInCheckBox( toLocationInCell( p ), clm.getElementAt( idx ).toString() )
            || e.getClickCount() == 2
            )
            ) {
          clm.setSelectedAt( idx, ! clm.isSelectedAt( idx ) );
          jl.repaint();
        }
      }
      catch( NoSuchElementException exp ) {}
    }

    private Point toLocationInCell( Point p ) {
      int idx = jl.locationToIndex( p );

      if( idx == 0 ){
        return p;
      }
      else {
        Rectangle r = jl.getCellBounds( 0, idx - 1 );
        return new Point( p.x, p.y - r.height );
      }
    }
  }


  /**
   * This class is from
   * @version 1.0.1 2002-01-26
   * @author Takashi KOBAYASHI
   */

  class CheckBoxCellRenderer extends JPanel implements ListCellRenderer {
    JCheckBox jcb;
    Border noFocusBorder;

    public CheckBoxCellRenderer() {
      super();
      noFocusBorder = new EmptyBorder(1, 1, 1, 1);
      setOpaque(true);
      setBorder(noFocusBorder);
      setLayout( new BorderLayout() );

      jcb = new JCheckBox();

      add( jcb, BorderLayout.WEST );
    }

    public Component getListCellRendererComponent(
        JList list,
        Object value,
        int index,
        boolean isSelected,
        boolean cellHasFocus )
    {
      CheckBoxListModel clm = (CheckBoxListModel)list.getModel();
      jcb.setText( value.toString() );
      try{
        jcb.setSelected( clm.isSelectedAt( index ) );
        jcb.setEnabled( clm.isEnabledAt( index ) );
      }
      catch( NoSuchElementException e ) {}

      if( isSelected ) {
        jcb.setBackground( list.getSelectionBackground() );
        setBackground( list.getSelectionBackground() );
        setForeground( list.getSelectionForeground() );
      }
      else {
        jcb.setBackground( list.getBackground() );
        setBackground( list.getBackground() );
        setForeground( list.getForeground() );
      }
      setEnabled(list.isEnabled());
      setFont(list.getFont());
      setBorder(
          (cellHasFocus)
          ? UIManager.getBorder( "List.focusCellHighlightBorder" )
          : noFocusBorder
          );
      return this;
    }

    public boolean isInCheckBox( Point p, String cellText ) {
      jcb.setText( cellText );
      return jcb.contains( p );
    }
  }

  /**
   * This class is from
   * @version 1.0.1 2002-01-26
   * @author Takashi KOBAYASHI
   */

  class CheckBoxListModel extends DefaultListModel {
    private Vector selected, enabled;
    private boolean defaultSelected;
    private boolean defaultEnabled;

    public CheckBoxListModel() {
      super();
      selected = new Vector();
      enabled = new Vector();

      defaultSelected = false;
      defaultEnabled = true;
    }

//-------------------- getter/setter

    public void setDefaultChecked( boolean state ) {
      defaultSelected = state;
    }

    public boolean getDefaultChecked() {
      return defaultSelected;
    }

    public void setDefaultEnabled( boolean state ) {
      defaultEnabled = state;
    }

    public boolean getDefaultEnabled() {
      return defaultEnabled;
    }

    public boolean isSelectedAt( int index ) {
      Object obj = selected.get( index );
      if( obj == null ) {
        throw new NoSuchElementException();
      }
      return ( (Boolean)obj ).booleanValue();
    }

    public void setSelectedAt( int index, boolean selected ) {
      if( get( index ) == null ) {
        throw new NoSuchElementException();
      }
      this.selected.set( index, new Boolean( selected ) );
    }


    public boolean isEnabledAt( int index ) {
      Object obj = enabled.get( index );
      if( obj == null ) {
        throw new NoSuchElementException();
      }
      return ( (Boolean)obj ).booleanValue();
    }

    public void setEnabledAt( int index, boolean enabled ) {
      if( get( index ) == null ) {
        throw new NoSuchElementException();
      }
      this.enabled.set( index, new Boolean( enabled ) );
    }

//-------------------- new apllicable

    public synchronized void add( int index, Object obj, boolean selected ) {
      this.selected.add( index, new Boolean( selected ) );
      this.enabled.add( index, new Boolean( defaultEnabled ) );
      super.add( index, obj );
    }

    public synchronized void addElement( Object obj, boolean selected ) {
      add( getSize(), obj, selected );
    }

//-------------------- for compatibility

    public synchronized void add( int index, Object obj ) {
      add( index, obj, defaultSelected );
    }

    public synchronized void addElement( Object obj ) {
      addElement( obj, defaultSelected );
    }

    public synchronized void clear() {
      selected.clear();
      enabled.clear();
      super.clear();
    }

    public synchronized void insertElementAt( Object obj, int index ) {
      add( index, obj );
    }

    public synchronized Object remove( int index ) {
      selected.remove( index );
      enabled.remove( index );
      return super.remove( index );
    }

    public synchronized void removeAllElements() {
      selected.removeAllElements();
      enabled.removeAllElements();
      super.removeAllElements();
    }

    public synchronized boolean removeElement( Object obj ) {
      int i = indexOf( obj );
      selected.removeElementAt( i );
      enabled.removeElementAt( i );
      return super.removeElement( obj );
    }

    public synchronized void removeElementAt( int index ) {
      remove( index );
    }

    public synchronized void removeRange( int fromIndex, int toIndex ) {
      for(int i = toIndex; i >= fromIndex; i--) {
        selected.removeElementAt( i );
        enabled.removeElementAt( i );
        super.removeElementAt( i );
      }
      fireIntervalRemoved(this, fromIndex, toIndex);
    }

    public synchronized Object set(int index, Object element) {
      selected.setElementAt( new Boolean( defaultSelected ), index );
      enabled.setElementAt( new Boolean( defaultEnabled ), index );
      return super.set( index, element );
    }

    public synchronized void setElementAt(Object obj, int index) {
      set( index, obj );
    }

    public synchronized void setSize( int newSize ) {
      selected.setSize( newSize );
      enabled.setSize( newSize );
      super.setSize( newSize );
    }

    public synchronized void trimToSize() {
      selected.trimToSize();
      enabled.trimToSize();
      super.trimToSize();
    }
  }

}
