package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;


//import the concept explorer API
import conexp.core.*;
import conexp.frontend.*;
import conexp.frontend.components.LatticeComponent;

import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class FormalLatticeComponentPanel extends JPanel{

  private Context context;
  private ContextDocumentAdapter doc;


  public FormalLatticeComponentPanel(Context context) {
    this.context = context;
    this.initUI();
  }

  public ContextDocument getContextDocument(){
    return doc;
  }

  private void initUI(){
    doc = new ContextDocumentAdapter(context);

    Component lattice = doc.getDocComponent();
    JPanel leftPanel = new JPanel();
    leftPanel = doc.getOptionPane();
    OptionPaneViewChangeListener viewlistener =
        new OptionPaneViewChangeListener(leftPanel);
    doc.addViewChangeListener(viewlistener);
    doc.activateViews();

    JPanel rightPanel = new JPanel();
    rightPanel.setLayout(new BorderLayout());
    rightPanel.add(doc.getToolBar(), BorderLayout.NORTH);
    rightPanel.add(new JScrollPane(lattice), BorderLayout.CENTER);

    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                                          true,
                                          leftPanel,
                                          rightPanel);
    splitPane.setOneTouchExpandable(true);

    this.setLayout(new BorderLayout());
    this.add(splitPane, BorderLayout.CENTER);

  }
}
