package edu.mayo.bmi.guoqian.fca.owlfcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */


import java.awt.*;
import javax.swing.*;
import javax.swing.JTabbedPane;


//import Protege-2000 API
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protegex.owl.model.*;
//import edu.stanford.smi.protegex.owl.ui.widget.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;


public class OWLFCAViewTab extends AbstractTabWidget {

  private JTabbedPane tabbedPane = new JTabbedPane();

  private OWLFCAViewPanel fcaViewPanel;

  private NormalFormTransformPanel nftPanel;

 // private UseCaseTesttPanel1 testPanel1;


  public OWLFCAViewTab(){

  }

  public void initialize(){

    //this.initUIGeneral();
    this.initUISpecial();

  }

  private void initUIGeneral(){
    setLabel("OWLFCAView Tab");

    OWLModel kb = (OWLModel) getKnowledgeBase();
    fcaViewPanel = new OWLFCAViewPanel(kb);

    JScrollPane fcaScrollPane = new JScrollPane();

    //fcaScrollPane.getViewport().add(fcaViewPanel, null);

    setLayout(new BorderLayout());
    add(fcaViewPanel, BorderLayout.CENTER);
  }

  private void initUISpecial(){
    setLabel("OWLFCAView Tab");

    OWLModel kb = (OWLModel) getKnowledgeBase();
    fcaViewPanel = new OWLFCAViewPanel(kb);

    JScrollPane fcaScrollPane = new JScrollPane();

    fcaScrollPane.getViewport().add(fcaViewPanel, null);
    tabbedPane.add("FCAView", fcaViewPanel);

    nftPanel = new NormalFormTransformPanel(kb);
    tabbedPane.add("Normal Form Transform", nftPanel);

    //testPanel1 = new UseCaseTesttPanel1(kb);
    //tabbedPane.add("Use Cases Test", testPanel1);

    setLayout(new BorderLayout());
    add(tabbedPane, BorderLayout.CENTER);
  }

  public static void main(String[] args){
    edu.stanford.smi.protege.Application.main(args);
  }
}
