package edu.mayo.bmi.guoqian.fca.sct;


/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */
import java.util.Iterator;
import java.util.Collection;
import edu.stanford.smi.protegex.owl.model.OWLRestriction;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import java.util.ArrayList;
import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class NormalFormDisplayForTerms extends NormalFormTransformModel{

  private StringBuffer sb = new StringBuffer();

  private OWLModel kb;
  private OWLNamedClass clsgeneral;

  private Collection colWithPrimitive = new ArrayList();

  public NormalFormDisplayForTerms(OWLModel kb, OWLNamedClass cls) {
    this.kb = kb;
    this.clsgeneral = cls;
    this.getAllDefiningRelationships(clsgeneral);
    normalForm = sb.toString();

  }

  private void getAllDefiningRelationships(OWLNamedClass cls){
    String superType = this.getProximalPrimitiveSuperType(cls);
    sb.append(superType + "\n");
    nForm.put(superType);
    Collection restrictions = cls.getRestrictions();
    Iterator it = restrictions.iterator();
    while(it.hasNext()){
      OWLRestriction restriction = (OWLRestriction) it.next();
      RDFProperty onProperty = restriction.getOnProperty();
      String onPropText = onProperty.getBrowserText();

      //dealing with RoleGroup property
      if(onPropText.equals("RoleGroup")){

        String parsable = restriction.getParsableExpression();
        this.getRoleGroupAllDefiningRelationships1(parsable);

      }else{//dealing with non Rolegroup property

        String fillerText = restriction.getFillerText();
        OWLNamedClass fillerCls = kb.getOWLNamedClass(fillerText);
        //dealing with a defined class
        if(fillerCls.isDefinedClass()){
          sb.append(onPropText + " = ");
          nForm.put(onPropText, "RESERVED");
          this.getAllDefiningRelationships(fillerCls);
        }else{//dealing with a primitive class
          sb.append(onPropText + " = " + fillerText + "\n");
          nForm.put(onPropText, fillerText);

        }
      }
    }

  }


  private void getRoleGroupAllDefiningRelationships1(String parsable){
    String substr1 = parsable.substring(16);

    String[] pairs = substr1.split("&");
    for(int i = 0; i < pairs.length; i++){

      //deal with first pair
      if(i == 0) {
        int len1 = pairs[i].length();
        String substr11 = pairs[i].substring(0, len1-2);
        String[] firstpart = substr11.split(" ");
        this.printRoleGroup(firstpart[0], firstpart[1]);
      }else if(i == pairs.length-1){
        int len3 = pairs[i].length();
        String substr3 = pairs[i].substring(4,len3-2);
        String[] lastpart = substr3.split(" ");
        this.printRoleGroup(lastpart[0], lastpart[1]);

      }else{

        //deal with middle pairs
        int len2 = pairs[i].length();
        String substr2 = pairs[i].substring(4, len2 - 2);
        String[] secondpart = substr2.split(" ");
        this.printRoleGroup(secondpart[0], secondpart[1]);
      }

    }
  }

  private void getRoleGroupAllDefiningRelationships(String parsable){

    String substr1 = parsable.substring(16);
    int index1 = substr1.indexOf(")");
    String substr11 = substr1.substring(0, index1);

    int index2 = index1 + 7;
    String substr12 = substr1.substring(index2);

    int substr12len = substr12.length();
    String substr121 = substr12.substring(0, substr12len-2);

    String[] firstparts = substr11.split(" ");
    this.printRoleGroup(firstparts[0], firstparts[1]);

    String[] secondparts = substr121.split(" ");
    this.printRoleGroup(secondparts[0], secondparts[1]);

  }

  private void printRoleGroup(String first, String second){
    OWLNamedClass cls = kb.getOWLNamedClass(second);
    if(cls.isDefinedClass()){
      sb.append(first + " = ");
      nForm.put(first, "RESERVED");
      this.getAllDefiningRelationships(cls);
    }else{
      sb.append("    " + first + " = " + second + "\n");
      nForm.put(first, second);
    }

  }

  private String getProximalPrimitiveSuperType(OWLNamedClass cls){
    String ret = "";
    if(cls.isDefinedClass()){
      Collection superClses =  cls.getNamedSuperclasses(false);
      int loop = this.getCollectionWithPrimitive(superClses);
      String superType = this.getPrimitiveBrowserText(colWithPrimitive);
      //System.out.println("Debug: " + loop + ": " + superType);

      ret = superType;
    }else{
      ret = cls.getBrowserText();
    }

    return ret;
  }

  private String getPrimitiveBrowserText(Collection superClses){
    String ret = "";
    //System.out.println("enter: " + superClses.size());
    Iterator it = superClses.iterator();
    while(it.hasNext()){
      OWLNamedClass superCls = (OWLNamedClass) it.next();

      if(!superCls.isDefinedClass()){
        ret = superCls.getBrowserText();
        //System.out.println("primitive name:" + ret);
        break;
      }
      //System.out.println("defined name: " + superCls.getBrowserText());
    }
    return ret;
  }

  //recursive to get a collection with primitive
  private int getCollectionWithPrimitive(Collection superClses){

    int loop = 0;

    if(!this.hasPrimitiveClass(superClses)) {
      //System.out.println("loop: " + loop++);
      Collection upperOne = this.getCollectionOfAllSuperClses(superClses);
      getCollectionWithPrimitive(upperOne);
    }

    return loop;

  }

  private boolean hasPrimitiveClass(Collection superClses){
    boolean flag = false;
    Iterator it = superClses.iterator();
    while(it.hasNext()){
      OWLNamedClass superCls = (OWLNamedClass) it.next();
      if(!superCls.isDefinedClass()){

        flag = true;
        colWithPrimitive = superClses;
        //System.out.println("defined concept:" + superCls.getBrowserText());
        break;
      }
    }

    //System.out.println("return value: " + flag);

    return flag;
  }

  private Collection getCollectionOfAllSuperClses(Collection clses){
    Collection ret = new ArrayList();
    Iterator it = clses.iterator();
    while(it.hasNext()){
      OWLNamedClass cls = (OWLNamedClass) it.next();
      if(cls.hasNamedSuperclass()){
        Collection superCls = cls.getNamedSuperclasses(false);
        ret.addAll(superCls);
      }
    }
    return ret;
  }

}
