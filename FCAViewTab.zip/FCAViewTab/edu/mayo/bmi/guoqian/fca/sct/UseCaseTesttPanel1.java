package edu.mayo.bmi.guoqian.fca.sct;
/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.ui.clsproperties.*;
import edu.stanford.smi.protegex.owl.ui.widget.*;
import javax.swing.JSplitPane;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import conexp.core.*;
import conexp.frontend.*;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.filechooser.FileFilter;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;


public class UseCaseTesttPanel1 extends JPanel implements ActionListener{

  private OWLModel kb;

  private JButton btnStart;
  private JTextField textField;
  private JTextArea textArea;
  private JSplitPane splitPane;
  private JScrollPane scrollPane;

  public UseCaseTesttPanel1(OWLModel kb) {
    this.kb = kb;
    this.initUI();
  }

  private void initUI(){

    JLabel label = new JLabel("Domain document: ");
    textField = new JTextField(20);
    textField.setText("c:\\temp\\heartmurmur02.txt");
    btnStart = new JButton("Start...");
    btnStart.addActionListener(this);

    JPanel upperPanel = new JPanel(new BorderLayout());
    upperPanel.add(label, BorderLayout.NORTH);

    JPanel cUpperPanel = new JPanel();
    cUpperPanel.add(textField);
    cUpperPanel.add(btnStart);

    upperPanel.add(cUpperPanel, BorderLayout.CENTER);

    textArea = new JTextArea();
    JScrollPane scrollPane1 = new JScrollPane();
    scrollPane1.getViewport().add(textArea);
    JPanel centerPanel = new JPanel(new BorderLayout());
    centerPanel.add(scrollPane1, BorderLayout.CENTER);

    JPanel leftPanel = new JPanel(new BorderLayout());
    leftPanel.add(upperPanel, BorderLayout.NORTH);
    leftPanel.add(centerPanel, BorderLayout.CENTER);

    JPanel rightPanel = new JPanel();
    scrollPane = new JScrollPane();
    scrollPane.getViewport().add(rightPanel);
    //main pane to show left and right panel
    splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                              true,
                              leftPanel,
                              scrollPane);
    splitPane.setOneTouchExpandable(true);

    this.setLayout(new BorderLayout());
    this.add(splitPane, BorderLayout.CENTER);

  }

  public void actionPerformed(ActionEvent e){

    Object s = e.getSource();
    if(s== btnStart){
      this.actionPerformed1();

    }

  }

  private void actionPerformed1(){
    String fileName = textField.getText();
    Map map = this.getSentences(fileName);
    Context formalcontext = this.getContext(map);

    FormalLatticeComponentPanel latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

  }

  private Map getSentences(String fileName){
    Map ret = new HashMap();
    BufferedReader br = null;

    try{
      br = new BufferedReader(new FileReader(fileName));
      String line = br.readLine();
      int i=1;
      String linenum = "s";
      while(line != null){
        line = line.toLowerCase();
        textArea.append(line + "\n");
        String[] words = line.split(" ");
        //for(int j = 0; j < words.length; j++){
          //textArea.append(words[j] + "|");
        //}
        //textArea.append("\n");
        linenum = "s" + i;
        //textArea.append(linenum + "\n");
        ret.put(linenum, words);
        i++;
        line = br.readLine();
      }

      br.close();
    }catch(IOException ie){
      ie.printStackTrace();
    }
    return ret;
  }

  private Context getContext(Map map){
    UseCaseTestContextSetter setter = new UseCaseTestContextSetter(1, map);
    FormalContextAdapter adapter = setter.getContextAdapter();
    return adapter.getContext();
  }
  }
