package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class NormalFormTableModel extends AbstractTableModel{

  private Collection clses;
  private OWLModel kb;
  private String[] columns;
  private String[] rows;

  public NormalFormTableModel(OWLModel kb, Collection clses) {
    this.kb = kb;
    this. clses = clses;
    this.columns = this.getColumns();
    this.rows = this.getRows();
  }

  public int getRowCount(){
    return clses.size();
  }

  public int getColumnCount(){
    return columns.length;
  }

  public Object getValueAt(int row, int col){
    String value = null;
    String _clsName = rows[row];
    if(col == 0){
      value = _clsName;
    }else{
      OWLNamedClass _cls = kb.getOWLNamedClass(_clsName);
      NormalForm _nForm = this.getNormalForm(_cls);
      String _key = columns[col];
      if (_nForm.getKeys().contains(_key)) {
        value = _nForm.getValue(columns[col]);
      }
      else {
        value = "NONE";
      }
    }
    return value;
  }

  public String getRowName(int row){
    return rows[row];
  }

  public String getColumnName(int col){
    return columns[col];
  }

  private NormalForm getNormalForm(OWLNamedClass cls){
    NormalFormDisplayFactory factory = new NormalFormDisplayFactory();
    NormalFormTransformModel model = factory.getModel(1, kb, cls);
    return model.getCanonicalForm();
  }

  private String[] getRows(){
    String[] ret = new String[clses.size()];
    int i = 0;
    Iterator it = clses.iterator();
    while(it.hasNext()){
      OWLNamedClass cls = (OWLNamedClass) it.next();
      ret[i++] = cls.getBrowserText();
    }
    return ret;
  }

  private String[] getColumns(){
    Vector ret = new Vector();
    //add row colum
    ret.add("Expression");
    Iterator it = clses.iterator();
    while(it.hasNext()){
      OWLNamedClass cls = (OWLNamedClass) it.next();
      NormalForm nform = this.getNormalForm(cls);
      Collection keys = nform.getKeys();
      Iterator it1 = keys.iterator();
      while(it1.hasNext()){
        String key = (String) it1.next();
        if(!ret.contains(key)){
          ret.add(key);
        }
      }

    }
    String[] retarray = new String[ret.size()];
    ret.copyInto(retarray);
    return retarray;
  }
}
