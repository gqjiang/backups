package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class NormalFormDisplayFactory {
  public NormalFormDisplayFactory() {
  }

  public NormalFormTransformModel getModel(int index, OWLModel kb, OWLNamedClass cls){
    switch(index){
      case 1:
        return new NormalFormDisplayForTerms(kb, cls);
      case 2:
        return new NormalFormDisplayForIds(kb, cls);
      case 3:
        return new NormalFormDisplayAll(kb, cls);
      default:
        return new NormalFormDisplayForTerms(kb, cls);
    }
  }
}
