package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class AnonymoursNodeListPane extends JDialog implements ActionListener{

  private JTextArea textArea;
  //private JScrollPane scrollPane;
  private JButton btnOK;
  private JButton btnSave;
  private String text;

  public AnonymoursNodeListPane(String text) {
    this.text = text;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      initUI();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }


  private void initUI(){
    this.setSize(400,600);
    this.getContentPane().setLayout(new BorderLayout());
    this.setTitle("Anonymous Nodes List");

    textArea = new JTextArea();
    textArea.setText(text);
    JScrollPane scrollPane = new JScrollPane();
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrollPane.getViewport().add(textArea);
    JPanel textPanel = new JPanel(new BorderLayout());
    textPanel.add(scrollPane, BorderLayout.CENTER);
    this.getContentPane().add(textPanel, BorderLayout.CENTER);

    btnOK = new JButton("OK...");
    btnOK.addActionListener(this);

    btnSave = new JButton("Save...");
    btnSave.addActionListener(this);

    JPanel btnPanel = new JPanel();
    btnPanel.add(btnOK);
    btnPanel.add(btnSave);

    this.getContentPane().add(btnPanel, BorderLayout.SOUTH);

  }

  //�E�B���h�E������ꂽ�Ƃ��ɏI������悤�ɃI�[�o�[���C�h
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }
  //�_�C�A���O�����
  private void cancel() {
    dispose();
  }


  public void actionPerformed(ActionEvent e){
    Object s = e.getSource();
    if(s == btnOK){
      this.cancel();
    }

    if(s == btnSave){
      this.actionPerformed_Save();
    }

  }

  private void actionPerformed_Save(){
    BufferedWriter bw;
    String fileName = "anonymousNodes.txt";
    File file = new File(fileName);
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.showSaveDialog(this);
    file = fileChooser.getSelectedFile();
    try{
      bw = new BufferedWriter(new FileWriter(file));
      bw.write(textArea.getText());
      bw.close();
    }catch(IOException ie){
      ie.printStackTrace();
    }
  }
}
