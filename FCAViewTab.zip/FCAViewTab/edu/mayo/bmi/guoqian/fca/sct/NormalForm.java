package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.util.*;

public class NormalForm {


  private Map keyValues;

  public NormalForm() {
    keyValues = new HashMap();
  }

  public void put(String value) {
    if (this.hasReserved()) {
       String key = this.getKeyForReserved();
       this.put(key, value);
    }
    else {
      this.put("isA", value);
    }
  }

  public void put(String key, String value) {
    if (keyValues.keySet().contains(key)) {
      Collection values = (Collection) keyValues.get(key);
      if(!values.contains(value))
          values.add(value);
    }
    else {
      Collection values = new ArrayList();
      if(!values.contains(value))
          values.add(value);
      keyValues.put(key, values);
    }
  }

  public void put(String key, Collection col){
    if (keyValues.keySet().contains(key)) {
      Collection values = (Collection) keyValues.get(key);
      Iterator it = col.iterator();
      while(it.hasNext()){
        String value = (String) it.next();
        if(!values.contains(value))
          values.add(value);
      }
    }
    else {
      Collection values = new ArrayList();
      Iterator it = col.iterator();
      while(it.hasNext()){
        String value = (String) it.next();
        if(!values.contains(value))
          values.add(value);
      }
      keyValues.put(key, values);
    }
  }

  public Collection getKeys(){
    return keyValues.keySet();
  }

  public String getValue(String key){
    StringBuffer sb = new StringBuffer();
    Collection values = (Collection) keyValues.get(key);
    Iterator it = values.iterator();
    while(it.hasNext()){
      String value = (String) it.next();
      sb.append(value + "|");
    }
    return sb.toString();
  }


  public Object getValues(String key){
    return keyValues.get(key);
  }

  public String getKeyValuePairs(){
    StringBuffer sb = new StringBuffer();
    Collection keys = this.getKeys();
    Iterator it = keys.iterator();
    while(it.hasNext()){
      String key = (String) it.next();
      String value = this.getValue(key);
      sb.append(key + " = " + value + "\n");
    }
    return sb.toString();
  }


  private boolean hasReserved() {
    boolean flag = false;
    Iterator it = keyValues.keySet().iterator();
    while (it.hasNext()) {
      String key = (String) it.next();
      Collection values = (Collection) keyValues.get(key);
      if (values.contains("RESERVED")) {
        flag = true;
        break;
      }
    }
    return flag;
  }

  private String getKeyForReserved(){
    String ret = "";
    Iterator it = keyValues.keySet().iterator();
    while (it.hasNext()) {
      String key = (String) it.next();
      Collection values = (Collection) keyValues.get(key);
      if (values.contains("RESERVED")) {
        values.remove("RESERVED");
        ret = key;
        break;
      }
    }

    return ret;
  }
}

