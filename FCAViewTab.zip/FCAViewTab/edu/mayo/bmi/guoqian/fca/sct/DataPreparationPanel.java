package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */
import java.io.*;
import java.util.*;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.ui.clsproperties.*;
import edu.stanford.smi.protegex.owl.ui.widget.*;
import javax.swing.JSplitPane;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import conexp.core.*;
import conexp.frontend.*;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.filechooser.FileFilter;
import java.awt.Color;
import edu.stanford.smi.protege.ui.ClsesPanel;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class DataPreparationPanel
    extends JPanel implements ActionListener {

  private OWLModel kb;

  private JSplitPane mainPane;

  private JButton btnStart1;
  private JButton btnStart2;
  private JButton btnStart3;
  private JButton btnDescription;

  private JButton btnSave;

//  private DirectInstancesList instanceList;
  private ClsesPanel clsesPanel;

  private JTextArea textArea;

  private JPanel rightPanel;
  private JScrollPane scrollPane2;

  //private Context formalcontext;

  //private FormalContextAdapter adapter;

  public DataPreparationPanel(KnowledgeBase kb) {
    this.kb = (OWLModel) kb;
    this.initUI();
  }

  private void initUI() {

    JPanel leftPanel = new JPanel(new BorderLayout());
    //JPanel rightPanel1 = new JPanel(new BorderLayout());

    rightPanel = new JPanel(new BorderLayout());

    clsesPanel = new ClsesPanel(kb.getProject());
    leftPanel.add(clsesPanel, BorderLayout.CENTER);

    JPanel btnPanel = new JPanel(new GridLayout(4, 1));
    btnStart1 = new JButton("Start(way1)...");
    btnStart1.addActionListener(this);
    JPanel btnPanel1 = new JPanel();
    btnPanel1.add(btnStart1);

    btnStart2 = new JButton("Start(way2)...");
    btnStart2.addActionListener(this);
    JPanel btnPanel2 = new JPanel();
    btnPanel2.add(btnStart2);

    btnStart3 = new JButton("Start(way3)...");
    btnStart3.addActionListener(this);
    JPanel btnPanel3 = new JPanel();
    btnPanel3.add(btnStart3);

    btnDescription = new JButton("Show basic description...");
    btnDescription.addActionListener(this);
    JPanel btnPanel4 = new JPanel();
    btnPanel4.add(btnDescription);

    btnPanel.add(btnPanel1);
    btnPanel.add(btnPanel2);
    btnPanel.add(btnPanel3);
    btnPanel.add(btnPanel4);
    leftPanel.add(btnPanel, BorderLayout.SOUTH);

    //View1 panel
    JPanel rightUpperPanel = new JPanel(new BorderLayout());
    JLabel label1 = new JLabel("  Data Set Results: ");
    label1.setForeground(Color.BLUE);
    textArea = new JTextArea("");
    textArea.setTabSize(32);
    JScrollPane scrollPane1 = new JScrollPane();
    scrollPane1.getViewport().add(textArea);
    //rightPanel1.add(scrollPane1, BorderLayout.CENTER);
    rightUpperPanel.add(label1, BorderLayout.NORTH);
    rightUpperPanel.add(scrollPane1, BorderLayout.CENTER);

    JPanel btnSavePanel = new JPanel();
    btnSave = new JButton("Save...");
    btnSave.addActionListener(this);
    btnSavePanel.add(btnSave);
    rightUpperPanel.add(btnSavePanel, BorderLayout.SOUTH);

    rightPanel.add(rightUpperPanel, BorderLayout.CENTER);

    //main pane to show left and right panel
    mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                              true,
                              leftPanel,
                              rightPanel);
    mainPane.setOneTouchExpandable(true);

    this.setLayout(new BorderLayout());
    this.add(mainPane, BorderLayout.CENTER);
  }

  public void actionPerformed(ActionEvent e) {
    Object s = e.getSource();
    if (s == btnStart1) {
      OWLNamedClass selectedClass = this.getSelectedClass();

      //clear the textarea
      textArea.setText("");
      textArea.append("className\t" +
                      "objNum\t" +
                      "definedObjNum\t" +
                      "attrNumOneValue\t" +
                      "attrNumManyValue\t" +
                      "conceptNum\t" +
                      "anonymousNodeNum\n");
      //System.out.println("selected class: " + selectedClass.getBrowserText());
      if (selectedClass != null) {
        Collection allSubClses = selectedClass.getNamedSubclasses(true);
        if (!allSubClses.contains(selectedClass)) {
          allSubClses.add(selectedClass);
        }

        Iterator it = allSubClses.iterator();
        while (it.hasNext()) {
          OWLNamedClass subCls = (OWLNamedClass) it.next();
          Collection subClses = subCls.getNamedSubclasses(true);
          if (!subClses.contains(subCls)) {
            subClses.add(subCls);
          }
          if (subClses != null && subClses.size() > 1) {

            FormalContextAdapter adpater = this.getContextAdapter(subClses,
                null, null, 7);

            Context context = adpater.getContext();
            int objNum = context.getObjectCount();
            int definedObjNum = this.getNumberOfFullyDefinedClasses(subClses);
            int attrNumOneValue = context.getAttributeCount();
            NormalFormTableModel tableModel = new NormalFormTableModel(kb,
                subClses);
            int attrNumManyValue = tableModel.getColumnCount() - 1;
            Lattice lattice = adpater.getLattice();
            int conceptNum = lattice.conceptsCount();
            int anonymousNum = this.getNumberOfAnonymousNodes(lattice);

            textArea.append(subCls.getBrowserText() + "\t");

            textArea.append(objNum + "\t" +
                            definedObjNum + "\t" +
                            attrNumOneValue + "\t" +
                            attrNumManyValue + "\t" +
                            conceptNum + "\t" +
                            anonymousNum + "\n");

          }
        }
      }
    }

    if (s == btnStart2) {
      OWLNamedClass selectedClass = this.getSelectedClass();

      //clear the textarea
      textArea.setText("");
      textArea.append("className\t" +
                      "objNum\t" +
                      "definedObjNum\t" +
                      "attrNumOneValue\t" +
                      "attrNumManyValue\t" +
                      "conceptNum\t" +
                      "anonymousNodeNum\n");
      //System.out.println("selected class: " + selectedClass.getBrowserText());
      if (selectedClass != null) {
        Collection allSubClses = selectedClass.getNamedSubclasses(false);
        //if (!selectedClass.isDefinedClass()) {
        //allSubClses.add(selectedClass);
        //}

        Iterator it = allSubClses.iterator();
        while (it.hasNext()) {
          OWLNamedClass subCls = (OWLNamedClass) it.next();
          Collection subClses = subCls.getNamedSubclasses(true);
          if (!subClses.contains(subCls)) {
            subClses.add(subCls);
          }
          if (subClses != null && subClses.size() > 1) {

            FormalContextAdapter adpater = this.getContextAdapter(subClses,
                null, null, 7);

            Context context = adpater.getContext();
            int objNum = context.getObjectCount();
            int definedObjNum = this.getNumberOfFullyDefinedClasses(subClses);
            int attrNumOneValue = context.getAttributeCount();
            NormalFormTableModel tableModel = new NormalFormTableModel(kb,
                subClses);
            int attrNumManyValue = tableModel.getColumnCount() - 1;
            Lattice lattice = adpater.getLattice();
            int conceptNum = lattice.conceptsCount();
            int anonymousNum = this.getNumberOfAnonymousNodes(lattice);

            textArea.append(subCls.getBrowserText() + "\t");

            textArea.append(objNum + "\t" +
                            definedObjNum + "\t" +
                            attrNumOneValue + "\t" +
                            attrNumManyValue + "\t" +
                            conceptNum + "\t" +
                            anonymousNum + "\n");

          }
        }
      }
    }

    if (s == btnStart3) {
      OWLNamedClass selectedClass = this.getSelectedClass();
      String strNumOfRandom = JOptionPane.showInputDialog(this, "Input the number of contexts: ",
                                  "Input a number for random",
                                  JOptionPane.PLAIN_MESSAGE);
      int numOfRandom = Integer.parseInt(strNumOfRandom);

      String strMinNumOfObjects = JOptionPane.showInputDialog(this,
                                  "Input the number of minimum objects: ",
                                  "Input a number for minimum objects",
                                  JOptionPane.PLAIN_MESSAGE);
      int minNumOfObjects = Integer.parseInt(strMinNumOfObjects);


      //clear the textarea
      textArea.setText("");
      textArea.append("className\t" +
                      "objNum\t" +
                      "definedObjNum\t" +
                      "attrNumOneValue\t" +
                      "attrNumManyValue\t" +
                      "conceptNum\t" +
                      "anonymousNodeNum\n");
      //System.out.println("selected class: " + selectedClass.getBrowserText());
      if (selectedClass != null) {
        Collection allSubClses = selectedClass.getNamedSubclasses(true);
        Collection subClsesUsedForContext = this.getLimitedCollection(allSubClses, minNumOfObjects);
        Collection randomizedSubClses =
            this.getRadomizedCollection(subClsesUsedForContext, numOfRandom);


        Iterator it = randomizedSubClses.iterator();
        while (it.hasNext()) {
          OWLNamedClass subCls = (OWLNamedClass) it.next();
          Collection subClses = subCls.getNamedSubclasses(true);
          if (!subClses.contains(subCls)) {
            subClses.add(subCls);
          }
          //if (subClses != null && subClses.size() > 1) {

            FormalContextAdapter adpater = this.getContextAdapter(subClses,
                null, null, 7);

            Context context = adpater.getContext();
            int objNum = context.getObjectCount();
            int definedObjNum = this.getNumberOfFullyDefinedClasses(subClses);
            int attrNumOneValue = context.getAttributeCount();
            NormalFormTableModel tableModel = new NormalFormTableModel(kb,
                subClses);
            int attrNumManyValue = tableModel.getColumnCount() - 1;
            Lattice lattice = adpater.getLattice();
            int conceptNum = lattice.conceptsCount();
            int anonymousNum = this.getNumberOfAnonymousNodes(lattice);

            textArea.append(subCls.getBrowserText() + "\t");

            textArea.append(objNum + "\t" +
                            definedObjNum + "\t" +
                            attrNumOneValue + "\t" +
                            attrNumManyValue + "\t" +
                            conceptNum + "\t" +
                            anonymousNum + "\n");

          }
        }
      //}
    }

    if (s == btnDescription) {
      OWLNamedClass selectedClass = this.getSelectedClass();

      //clear the textarea
      textArea.setText("");
      textArea.append("className\t" +
                      "classID\t" +
                      "totalSubClsNum\t" +
                      "contextSubClsNum1\t" +
                      "contextSubClsNum2\t" +
                      "contextSubClsNum3\n");
      //System.out.println("selected class: " + selectedClass.getBrowserText());
      if (selectedClass != null) {
        Collection allSubClses = selectedClass.getNamedSubclasses(false);

        Iterator it = allSubClses.iterator();
        while (it.hasNext()) {
          OWLNamedClass subCls = (OWLNamedClass) it.next();
          Collection subClses = subCls.getNamedSubclasses(true);
          String subClsName = subCls.getBrowserText();
          String classID = this.getSctidForCls(subClsName);

          int total = subClses.size();
          int contextTotal1 = this.getContextSubClsNum(subClses, 1);
          int contextTotal2 = this.getContextSubClsNum(subClses, 2);
          int contextTotal3 = this.getContextSubClsNum(subClses, 3);

            textArea.append( subClsName+ "\t" +
                            classID + "\t" +
                            total + "\t" +
                            contextTotal1 + "\t" +
                            contextTotal2 + "\t" +
                            contextTotal3 + "\n");

        }
      }
    }

    if (s == btnSave) {
      this.actionPerformed_Save();
    }
  }

  private Collection getRadomizedCollection(Collection subClses, int randomInt){
    Collection ret = new ArrayList();
    Random random = new Random();
    Object[] subClsesArray = subClses.toArray();
    for(int i = 0; i < randomInt; i++){
      int max = subClses.size()-1;
      int nextInt = random.nextInt(max);
      Object subCls = subClsesArray[nextInt];
      if(ret.contains(subCls)){
        i--;
      }else{
        ret.add(subCls);
      }
    }

    return ret;
  }

  private Collection getLimitedCollection(Collection subClses, int base){
    Collection ret = new ArrayList();
    Iterator it = subClses.iterator();
    while(it.hasNext()){
      OWLNamedClass subCls = (OWLNamedClass) it.next();
      Collection subSubClses = subCls.getNamedSubclasses(true);
      if (subSubClses != null && subSubClses.size() > base) {
        ret.add(subCls);
      }
    }
    return ret;
  }

  private int getContextSubClsNum(Collection subClses, int base){
    int count = 0;
    Iterator it = subClses.iterator();
    while(it.hasNext()){
      OWLNamedClass subCls = (OWLNamedClass) it.next();
      Collection subSubClses = subCls.getNamedSubclasses(true);
      if (subSubClses != null && subSubClses.size() > base) {
        count++;
      }
    }

    return count;
  }

  private String getSctidForCls(String str){
      OWLNamedClass namedCls = kb.getOWLNamedClass(str);
      RDFProperty labelProperty = kb.getRDFSLabelProperty();
      RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
      String ret = value.getString();
      return ret;
  }


  private void actionPerformed_Save() {
    BufferedWriter bw;
    String fileName = "dataset.txt";
    File file = new File(fileName);
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.showSaveDialog(this);
    file = fileChooser.getSelectedFile();
    try {
      bw = new BufferedWriter(new FileWriter(file));
      bw.write(textArea.getText());
      bw.close();
    }
    catch (IOException ie) {
      ie.printStackTrace();
    }
  }

  //get selected class
  private OWLNamedClass getSelectedClass() {
    //setup root node as default
    //String rootNode = "SNOMED_CT_Concept__SNOMED_RT_CTV3_";
    OWLNamedClass selectedClass = null;
    Collection selections = clsesPanel.getSelection();
    Iterator it = selections.iterator();
    while (it.hasNext()) {
      selectedClass = (OWLNamedClass) it.next();
      break;
    }
    return selectedClass;

  }

  //get number of anonymous nodes
  private int getNumberOfAnonymousNodes(Lattice lattice) {
    int count = lattice.conceptsCount();
    int aCount = 0;
    for (int i = 0; i < count; i++) {
      LatticeElement element = lattice.elementAt(i);
      //Concept concept = (Concept) element;
      if (!element.hasOwnObjects()) {
        if (i > 2) {
          aCount++;
        }
      }
    }
    return aCount;

  }

  //get number of fully defined classes
  private int getNumberOfFullyDefinedClasses(Collection clses) {
    int count = 0;

    Iterator it = clses.iterator();
    while (it.hasNext()) {
      OWLNamedClass cls = (OWLNamedClass) it.next();
      if (cls.isDefinedClass()) {
        count++;
      }
    }
    return count;
  }

  private FormalContextAdapter getContextAdapter(Collection objects,
                                                 RDFProperty prop,
                                                 OWLNamedClass cls,
                                                 int typeIndex) {
    OWLFormalContextSetter setter =
        new OWLFormalContextSetter(kb,
                                   objects,
                                   prop,
                                   cls,
                                   null,
                                   null,
                                   typeIndex);

    return setter.getContextAdapter();

  }

}
