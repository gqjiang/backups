package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.util.*;

import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class UseCaseTestContextSetter {

  private FormalContextAdapter adapter;
  //private OWLModel kb;


  public UseCaseTestContextSetter(int index, Map map) {
    adapter = new FormalContextAdapter();

    switch(index){
      case 1:
        this.setContextForSentences(map);
        break;
      default:
        this.setContextForSentences(map);
        break;
    }
  }

  private void setContextForSentences(Map map1){
    Iterator it = map1.keySet().iterator();
    while(it.hasNext()){
      String key = (String) it.next();
      adapter.addFormalObject(key);
      String[] words = (String[]) map1.get(key);
      for(int i = 0; i < words.length; i++){
        adapter.addFormalAttribute(words[i]);
        adapter.setRelation(key, words[i]);
      }

    }
  }

  public FormalContextAdapter getContextAdapter() {
    return this.adapter;
  }

}
