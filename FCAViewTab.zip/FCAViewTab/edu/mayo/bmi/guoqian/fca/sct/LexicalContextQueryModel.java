package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Compositional Expression Issue of SNOMED CT Using Formal Concept
 * Analysis</p>
 *
 * <p>���쌠: Copyright (c) 2006</p>
 *
 * <p>��Ж�: Division of BioMedical Informatics, Myo Clinic College of
 * Medicine</p>
 *
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

import conexp.core.*;

import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;
import javax.swing.JOptionPane;


public class LexicalContextQueryModel {

  private OWLModel kb;
  private Lattice lattice;
  private String queryResults;

  public LexicalContextQueryModel(Lattice lattice, OWLModel kb) {
    this.lattice = lattice;
    this.kb = kb;
    queryResults = this.queryCodes();
  }

  public String getQueryResults(){
    return this.queryResults;
  }

  private String queryCodes() {

    Collection colLevel1 = new ArrayList();
    Collection colLevel2 = new ArrayList();
    Collection colLevel21 = new ArrayList();
    Collection colLevel3 = new ArrayList();

    //StringBuffer sb = new StringBuffer();
    int nodeCount = lattice.conceptsCount();
    for (int i = 0; i < nodeCount; i++) {
      LatticeElement node = lattice.elementAt(i);
      Iterator it = node.ownObjectsIterator();
      while (it.hasNext()) {
        ContextEntity entity = (ContextEntity) it.next();
        String entityName = entity.getName();
        if (entityName.equals("Query")) {
          String queryOwnObjName = this.getOwnObjName(node);
          if (queryOwnObjName.equals("")) {
            LatticeElementCollection parents = node.getSuccessors();
            Iterator it1 = parents.iterator();
            while (it1.hasNext()) {
              LatticeElement node1 = (LatticeElement) it1.next();
              String ownObjName = this.getOwnObjName(node1);
              if (!ownObjName.equals("")) {
                //sb.append("Level 2: " + ownObjName);
                if(!colLevel2.contains(ownObjName))
                    colLevel2.add(ownObjName);
              }
              else {
                LatticeElementCollection children = node1.getPredecessors();
                Iterator it2 = children.iterator();
                while (it2.hasNext()) {
                  LatticeElement node2 = (LatticeElement) it2.next();
                  String ownObjName2 = this.getOwnObjName(node2);
                  if(!ownObjName2.equals(""))
                    //sb.append("Level 3: " + ownObjName2 + "\n");
                    if(!colLevel3.contains(ownObjName2))
                        colLevel3.add(ownObjName2);
                }

                LatticeElementCollection parents1 = node1.getSuccessors();
                Iterator it3 = parents1.iterator();
                while(it3.hasNext()){
                  LatticeElement node3 = (LatticeElement) it3.next();
                  String ownObjName3 = this.getOwnObjName(node3);
                  if(!ownObjName3.equals("") && !ownObjName3.equals("Obj 1")){
                    //sb.append("Level 2-1: " + ownObjName3 + "\n" );
                    if(!colLevel21.contains(ownObjName3))
                        colLevel21.add(ownObjName3);
                  }
                }
              }
            }

          }
          else {
            //sb.append("Level 1: " + queryOwnObjName);
            if(!colLevel1.contains(queryOwnObjName) &&
               !queryOwnObjName.equals("Obj 1"))
                colLevel1.add(queryOwnObjName);

          }
          break;
        }
      }
    }

    return this.getQueryResults(colLevel1, colLevel2, colLevel21, colLevel3);
  }

  private String getQueryResults(Collection level1,
                                 Collection level2,
                                 Collection level21,
                                 Collection level3){
    StringBuffer sb = new StringBuffer();
    if(level1.size() > 0)
      sb.append(this.getStringFromCollection(level1, 1));

    if(level2.size() > 0)
      sb.append(this.getStringFromCollection(level2, 2));
    else
      sb.append(this.getStringFromCollection(level21, 2));

    if(level3.size() > 0)
      sb.append(this.getStringFromCollection(level3, 3));

    if(level1.size() == 0 &&
       level2.size() == 0 &&
       level21.size() == 0 &&
       level3.size() == 0){
      sb.append("Sorry, no code for the query!");
    }


    return sb.toString();
  }

  private String getStringFromCollection(Collection level, int index){
    StringBuffer sb = new StringBuffer("");
    Iterator it = level.iterator();
    while(it.hasNext()){
      String name = (String) it.next();
      sb.append("Level" + index + ": " + name + "\n");
    }

    return sb.toString();
  }



/*
  private String getLabelsdForCls(String strCls){
    OWLNamedClass cls = kb.getOWLNamedClass(strCls);

      String label = "";
      //OWLNamedClass namedCls = kb.getOWLNamedClass(str);
      RDFProperty labelProperty = kb.getRDFSLabelProperty();
      //RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
      Collection labels = cls.getPropertyValues(labelProperty);
      Iterator it = labels.iterator();
      while(it.hasNext()){
        RDFSLiteral value = (RDFSLiteral) it.next();
        label = value.getString();
        break;
      }

      return label;
  }
  */

  private String getOwnObjName(LatticeElement node) {
    StringBuffer sb = new StringBuffer("");
    Iterator it = node.ownObjectsIterator();
    while (it.hasNext()) {
      ContextEntity entity = (ContextEntity) it.next();
      String entityName = entity.getName();
      if (!entityName.equals("Query")) {
        sb.append(entityName);
      }
    }

    return sb.toString();
  }

  private OWLNamedClass getClsId(String object){
    int index = object.indexOf("|");
    String clsName = object.substring(0,index-1);
    return kb.getOWLNamedClass(clsName);
  }

  private String getClsIdName(String object){
    int index = object.indexOf("|");
   String clsName = object.substring(0,index-1);
   return clsName;

  }


}
