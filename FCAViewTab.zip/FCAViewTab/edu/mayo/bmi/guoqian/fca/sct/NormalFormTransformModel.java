package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class NormalFormTransformModel {

  protected String normalForm = "";
  protected NormalForm nForm = new NormalForm();

  public NormalFormTransformModel() {
    //this.kb = kb;
  }

  public String getNormalForm(){
    return this.normalForm;
  }

  public NormalForm getCanonicalForm(){
    return this.nForm;
  }


}
