package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protegex.owl.model.*;
//import edu.stanford.smi.protegex.owl.ui.clsproperties.*;
import edu.stanford.smi.protegex.owl.ui.widget.*;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class NormalFormTransformPanel extends JPanel
             implements ActionListener {


  private OWLModel kb;

  private JSplitPane mainPane;

  private JButton btnShowNormalForm;

  private JButton btnProjectTransform;

//  private DirectInstancesList instanceList;
  private ClsesPanel clsesPanel;

  private JTextArea textArea;


  private JPanel rightPanel;
  private JScrollPane scrollPane2;

  //private JTabbedPane tabbedPane1;

  private JTable jTable;
  private NormalFormTableModel tableModel;

  private JButton btnSave1;
  private JButton btnSave2;



  public NormalFormTransformPanel(KnowledgeBase kb) {
    this.kb = (OWLModel)kb;
    this.initUI();
  }

  private void initUI(){

    JPanel leftPanel = new JPanel(new BorderLayout());
    //JPanel rightPanel1 = new JPanel(new BorderLayout());

    rightPanel = new JPanel(new GridLayout(2,1));

    clsesPanel = new ClsesPanel(kb.getProject());
    leftPanel.add(clsesPanel, BorderLayout.CENTER);


    btnShowNormalForm = new JButton("Show Normal Form...");
    btnShowNormalForm.addActionListener(this);
    JPanel btnPanel = new JPanel();
    btnPanel.add(btnShowNormalForm);
    leftPanel.add(btnPanel, BorderLayout.SOUTH);

    //Transform selected classes to a new pprj
    btnProjectTransform = new JButton("Transform Project...");
    btnProjectTransform.addActionListener(this);
    btnPanel.add(btnProjectTransform);


    //View1 panel
    JPanel rightUpperPanel = new JPanel(new BorderLayout());
    JLabel label1 = new JLabel("  Normal form for the selected class: ");
    label1.setForeground(Color.BLUE);
    textArea = new JTextArea("");
    JScrollPane scrollPane1 = new JScrollPane();
    scrollPane1.getViewport().add(textArea);
    //rightPanel1.add(scrollPane1, BorderLayout.CENTER);
    rightUpperPanel.add(label1, BorderLayout.NORTH);
    rightUpperPanel.add(scrollPane1, BorderLayout.CENTER);

    rightPanel.add(rightUpperPanel);

    //tabbedPane1.add("View1", scrollPane1);

    //View2 panel
    JPanel rightLowerPanel = new JPanel(new BorderLayout());
    JLabel label2 = new JLabel("  Normal form for all subclasses of the selected class: ");
    label2.setForeground(Color.BLUE);
    jTable = new JTable();
    scrollPane2 = new JScrollPane();
    scrollPane2.getViewport().add(jTable);
    //tabbedPane1.add("View2", scrollPane2);
    scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrollPane2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    rightLowerPanel.add(label2, BorderLayout.NORTH);
    rightLowerPanel.add(scrollPane2, BorderLayout.CENTER);

    JPanel btnSavePanel = new JPanel();
    btnSave1 = new JButton("Save One...");
    btnSave1.addActionListener(this);

    btnSave2 = new JButton("Save All...");
    btnSave2.addActionListener(this);

    btnSavePanel.add(btnSave1);
    btnSavePanel.add(btnSave2);

    rightLowerPanel.add(btnSavePanel, BorderLayout.SOUTH);

    rightPanel.add(rightLowerPanel);

    //rightPanel.add(tabbedPane1, BorderLayout.CENTER);

    //main pane to show left and right panel
    mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                              true,
                              leftPanel,
                              rightPanel);
    mainPane.setOneTouchExpandable(true);

    this.setLayout(new BorderLayout());
    this.add(mainPane, BorderLayout.CENTER);
  }

  public void actionPerformed(ActionEvent e){
    Object s = e.getSource();
    if(s == btnShowNormalForm){
        OWLNamedClass selectedClass = this.getSelectedClass();

        //clear the textarea
        textArea.setText("");
        //System.out.println("selected class: " + selectedClass.getBrowserText());
        if(selectedClass != null){
          if (selectedClass.isDefinedClass()) {
            this.getNormalFormForDenfinedClass(selectedClass);
          }
          else {
            this.getNormalFormForPrimitiveClass(selectedClass);
          }

          //show View2
          this.showNormalFormTable(selectedClass);
        }else{
          textArea.append("You should select a class at first before clicking the button");
        }
    }

    if(s == btnProjectTransform){
      OWLNamedClass selectedClass = this.getSelectedClass();
      TransformToFrameProjectModel pModel =
          new TransformToFrameProjectModel(selectedClass, kb);
      pModel.performTransform();
      textArea.append("Project transformation successful.\n");
    }

    if(s == btnSave1){
      this.actionPerformed_saveOne();
    }

    if(s == btnSave2){
      this.actionPerformed_saveAll();
    }
  }

  private void showNormalFormTable(OWLNamedClass cls){
    Collection subClses = cls.getNamedSubclasses(true);
    //subClses.add(cls);
    tableModel = new NormalFormTableModel(kb, subClses);
    jTable = new JTable(tableModel);
    scrollPane2.getViewport().add(jTable);
    scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrollPane2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    scrollPane2.repaint();
    rightPanel.repaint();
  }



  private Collection getAllSlotsOfNormalForms(OWLNamedClass cls){
    Collection slotNames = new ArrayList();
    Collection subClses = cls.getNamedSubclasses(true);
    tableModel = new NormalFormTableModel(kb, subClses);
    int colNum = tableModel.getColumnCount();
    for(int i = 1; i < colNum; i++){
      String colName = tableModel.getColumnName(i);
      if(!colName.equals("isA")){
        slotNames.add(colName);
      }
    }

    return slotNames;
  }

  private void actionPerformed_saveOne(){
    BufferedWriter bw;
    String fileName = "OneNormalForm.txt";
    File file = new File(fileName);
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.showSaveDialog(this);
    file = fileChooser.getSelectedFile();
    try {
      bw = new BufferedWriter(new FileWriter(file));
      bw.write(textArea.getText());
      bw.close();
    }
    catch (IOException ie) {
      ie.printStackTrace();
    }
  }

  private void actionPerformed_saveAll(){
    BufferedWriter bw;
    String fileName = "OneNormalForm.txt";
    File file = new File(fileName);
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.showSaveDialog(this);
    file = fileChooser.getSelectedFile();
    try {
      bw = new BufferedWriter(new FileWriter(file));
      bw.write(this.getStringFromTableModel());
      bw.close();
    }
    catch (IOException ie) {
      ie.printStackTrace();
    }
  }

  private String getStringFromTableModel(){
    StringBuffer sb = new StringBuffer();
    int colCount = tableModel.getColumnCount();
    int rowCount = tableModel.getRowCount();


    for(int h = 0; h < colCount; h++){
      sb.append(tableModel.getColumnName(h) + ",");
    }
    sb.append("\n");

    for(int i = 0; i < rowCount; i++){
      for(int j = 0; j < colCount; j++){
        sb.append((String)tableModel.getValueAt(i, j) + ",");
      }
      sb.append("\n");
    }

    return sb.toString();
  }

  //get selected class
  private OWLNamedClass getSelectedClass(){
      //setup root node as default
      //String rootNode = "SNOMED_CT_Concept__SNOMED_RT_CTV3_";
      OWLNamedClass selectedClass = null;
      Collection selections = clsesPanel.getSelection();
      Iterator it = selections.iterator();
      while(it.hasNext()){
        selectedClass = (OWLNamedClass) it.next();
        break;
      }
      return selectedClass;

  }

  private void getNormalFormForDenfinedClass(OWLNamedClass cls){
    StringBuffer normalForm = new StringBuffer();
    String bText = cls.getBrowserText();
    normalForm.append(bText + " is a fully defined concept" + "\n");
    normalForm.append("\n");
    normalForm.append("The normal form expression (no context) of the concept is: \n");
    textArea.append(normalForm.toString() + "\n");
    String strNormalForm = this.getNormalForm(cls);
    //System.out.println(strNormalForm);
    textArea.append(strNormalForm);

  }

  private void getNormalFormForPrimitiveClass(OWLNamedClass cls){
    StringBuffer normalForm = new StringBuffer();
    String bText = cls.getBrowserText();
    normalForm.append(bText + " is a primitive concept" + "\n");
    normalForm.append("\n");
    normalForm.append("The normal form expression (no context) of the concept is: \n");

    textArea.append(normalForm.toString() + "\n");

    String strNormalForm = this.getNormalForm(cls);
    //System.out.println(strNormalForm);
    textArea.append(strNormalForm);

  }

  private String getNormalForm(OWLNamedClass cls){
    StringBuffer sb = new StringBuffer();
    NormalFormDisplayFactory factory = new NormalFormDisplayFactory();
    NormalFormTransformModel model1 = factory.getModel(1, kb, cls);
    String normalForm1 = model1.getNormalForm();
//    NormalForm nForm1 = model1.getCanonicalForm();

    NormalFormTransformModel model2 = factory.getModel(2, kb, cls);
    String normalForm2 = model2.getNormalForm();

    NormalFormTransformModel model3 = factory.getModel(3, kb, cls);
    String normalForm3 = model3.getNormalForm();
    sb.append("Display for terms: \n");
    sb.append(normalForm1 + "\n");

//    sb.append("Display for test:" + "\n");
//    sb.append(nForm1.getKeyValuePairs() + "\n");

    sb.append("Display for ids: \n");
    sb.append(normalForm2 + "\n");
    sb.append("Display for all: \n");
    sb.append(normalForm3 + "\n");
    return sb.toString();
  }

}
