package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.LexGrid.concepts.CodedEntry;
import org.LexGrid.concepts.ConceptProperty;
import org.LexGrid.concepts.Definition;
import org.LexGrid.concepts.Presentation;
import org.apache.log4j.Logger;

import edu.mayo.informatics.resourcereader.core.IF.ResourceContents;
import edu.mayo.informatics.resourcereader.rdf.RDFContents;
import edu.mayo.informatics.resourcereader.rdf.RDFResourceReader;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.*;

import edu.stanford.smi.protegex.server_changes.model.*;
import edu.stanford.smi.protegex.server_changes.model.generated.*;
//import edu.stanford.smi.protege.collab.changes.ChangeOntologyUtil;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.util.CollectionUtilities;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.server_changes.ChangesProject;
import edu.stanford.smi.protegex.server_changes.model.ChangeModel.AnnotationCls;
import edu.stanford.smi.protegex.server_changes.model.generated.Annotation;
import edu.stanford.smi.protegex.server_changes.model.generated.Ontology_Component;
import edu.stanford.smi.protegex.server_changes.model.generated.Timestamp;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

public class ChangeSetDetectionModelByRDFParser {

	private String strUrl;

	private KnowledgeBase kb;

	private Map drafts;

	public ChangeSetDetectionModelByRDFParser(String strUrl, KnowledgeBase kb) {
		this.kb = kb;
		this.strUrl = strUrl;
	}

	public Map rdfParsingUsingProtegeOWLModel() {
		StringBuffer sb = new StringBuffer();
		drafts = new HashMap();

		try {

			OWLModel owlModel = ProtegeOWL.createJenaOWLModelFromURI(strUrl);
			Collection rdfResources = owlModel.getRDFResources();
			for (Iterator it = rdfResources.iterator(); it.hasNext();) {
				Object resource = it.next();
				if (resource instanceof RDFSClass) {
					// sb.append("class: " +
					// ((RDFSClass)resource).getBrowserText() + "\n");
				} else if (resource instanceof RDFProperty) {
					// sb.append("property:" +
					// ((RDFProperty)resource).getBrowserText() + "\n");
				} else if (resource instanceof RDFIndividual) {
					String bText = ((RDFIndividual) resource).getBrowserText();
					if (bText.indexOf("wiki:Draft") >= 0) {

						Map draftContents = new HashMap();

						Collection props = ((RDFIndividual) resource)
								.getPossibleRDFProperties();

						for (Iterator it2 = props.iterator(); it2.hasNext();) {
							RDFProperty prop = (RDFProperty) it2.next();
							Collection normalizedPropValues = new ArrayList();
							sb.append("propName: " + prop.getName() + "\n");
							String propName = prop.getName();
							String normalPropName = null;
							if (propName.indexOf("wiki") >= 0) {
								Collection propValues = ((RDFIndividual) resource)
										.getPropertyValues(prop);
								for (Iterator it3 = propValues.iterator(); it3
										.hasNext();) {
									if (propName.indexOf("Attribute") >= 0) {
										normalPropName = "Attribute:"
												+ propName.substring(17);
										String propValue = it3.next()
												.toString();
										sb.append("value: " + propValue + "\n");
										normalizedPropValues.add(propValue);
									} else if (propName.indexOf("Relation") >= 0) {
										normalPropName = "Relation:"
												+ propName.substring(16);
										RDFResource propValue = (RDFResource) it3
												.next();
										String value = propValue
												.getBrowserText();
										normalizedPropValues
												.add(this
														.getNormalizedAssociationValue(value));
									}

								}
							}
							draftContents.put(normalPropName,
									normalizedPropValues);

						}

						bText = bText.substring(5);
						drafts.put(bText, draftContents);

					}

				} else {
					sb.append("other:" + resource.toString() + "\n");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return drafts;
	}

	public String getParsedContents() {
		StringBuffer sb = new StringBuffer();
		Map drafts = this.rdfParsingUsingProtegeOWLModel();
		for (Iterator it = drafts.keySet().iterator(); it.hasNext();) {
			String draftName = (String) it.next();
			sb.append("== " + draftName + " ==\n");
			Map draftContents = (Map) drafts.get(draftName);
			for (Iterator it1 = draftContents.keySet().iterator(); it1
					.hasNext();) {
				String propName = (String) it1.next();
				Collection propValues = (Collection) draftContents
						.get(propName);
				for (Iterator it2 = propValues.iterator(); it2.hasNext();) {
					String propValue = (String) it2.next();
					sb.append("    " + propName + " = " + propValue + "\n");
				}
			}
		}

		return sb.toString();
	}

	public Map getProposals() {
		return this.drafts;
	}

	public String getOriginalContents(String selectedCode, Map originalContents) {
		StringBuffer sb = new StringBuffer();
		sb.append("== Original Concept: " + selectedCode + " ==\n");
		for (Iterator it1 = originalContents.keySet().iterator(); it1.hasNext();) {
			String propName = (String) it1.next();
			Collection propValues = (Collection) originalContents.get(propName);
			for (Iterator it2 = propValues.iterator(); it2.hasNext();) {
				String propValue = (String) it2.next();
				sb.append("    " + propName + " = " + propValue + "\n");
			}
		}
		return sb.toString();

	}

	public void createChangeSetUsingAnnotationOntology(Cls selectedCode,
			Map originalContents) {

		ChangeModel changeModel = new ChangeModel(kb);
		new ChangesProject().afterLoad(kb.getProject());
		KnowledgeBase ckb = ChangesProject.getChangesKB(kb);

		Map proposals = this.getProposals();

		Ontology_Class icdOntologyClass = (Ontology_Class) ckb
				.getInstance(selectedCode.getBrowserText());
		if (icdOntologyClass == null) {
			icdOntologyClass = (Ontology_Class) ckb.createInstance(selectedCode.getBrowserText(), ckb.getCls("Ontology_Class"));
			icdOntologyClass.setCurrentName(selectedCode.getBrowserText());
		}
		
		Collection allComments = new ArrayList();

		for (Iterator it = proposals.keySet().iterator(); it.hasNext();) {
			String draftTitle = (String) it.next();
			Map draftContents = (Map) proposals.get(draftTitle);

			String userName = this.getProposalUser(draftTitle);
			// Timestamp tstamp = this.getProposalTimestampe(draftTitle);
			String contents = this.getProposalContents(draftContents);

			Annotation comment = (Annotation) ckb.createInstance(null,
					ChangesProject.getChangesDb(kb).getModel().getCls(
							AnnotationCls.Comment));
			// ChangeOntologyUtil.fillAnnotationSystemFields(kb, comment);
			// comment.setCreated(tstamp);
			//comment.setName(draftTitle);

			comment.setAuthor(userName);

			comment.setBody(draftTitle);
			
			Property_Change propertyChange = (Property_Change) ckb.createInstance(null,
					ckb.getCls("Property_Change"));
			propertyChange.setContext("Property Changed at:" + draftTitle);
			propertyChange.setApplyTo(icdOntologyClass);
			
			allComments.add(comment);

			// pizzaOntologyComponent.setAssociatedAnnotations(CollectionUtilities.createCollection(comment));

			System.out.println("Created comment " + comment.getBrowserText()
					+ " on " + selectedCode.getBrowserText());

		}
		icdOntologyClass.setAssociatedAnnotations(allComments);

		
		
		System.out.println("\nSaving " + kb.getProject().getProjectURI());
		ArrayList errors = new ArrayList();
		kb.getProject().save(errors);

		System.out.println("\nSaving annotations in "
				+ ckb.getProject().getProjectURI());
		ckb.getProject().save(errors);

		System.out.println(errors);
		System.out.print("Processing finished...");

	}

	private String getProposalContents(Map contents) {
		StringBuffer sb = new StringBuffer();
		for (Iterator it = contents.keySet().iterator(); it.hasNext();) {
			String pName = (String) it.next();
			Collection pValues = (Collection) contents.get(pName);
			for (Iterator it1 = pValues.iterator(); it1.hasNext();) {
				String pValue = (String) it1.next();
				sb.append(pName + "=" + pValue + "\n");
			}
		}

		return sb.toString();
	}

	private String getProposalUser(String title) {
		String ret = "";
		int index1 = title.indexOf("_by_");
		int index2 = title.indexOf("_at_");
		ret = title.substring(index1 + 4, index2);

		return ret;
	}

	private Timestamp getProposalTimestampe(String title) {
		String ret = "";
		int index1 = title.indexOf("_at_");
		ret = title.substring(index1 + 4);
		System.out.println("Timestamp:" + ret + "\n");

		Timestamp tstamp = new Timestamp();
		tstamp.setSequence(Integer.parseInt(ret));

		return tstamp;
	}

	private String getNormalizedAssociationValue(String wikivalue) {
		String value = null;
		if (wikivalue.length() > 16) {
			value = wikivalue.substring(16);
			value = value.replaceAll("-28", "(");
			value = value.replaceAll("-29", ")");
		}
		return value;
	}
	/*
	 * public String rdfParsing(){
	 * 
	 * StringBuffer sb = new StringBuffer();
	 * 
	 * URL url; try{ url = new URL(strUrl); RDFResourceReader reader = new
	 * RDFResourceReader(url, null); ResourceContents contents =
	 * reader.getContents(false, true);
	 * 
	 * if (contents == null) { System.out.println("contents were null.");
	 * 
	 * }else{ if (contents instanceof RDFContents) { RDFContents rdfct =
	 * (RDFContents) contents; rdfct.printRDFElements(System.out);
	 * 
	 * Set uriSet = rdfct.getRDFElementURIs(); for(Iterator it =
	 * uriSet.iterator(); it.hasNext();){ String key = (String) it.next();
	 * sb.append(key + "\n"); //if(key.indexOf("Draft") >= 0){ Properties prop =
	 * rdfct.getRDFElementProperties(key);
	 * 
	 * sb.append("name: " + prop.getProperty("name") + "\n"); sb.append("label: " +
	 * prop.getProperty("label") + "\n");
	 * 
	 * for(Iterator it1 = prop.keySet().iterator(); it1.hasNext();){ String key1 =
	 * it1.next().toString();
	 * 
	 * 
	 * String prop1 = prop.getProperty(key1); String shortProp1 = prop1;
	 * if(prop1.indexOf("http:") >= 0){ shortProp1 =
	 * prop1.substring(prop1.lastIndexOf("/")+1, prop1.length()); } sb.append("
	 * key1: " + key1 + "\n"); sb.append(" shortprop1: " + shortProp1 + "\n");
	 * sb.append(" prop1: " + prop1 + "\n"); } } } } }catch(Exception e){
	 * e.printStackTrace(); }
	 * 
	 * return sb.toString(); }
	 */

}
