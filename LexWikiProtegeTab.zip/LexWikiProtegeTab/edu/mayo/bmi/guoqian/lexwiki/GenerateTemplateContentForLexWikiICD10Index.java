package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.FormalContextAdapter;

import net.sourceforge.jwbf.actions.http.mw.*;

public class GenerateTemplateContentForLexWikiICD10Index {

	private String fileName;

	private Map contents;

	private Frequency freqAll;
	
	private FormalContextAdapter adapter;

	public GenerateTemplateContentForLexWikiICD10Index(String fileName) {
		this.fileName = fileName;
	}

	public String getIndexFrequency() {
		this.calculateFrquency();
		StringBuffer sb = new StringBuffer();
		sb.append("Types|" + freqAll.getTypes() + "\n");
		sb.append("Tokens|" + freqAll.getTokens() + "\n");
		for (Iterator it = freqAll.iterator(); it.hasNext();) {
			String idxName = (String) it.next();
			int freq = freqAll.getFreq(idxName);
			if (this.isStartsWithUpperLetter(idxName)) {
				sb.append(idxName + "|" + freq + "|" + "HT" + "\n");
			} else {
				sb.append(idxName + "|" + freq + "|" + "ST" + "\n");
			}
		}

		return sb.toString();
	}
	
	public FormalContextAdapter getFormalContextAdapter(){
		adapter = new FormalContextAdapter();
		freqAll = new Frequency();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while (line != null) {
				String[] items = line.split("\\|");
				String idxName = items[0];
				Collection atomicTerms = this.getAllAtomicTermsForIndexName(idxName);
				if (items.length > 1) {
					for (int i = 1; i < items.length; i++) {
						String item = items[i];
						if (item.startsWith("see") || item.startsWith("code")) {
							continue;
						} else {
							String code = item;
							adapter.addFormalObject(code);
							for(Iterator it = atomicTerms.iterator(); it.hasNext();){
								String aterm = (String)it.next();
								adapter.addFormalAttribute(aterm);
								adapter.setRelation(code, aterm);
							}
						}
					}
				}
				line = br.readLine();
			}

			br.close();
		} catch (IOException ie) {
			ie.printStackTrace();
		}		
		return adapter;
	}

	public Map getAllContents() {
		contents = new HashMap();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while (line != null) {
				String[] items = line.split("\\|");
				String idxName = items[0];

				StringBuffer sb = new StringBuffer();
				sb.append(this.getLexWikiPreferredNameTemplate(idxName));
				if (items.length > 1) {
					for (int i = 1; i < items.length; i++) {
						String item = items[i];
						if (item.startsWith("see") || item.startsWith("code")) {
							sb.append(this.getLexWikiSeeAlsoTemplate(item));
						} else {
							sb.append(this.getLexWikiIndexToTemplate(item,
									"ICD10"));
						}
					}
				}

				sb.append(this.getLexWikiParentTemplate(idxName));
				sb.append(this.getLexWikiSubIndexesTemplate());

				contents.put(idxName, sb.toString());
				line = br.readLine();
			}

			br.close();
		} catch (IOException ie) {
			ie.printStackTrace();
		}

		return contents;
	}

	public Object[] getIndexNames() {

		Object[] ret = contents.keySet().toArray();
		Arrays.sort(ret);
		return ret;
	}

	public String getContentForIndexName(String idxName) {
		return (String) contents.get(idxName);
	}

	public Collection getWikiSimpleArticles() {
		Collection ret = new ArrayList();
		for (Iterator it = contents.keySet().iterator(); it.hasNext();) {
			String idxName = (String) it.next();
			String content = (String) contents.get(idxName);
			SimpleArticle sa = new SimpleArticle();
			String label = "Index:" + this.mangle(idxName);
			sa.setLabel(label);
			sa.setText(content);
			ret.add(sa);
		}

		return ret;
	}

	private void calculateFrquency() {
		freqAll = new Frequency();
		for (Iterator it = contents.keySet().iterator(); it.hasNext();) {
			String idxName = (String) it.next();
			String[] items = idxName.split("/");
			for (int i = 0; i < items.length; i++) {
				String item = items[i];
				if (hasTokenParentheses(item)) {
					//System.out.println("Yes: has parentheses tokens");
					this.getFrequencyTokenParentheses(item);
					this.getFrequencyTokenNestedParentheses(item);

					item = item.replaceAll("\\(.+\\)", "");
					item = item.trim();
					if (item.indexOf(",") >= 0) {
						String[] terms = item.split(",");
						for (int j = 0; j < terms.length; j++) {
							freqAll.add(terms[j].trim());
						}
					} else {
						freqAll.add(item.trim());
					}
				} else {
					if (item.indexOf(",") >= 0) {
						String[] terms = item.split(",");
						for (int j = 0; j < terms.length; j++) {
							freqAll.add(terms[j].trim());
						}
					} else {
						freqAll.add(item.trim());
					}

				}

			}

		}

	}
	
	private Collection getAllAtomicTermsForIndexName(String idxName){
		Collection ret = new ArrayList();
		String[] items = idxName.split("/");
		for (int i = 0; i < items.length; i++) {
			String item = items[i];
			if (hasTokenParentheses(item)) {
				//System.out.println("Yes: has parentheses tokens");
				//ret.addAll(this.getFrequencyTokenParentheses(item));
				//ret.addAll(this.getFrequencyTokenNestedParentheses(item));

				item = item.replaceAll("\\(.+\\)", "");
				item = item.trim();
				if (item.indexOf(",") >= 0) {
					String[] terms = item.split(",");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim());
					}
				} else if(item.indexOf(" or ") >= 0){
					String[] terms = item.split(" or ");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim());
					}					
				}else {
				
					freqAll.add(item.trim());
					ret.add(item.trim());
				}
			} else {
				if (item.indexOf(",") >= 0) {
					String[] terms = item.split(",");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim());
					}
				}else if(item.indexOf(" or ") >= 0){
					String[] terms = item.split(" or ");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim());
					}					
				} else {
					freqAll.add(item.trim());
					ret.add(item.trim());
				}

			}

		}		
		
		return ret;
	}

	private boolean isStartsWithUpperLetter(String line) {
		boolean ret = false;
		if (line != null && line.length() > 0) {

			String firstLetter = line.substring(0, 1);

			Pattern p = Pattern.compile("[A-Z]");

			Matcher m = p.matcher(firstLetter);

			if (m.find()) {
				ret = true;
			}
		}

		return ret;
	}

	private boolean hasTokenParentheses(String line) {
		boolean ret = false;

		Pattern p = Pattern.compile("(\\(.+\\))");

		Matcher m = p.matcher(line);

		if (m.find()) {
			int count = m.groupCount();
			//System.out.println(count);
			
			ret = true;
		}

		return ret;
	}

	private Collection getFrequencyTokenParentheses(String line) {
		Collection ret = new ArrayList();

		Pattern p = Pattern.compile("(\\([a-zA-Z' ]+?\\))");

		Matcher m = p.matcher(line);

		if (m.find()) {
			int count = m.groupCount();
			//System.out.println(count);
			for (int i = 0; i < count; i++) {
				String group = m.group(i);
				group = group.replaceAll("\\(", "");
				group = group.replaceAll("\\)", "");
				System.out.println(group);
				freqAll.add(group.trim());
				ret.add(group.trim());
			}
		}
		
		return ret;

	}

	private Collection getFrequencyTokenNestedParentheses(String line) {
		Collection ret = new ArrayList();

		Pattern p = Pattern.compile("(\\([a-zA-Z' ]+?\\()");

		Matcher m = p.matcher(line);

		if (m.find()) {
			int count = m.groupCount();
			//System.out.println(count);
			for (int i = 0; i < count; i++) {
				String group = m.group(i);
				group = group.replaceAll("\\(", "");
				group = group.replaceAll("\\)", "");
				System.out.println(group);
				freqAll.add(group.trim());
				ret.add(group.trim());
			}
		}
		
		return ret;

	}	
	
	private String getLexWikiParentTemplate(String name) {
		StringBuffer sb = new StringBuffer();
		if (name.length() > 1) {
			String firstLetter = name.substring(0, 1);
			sb.append("{{LexWiki Parent|Alphabetical Index " + firstLetter
					+ "}}\n");
		} else {
			sb
					.append("{{LexWiki Parent|Alphabetical Index " + "Other"
							+ "}}\n");

		}
		return sb.toString();
	}

	private String getLexWikiPreferredNameTemplate(String name) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Preferred Name|" + name + "}}\n");

		return sb.toString();
	}

	private String getLexWikiSeeAlsoTemplate(String term) {
		StringBuffer sb = new StringBuffer();
		if (term.startsWith("see also")) {
			int index = term.indexOf("see also");
			String idxterm = term.substring(index + 9);
			sb.append("{{LexWiki SeeAlso|See Also|" + idxterm + "}}\n");

		} else if (term.startsWith("code")) {
			sb.append("{{LexWiki SeeAlso|See Also|" + term + "}}\n");

		} else {
			int index = term.indexOf("see");
			String idxterm = term.substring(index + 3);
			sb.append("{{LexWiki SeeAlso|See|" + idxterm + "}}\n");

		}

		return sb.toString();
	}

	private String getLexWikiIndexToTemplate(String code, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki IndexTo|" + ns + "|(" + code + ")}}\n");

		return sb.toString();
	}

	private String getLexWikiSubIndexesTemplate() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki SubIndexes|{{PAGENAME}}}}\n");
		return sb.toString();
	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		// lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		// lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}

}
