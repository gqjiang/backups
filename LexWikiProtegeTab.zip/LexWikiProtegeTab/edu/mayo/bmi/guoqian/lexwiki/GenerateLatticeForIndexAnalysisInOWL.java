package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;
import java.io.*;
import java.net.URI;

import javax.swing.JPanel;

import com.hp.hpl.jena.util.FileUtils;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.URIUtilities;
import conexp.core.*;
import conexp.frontend.*;

import edu.stanford.smi.protegex.owl.ProtegeOWL;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.util.ImportHelper;
import edu.stanford.smi.protegex.owl.swrl.*;
import edu.stanford.smi.protegex.owl.swrl.model.*;
import edu.stanford.smi.protegex.owl.swrl.parser.SWRLParser;
import edu.stanford.smi.protegex.owl.ui.widget.OWLUI;
import edu.stanford.smi.protegex.owl.ui.*;
import edu.mayo.bmi.guoqian.fca.fcaviewtab.FormalContextAdapter;

public class GenerateLatticeForIndexAnalysisInOWL {

	private OWLModel owlModel;

	private FormalContextAdapter adapter;

	public GenerateLatticeForIndexAnalysisInOWL(OWLModel owlModel) {
		this.owlModel = owlModel;
		// allCodeNames = this.getAllRecords();
		// this.generateContent();

	}

	public FormalContextAdapter getFormalContextAdapter(
			OWLNamedClass selectedCls) {
		String indexAtom = "Index_Atom";
		RDFProperty slotIndexAtom = owlModel.getRDFProperty(indexAtom);

		adapter = new FormalContextAdapter();

		/*
		 * String topClsName = selectedCls.getBrowserText();
		 * adapter.addFormalObject(topClsName); Collection topIdxAtoms = new
		 * ArrayList(); topIdxAtoms =
		 * selectedCls.getOwnSlotValues(slotIndexAtom); int index1 =
		 * topClsName.lastIndexOf("("); topClsName = topClsName.substring(0,
		 * index1); String [] topWords = topClsName.split(" "); for(int i = 1; i <
		 * topWords.length; i++){ String topWord = topWords[i].toLowerCase();
		 * if(topWord.endsWith(",")){ topWord = topWord.substring(0,
		 * topWord.length()-1); } adapter.addFormalAttribute(topWord);
		 * adapter.setRelation(selectedCls.getBrowserText(), topWord); }
		 * for(Iterator it0 = topIdxAtoms.iterator(); it0.hasNext();){ String
		 * atom = (String)it0.next(); adapter.addFormalAttribute(atom);
		 * adapter.setRelation(selectedCls.getBrowserText(), atom); }
		 */
		Collection subclasses = selectedCls.getSubclasses(true);

		for (Iterator it = subclasses.iterator(); it.hasNext();) {
			OWLNamedClass subclass = (OWLNamedClass) it.next();
			//String clsName = subclass.getBrowserText();
			RDFProperty propLabel = owlModel.getRDFProperty("rdfs:label");
			String label = (String)subclass.getPropertyValue(propLabel);
			String clsName = label;
			adapter.addFormalObject(clsName);
			Collection idxAtoms = subclass.getPropertyValues(slotIndexAtom);
			for (Iterator it1 = idxAtoms.iterator(); it1.hasNext();) {
				String atom = (String) it1.next();
				adapter.addFormalAttribute(atom);
				adapter.setRelation(clsName, atom);

				// if(clsName.indexOf(", unspecified") >= 0){
				// adapter.addFormalAttribute("unspecified");
				// adapter.setRelation(clsName, "unspecified");
				// }
				// adapter.setRelation(selectedCls.getBrowserText(), atom);
			}
			/*
			 * //add top node attributes for(Iterator it2 =
			 * topIdxAtoms.iterator(); it2.hasNext();){ String atom =
			 * (String)it2.next(); adapter.addFormalAttribute(atom);
			 * adapter.setRelation(clsName, atom); } for(int i1 = 1; i1 <
			 * topWords.length; i1++){ String topWord =
			 * topWords[i1].toLowerCase(); if(topWord.endsWith(",")){ topWord =
			 * topWord.substring(0, topWord.length()-1); }
			 * adapter.addFormalAttribute(topWord); adapter.setRelation(clsName,
			 * topWord); }
			 */
		}

		return adapter;

	}
	
	public String getAuditingResults(OWLNamedClass selectedCls) {
		
		
		StringBuffer sb = new StringBuffer();
		
		if(selectedCls.getBrowserText().equals("ICD10_Terms")){
		
			Collection chapters = selectedCls.getSubclasses(false);
			for(Iterator it = chapters.iterator(); it.hasNext();){
				OWLNamedClass chapter = (OWLNamedClass)it.next();
				sb.append(chapter.getBrowserText() + "\n");
				Collection subclasses = chapter.getSubclasses(true);
				for(Iterator it1 = subclasses.iterator(); it1.hasNext();){
					OWLNamedClass subclass = (OWLNamedClass)it1.next();
					RDFProperty propCode = owlModel.getRDFProperty("Concept_Code");
					String code = (String)subclass.getPropertyValue(propCode);
					if(code.length() == 3){
						Lattice lattice = this.getFormalContextAdapter(subclass)
						.getLattice();
						Collection objects = subclass.getSubclasses(true);
						sb.append(code + "|" + objects.size() + "|" + this.getLatticeNodeNumAndAnonymousNodeNum(lattice));
						
						sb.append(this.getOutlierNodeNum(lattice) + "\n");					}
				}
			
			}
		
		
		
		}else{
		
			Lattice lattice = this.getFormalContextAdapter(selectedCls)
				.getLattice();
		

			Collection subclasses = selectedCls.getSubclasses(true);
		
			sb.append(subclasses.size() + "|" + this.getLatticeNodeNumAndAnonymousNodeNum(lattice));
		
			sb.append(this.getOutlierNodeNum(lattice));
		}
		
		
		
		return sb.toString();
		
		
	}

	public void tranformLatticeToSWRL(OWLNamedClass selectedCls, JPanel parent) {
		Lattice lattice = this.getFormalContextAdapter(selectedCls)
				.getLattice();

		try {

			owlModel.getNamespaceManager().setDefaultNamespace(
					"http://informatics.mayo.edu#");

			RDFSClass rootClass = owlModel.getOWLNamedClass("owl:Thing");
			OWLNamedClass clsDiseaseModel = owlModel
					.getOWLNamedClass("ICD11DiseaseModel");

			SWRLFactory factory = new SWRLFactory(owlModel);

			SWRLAtomList body = factory.createAtomList();
			SWRLAtomList head = factory.createAtomList();

			OWLNamedClass clsDiseaseType = owlModel
					.getOWLNamedClass("DiseaseType");

			OWLNamedClass clsAnatomicalSite = owlModel
					.getOWLNamedClass("AnatomicalSite");
			OWLNamedClass clsSpecifiedSite = owlModel
					.getOWLNamedClass("SpecifiedSite");
			OWLNamedClass clsSpecifiedNEC = owlModel
					.getOWLNamedClass("SpecifiedNEC");
			OWLNamedClass clsUnspecifiedSite = owlModel
					.getOWLNamedClass("UnspecifiedSite");

			OWLNamedClass clsTemporalRelation = owlModel
					.getOWLNamedClass("TemporalRelation");

			LatticeElement topElement = lattice.getTop();

			Map mapOwnAttrs = new HashMap();

			LatticeElementCollection children = topElement.getChildren();
			for (Iterator it11 = children.iterator(); it11.hasNext();) {
				LatticeElement element = (LatticeElement) it11.next();
				if (element.hasOwnObjects()) {
					for (Iterator it12 = element.ownObjectsIterator(); it12
							.hasNext();) {
						ContextEntity ownObj = (ContextEntity) it12.next();
						String ownObjName = (String) ownObj.getName();
						// System.out.println("ownObj:" + ownObjName);
					}

					for (Iterator it13 = element.ownAttribsIterator(); it13
							.hasNext();) {
						ContextEntity ownAttr = (ContextEntity) it13.next();
						String ownAttrName = (String) ownAttr.getName();
						// System.out.println("ownAttr:" + ownAttrName);
					}
				} else if (element.hasOwnAttribs()) {

					for (Iterator it13 = element.ownAttribsIterator(); it13
							.hasNext();) {
						ContextEntity ownAttr = (ContextEntity) it13.next();
						String ownAttrName = (String) ownAttr.getName();
						// System.out.println("ownAttrWithoutOwnObj:" +
						// ownAttrName);

						// for(Iterator ittop = topElement.ownAttribsIterator();
						// ittop.hasNext();){
						// ContextEntity ownAttr = (ContextEntity) ittop.next();
						// String ownAttrName = ownAttr.getName();
						// System.out.println(ownAttrName);
						OWLNamedClass parentClass = (OWLNamedClass) ProtegeUI
								.getSelectionDialogFactory().selectClass(
										parent,
										owlModel,
										clsDiseaseModel,
										"Select a parent class for (top) "
												+ ownAttrName);
                        
						OWLNamedClass attrClass = null;
						
					    if(owlModel.getOWLNamedClass(ownAttrName) == null){
						    attrClass = owlModel
								.createOWLNamedSubclass(ownAttrName,
										parentClass);
					    }else{
					    	attrClass = owlModel.getOWLNamedClass(ownAttrName);
					    }
						if (parentClass.getBrowserText().equals("DiseaseType")) {

							if (mapOwnAttrs.containsKey("hasDiseaseType")) {
								Collection values = (Collection) mapOwnAttrs
										.get("hasDiseaseType");
								values.add(ownAttrName);
								mapOwnAttrs.put("hasDiseaseType", values);
							} else {
								Collection values = new ArrayList();
								values.add(ownAttrName);
								mapOwnAttrs.put("hasDiseaseType", values);
							}

						} else if (parentClass.getBrowserText().equals(
								"AnatomicalSite")) {
							if (mapOwnAttrs.containsKey("hasAnatomicalSite")) {
								Collection values = (Collection) mapOwnAttrs
										.get("hasAnatomicalSite");
								values.add(ownAttrName);
								mapOwnAttrs.put("hasAnatomicalSite", values);
							} else {
								Collection values = new ArrayList();
								values.add(ownAttrName);
								mapOwnAttrs.put("hasAnatomicalSite", values);
							}
						} else if (parentClass.getBrowserText().equals(
								"TemporalRelation")) {
							if (mapOwnAttrs.containsKey("hasTemporalRelation")) {
								Collection values = (Collection) mapOwnAttrs
										.get("hasTemporalRelation");
								values.add(ownAttrName);
								mapOwnAttrs.put("hasTemporalRelation", values);
							} else {
								Collection values = new ArrayList();
								values.add(ownAttrName);
								mapOwnAttrs.put("hasTemporalRelation", values);
							}
						}

					}

					this.createRules(mapOwnAttrs, element, selectedCls, null);
					


					LatticeElementCollection subelements = element
							.getChildren();

					for (Iterator itbot = subelements.iterator(); itbot
							.hasNext();) {
						LatticeElement subelement = (LatticeElement) itbot
								.next();
						Map mapOwnAttrs1 = new HashMap();
						
						//String ownObjName = "";
						
						for (Iterator it12 = subelement.ownObjectsIterator(); it12
								.hasNext();) {
							
						
							ContextEntity ownObj = (ContextEntity) it12.next();
							String ownObjName = (String) ownObj.getName();
							OWLNamedClass objClass = this.getClassNameFromLabel(ownObjName, selectedCls);

							System.out.println("ownObj:" + ownObjName);

							for (Iterator it13 = subelement
									.ownAttribsIterator(); it13.hasNext();) {
								ContextEntity ownAttr = (ContextEntity) it13
										.next();
								String ownAttrName = (String) ownAttr.getName();
								System.out.println("ownAttr:" + ownAttrName);
								
								OWLNamedClass parentClass = (OWLNamedClass) ProtegeUI
								.getSelectionDialogFactory().selectClass(
										parent,
										owlModel,
										clsDiseaseModel,
										"Select a parent class for "
												+ ownAttrName);

						OWLNamedClass attrClass = owlModel
								.createOWLNamedSubclass(ownAttrName,
										parentClass);
						
						if (parentClass.getBrowserText().equals("DiseaseType")) {

							if (mapOwnAttrs1.containsKey("hasDiseaseType")) {
								Collection values = (Collection) mapOwnAttrs1
										.get("hasDiseaseType");
								values.add(ownAttrName);
								mapOwnAttrs1.put("hasDiseaseType", values);
							} else {
								Collection values = new ArrayList();
								values.add(ownAttrName);
								mapOwnAttrs1.put("hasDiseaseType", values);
							}

						} else if (parentClass.getBrowserText().equals(
								"AnatomicalSite")) {
							if (mapOwnAttrs1.containsKey("hasAnatomicalSite")) {
								Collection values = (Collection) mapOwnAttrs1
										.get("hasAnatomicalSite");
								values.add(ownAttrName);
								mapOwnAttrs1.put("hasAnatomicalSite", values);
							} else {
								Collection values = new ArrayList();
								values.add(ownAttrName);
								mapOwnAttrs1.put("hasAnatomicalSite", values);
							}
						} else if (parentClass.getBrowserText().equals(
								"TemporalRelation")) {
							if (mapOwnAttrs1.containsKey("hasTemporalRelation")) {
								Collection values = (Collection) mapOwnAttrs1
										.get("hasTemporalRelation");
								values.add(ownAttrName);
								mapOwnAttrs1.put("hasTemporalRelation", values);
							} else {
								Collection values = new ArrayList();
								values.add(ownAttrName);
								mapOwnAttrs1.put("hasTemporalRelation", values);
							}
						}

					}
							
							this.createRules(mapOwnAttrs1, subelement, selectedCls, objClass);						
								
					}
	
						}
					


					}

				}
			

			LatticeElement botElement = lattice.getBottom();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	private OWLNamedClass getClassNameFromLabel(String label, OWLNamedClass selectedCls){
		OWLNamedClass ret = null;
		RDFProperty propLabel = owlModel.getRDFProperty("rdfs:label");
		//String rootNode = "ICD10_Terms";
		//OWLNamedClass rootCls = owlModel.getOWLNamedClass(rootNode);
		Collection allClasses = selectedCls.getSubclasses(true);
		for(Iterator it = allClasses.iterator(); it.hasNext();){
			OWLNamedClass subclass = (OWLNamedClass) it.next();
			String clsLabel = (String)subclass.getPropertyValue(propLabel);
			if(clsLabel.equals(label)){
				ret = subclass;
				break;
			}
			
		}
		
		return ret;
		
	}

	private void AddValuesToMapContainer(Map map, String type, String value) {
		if (map.containsKey(type)) {
			Collection values = (Collection) map.get(type);
			values.add(value);
			map.put(type, values);
		} else {
			Collection values = new ArrayList();
			values.add(value);
			map.put(type, values);
		}

		// return map;

	}

	private void createRules(Map mapOwnAttrs, LatticeElement element,
			OWLNamedClass selectedCls,  OWLNamedClass objClass) {
		//String conceptCode = "Concept_Code";
		//RDFProperty propCode = owlModel.getRDFProperty(conceptCode);
		SWRLFactory factory = new SWRLFactory(owlModel);
		Collection dtValues = (Collection) mapOwnAttrs.get("hasDiseaseType");
		Collection dtRules = new ArrayList();
		if(dtValues != null)
		    dtRules = this.getRuleForDiseaseType(dtValues);
		
		
		Collection asValues = (Collection) mapOwnAttrs.get("hasAnatomicalSite");
		
		Collection asRules = new ArrayList();
		if(asValues != null)
			asRules = this.getRuleForAnatomicalSite(asValues);
		Collection trValues = (Collection) mapOwnAttrs
				.get("hasTemporalRelation");
		
		Collection trRules = new ArrayList();
		if(trValues != null)
		    trRules = this.getRuleForTemporalRelation(trValues);


		try {
			// top node
			if (!element.hasOwnObjects()) {
				Collection comRule1 = this.combineRules(dtRules, asRules);
				Collection comRule2 = this.combineRules(comRule1, trRules);

				for (Iterator it = comRule2.iterator(); it.hasNext();) {
					String rule = (String) it.next();

					//System.out.println(rule + " -> "
							//+ selectedCls.getBrowserText() + "(?d)");
					
					//String clsCode = (String)selectedCls.getPropertyValue(propCode);
                    //OWLNamedClass tempCategory = owlModel.getOWLNamedClass("TempCategory");
					
					//OWLNamedClass codeCls = owlModel.createOWLNamedClass(clsCode);
					factory.createImp(rule + " " + SWRLParser.IMP_CHAR + " "
							+ selectedCls.getBrowserText() + "(?d)");

				}

				// factory.createImp("infarction(?d) " + SWRLParser.AND_CHAR + "
				// hasAnatomicalSite(?d, ?a) " + SWRLParser.AND_CHAR + "
				// myocardium(?a) " + SWRLParser.IMP_CHAR + " myocardium(?d)");

			} else {
				
				Collection topRules = new ArrayList();
				topRules.add(selectedCls.getBrowserText() + "(?d)");
				
				Collection comRule1 = new ArrayList();
				Collection comRule2 = new ArrayList();
				Collection comRule3 = new ArrayList();
				
			    if(dtRules != null){
					comRule1 = this.combineRules(topRules, dtRules);
					this.createSWRLImp(comRule1, objClass);
			    }
				if(asRules != null){
					comRule2 = this.combineRules(topRules, asRules);
					this.createSWRLImp(comRule2, objClass);
				}
				
				if(trRules != null){
					comRule3 = this.combineRules(topRules, trRules);
					this.createSWRLImp(comRule3, objClass);
				}
				
                
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	
	private void createSWRLImp(Collection rules, OWLNamedClass objClass){
		//String conceptCode = "Concept_Code";
		//RDFProperty propCode = owlModel.getRDFProperty(conceptCode);
		SWRLFactory factory = new SWRLFactory(owlModel);		
		try{
			for (Iterator it = rules.iterator(); it.hasNext();) {
				String rule = (String) it.next();

				System.out.println(rule + " -> "
						+ objClass.getName() + "(?d)");
				
				//String clsCode = (String)objClass.getPropertyValue(propCode);
                //OWLNamedClass tempCategory = owlModel.getOWLNamedClass("TempCategory");
				
				//OWLNamedClass codeCls = owlModel.createOWLNamedClass(clsCode);

				factory.createImp(rule + " " + SWRLParser.IMP_CHAR + " "
						+ objClass.getBrowserText() + "(?d)");

			}			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private Collection getRuleForDiseaseType(Collection values) {
		Collection ret = new ArrayList();
		for (Iterator it = values.iterator(); it.hasNext();) {
			String value = (String) it.next();

			ret.add(value + "(?d)");
		}

		return ret;
	}

	private Collection getRuleForAnatomicalSite(Collection values) {
		Collection ret = new ArrayList();
		for (Iterator it = values.iterator(); it.hasNext();) {
			String value = (String) it.next();

			ret.add(SWRLParser.AND_CHAR + " hasAnatomicalSite(?d, ?a) "
					+ SWRLParser.AND_CHAR + " " + value + "(?a)");
		}

		return ret;
	}

	private Collection getRuleForTemporalRelation(Collection values) {
		Collection ret = new ArrayList();
		for (Iterator it = values.iterator(); it.hasNext();) {
			String value = (String) it.next();

			ret.add(SWRLParser.AND_CHAR + " hasTemporalRelation(?d, ?t) "
					+ SWRLParser.AND_CHAR + " " + value + "(?t)");
		}

		return ret;
	}

	private Collection combineRules(Collection rules1, Collection rules2) {
		Collection ret = new ArrayList();
		for (Iterator it1 = rules1.iterator(); it1.hasNext();) {
			String rule1 = (String) it1.next();

			for (Iterator it2 = rules2.iterator(); it2.hasNext();) {
				String rule2 = (String) it2.next();
				StringBuffer rule = new StringBuffer();
				rule.append(rule1);

				rule.append(rule2);

				ret.add(rule.toString());
			}
		}

		return ret;

	}

	

	
	private String getLatticeNodeNumAndAnonymousNodeNum(Lattice lattice){
		StringBuffer sb = new StringBuffer();
		int latticeNodeNum = lattice.conceptsCount();
        int anonymousNodeNum = 0;
		for(int i = 0; i < latticeNodeNum; i++){
           LatticeElement element = lattice.elementAt(i);

           if(!element.hasOwnObjects()){
        	   if(!element.equals(lattice.getTop()) && !element.equals(lattice.getBottom())){
        		   anonymousNodeNum++;
        		   
        	   }
           }
	    }
	    
	    sb.append(latticeNodeNum + "|" + anonymousNodeNum + "|");
		
		return sb.toString();
		
	}
	
	private String getOutlierNodeNum(Lattice lattice){
		StringBuffer sb = new StringBuffer();
		int latticeNodeNum = lattice.conceptsCount();
        int anonymousNodeNum = 0;
        Collection outlierNodes = new ArrayList();
		for(int i = 0; i < latticeNodeNum; i++){
           LatticeElement element = lattice.elementAt(i);
           LatticeElementCollection children = element.getChildren();
           if(element.hasOwnObjects()){
        	   for(int j = 0; j < latticeNodeNum; j++){
        		   LatticeElement element1 = lattice.elementAt(j);
        		   if(element1.hasOwnObjects() && !element1.equals(element)){
        			   for(Iterator it = children.iterator(); it.hasNext();){
        				   LatticeElement child = (LatticeElement)it.next();
        				   if(child.equals(element1)){
        					   for(Iterator it1 = element.ownObjectsIterator(); it1.hasNext();){
        						   ContextEntity entity = (ContextEntity)it1.next();
        						   //sb.append(entity.getName() + "\n");
        						   if(!entity.getName().equals("Obj 1") && !outlierNodes.contains(entity.getName())){
        							   outlierNodes.add(entity.getName());
        						   }
        					   }
        				   }
        			   }
        		   }
        	   }
           }
	    }
		sb.append(outlierNodes.size() + "|");
	    for(Iterator it = outlierNodes.iterator(); it.hasNext();){
	    	String name = (String) it.next();
	    	sb.append(name + "|");
	    }
		
		return sb.toString();
		
	}	
	
}
