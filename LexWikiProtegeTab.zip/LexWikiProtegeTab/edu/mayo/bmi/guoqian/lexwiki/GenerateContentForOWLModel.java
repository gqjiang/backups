package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;

import edu.stanford.smi.protegex.owl.model.*;


public class GenerateContentForOWLModel {

	private OWLModel kb;
	private OWLNamedClass selectedCls;
	private StringBuffer result;
	
	public GenerateContentForOWLModel(OWLModel kb, 
			OWLNamedClass selectedCls){
		this.kb = kb;
		this.selectedCls = selectedCls;
		result = new StringBuffer();
		result.append("== Annotations ==\n");
		result.append(this.getType());
		result.append(this.getAnnotations());
		result.append("== Asserted Conditions ==\n");
		result.append(this.getAssertedConditions(selectedCls));
		//result.append("== Inherited Conditions ==\n");
		//result.append(this.getInheritedConditions());
		result.append("== Properties ==\n");
		result.append(this.getProperties());
		result.append("== Disjoints ==\n");
		result.append(this.getDisjoints());
		result.append(this.getSuperClsesNames());
		
	}
	
	public String getContent(){
		return result.toString();
	}
	
	private String getAnnotations(){
		StringBuffer sb = new StringBuffer();
		RDFProperty labelProperty = kb.getRDFSLabelProperty();
		RDFProperty commentProperty = kb.getRDFProperty("rdfs:comment");
		Collection labels = selectedCls.getPropertyValues(labelProperty);
		for(Iterator it = labels.iterator(); it.hasNext();){
			RDFSLiteral value = (RDFSLiteral) it.next();
			sb.append(" * [[Label:=" + value.getString() + "]]\n");
		}
		
		Collection comments = selectedCls.getPropertyValues(commentProperty);
		for(Iterator it = comments.iterator(); it.hasNext();){
			RDFSLiteral value = (RDFSLiteral) it.next();
			sb.append(" * [[Comment:=" + value.getString() + "]]\n");
		}
		
		return sb.toString();
	}
	
	private String getType(){
		StringBuffer sb = new StringBuffer();
		if(selectedCls.isDefinedClass()){
			sb.append(" * [[Role:=fully defined]]\n");
			
		}else{
			sb.append(" * [[Role:=primitive]]\n");
			
		}
		
		return sb.toString();
	}
	
	private String getAssertedConditions(OWLNamedClass cls){
		StringBuffer sb = new StringBuffer();
		if(!cls.isDefinedClass()){
		    Collection conditions = selectedCls.getRestrictions();
		    for(Iterator it = conditions.iterator(); it.hasNext();){
			    OWLRestriction value = (OWLRestriction) it.next();
		    	RDFProperty onProp = value.getOnProperty();
			    //sb.append(" * {{DLAssertion|" + value.getBrowserText() + "}}\n");
			    if(value instanceof OWLAllValuesFrom){

			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
			    			value.getFillerProperty().getBrowserText() + "\n");
			        if(this.getCompoundIndex(value.getFillerText()) >= 0){
			        	RDFSClass _operand = kb.createRDFSClassFromExpression(value.getFillerText());
			        	sb.append(this.processOperand(_operand, this.getCompoundIndex(value.getFillerText())));
			        }else{
			        	sb.append(" ** [[" +
			       			 onProp.getName() + "::Category:" + value.getFillerText() + "]]\n");
			        }
			    /*
			    }else if(value instanceof OWLSomeValuesFrom){
			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
			    			value.getFillerProperty().getBrowserText() + " [[" +
			    			onProp.getName() + "::Category:" + value.getFillerText() + "]]\n");
			    	
			    }else if(value instanceof OWLHasValue){
			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
			    			value.getFillerProperty().getBrowserText() + " [[" +
			    			onProp.getName() + "::Category:" + value.getFillerText() + "]]\n");
			    }else if(value instanceof OWLMinCardinality){
			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
			    			value.getFillerProperty().getBrowserText() + " [[" +
			    			onProp.getName() + "::" + value.getFillerText() + "]]\n");

			    }else if(value instanceof OWLMaxCardinality){
			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
			    			value.getFillerProperty().getBrowserText() + " [[" +
			    			onProp.getName() + "::" + value.getFillerText() + "]]\n");

			    }else if(value instanceof OWLCardinality){
			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
			    			value.getFillerProperty().getBrowserText() + " [[" +
			    			onProp.getName() + "|" + value.getFillerText() + "]]\n");
                */
			    }else{
			    	sb.append(" * [[Relation:" + onProp.getName() + "]] " +
		    			value.getFillerProperty().getBrowserText() + " [[" +
		    			onProp.getName() + "|" + value.getFillerText() + "]]\n");
			    	
			    }
		    }
		}else{
			sb.append(this.getEquvalentClass(cls));
		}
		
		
		return sb.toString();
	}
	

	
	private String getEquvalentClass(OWLNamedClass cls){
		StringBuffer sb = new StringBuffer();
		Collection conditions = cls.getEquivalentClasses();
		for(Iterator it = conditions.iterator(); it.hasNext();){
			RDFSClass value = (RDFSClass) it.next();
			//sb.append(" * {{DLAssertion|" + value.getBrowserText() + "}}\n");
	        if(value instanceof OWLIntersectionClass){
	        	Collection operands = ((OWLIntersectionClass)value).getOperands();
				for(Iterator it1 = operands.iterator(); it1.hasNext();){
					RDFSClass operand = (RDFSClass)it1.next();
					if(this.getCompoundIndex(operand.getBrowserText()) >= 0){
						sb.append(this.processOperand(operand, this.getCompoundIndex(operand.getBrowserText())));
					}else{
				      	sb.append(" * [[:Category:" + operand.getBrowserText() + "]]\n");
				    }
				}
	        		
	        }else{
	        	sb.append(" * [[:Category:"  + value.getBrowserText() + "]]\n");
	        }
		}
		
		
		return sb.toString();
	}
	
	private int getCompoundIndex(String name){
		int result = -1;
		//String name = operand.getBrowserText();
		if(name.indexOf(" some ") >= 0){
			result = 1;
		}else if(name.indexOf(" or ") >= 0){
			result = 2;
		}else if (name.indexOf("not ") >= 0){
			result = 3;
		}else if (name.indexOf(" min ") >= 0){
			result = 4;
		}else if (name.indexOf(" max ") >= 0){
			result = 5;
		}else if (name.indexOf("{") >= 0){
			result = 6;
		}else if (name.indexOf(" has ") >= 0){
			result = 7;
		}
		
		return result;
	}
	
	private String processOperand(RDFSClass operand, int index){
		StringBuffer sb = new StringBuffer();
		switch(index){
		    case 1:
		    	RDFProperty onProp1 = ((OWLRestriction)operand).getOnProperty();
		    	sb.append(" ** [[Relation:" + onProp1.getName() + "]] " +
		    			((OWLRestriction)operand).getFillerProperty().getBrowserText() + " [[" +
		    			onProp1.getName() + "::Category:" + ((OWLRestriction)operand).getFillerText() + "]]\n");
                break;
		    case 2:
	        	Collection operands2 = ((OWLUnionClass)operand).getOperands();
				for(Iterator it2 = operands2.iterator(); it2.hasNext();){
					RDFSClass operand2 = (RDFSClass)it2.next();
		        	sb.append(" ** '''or''' [[:Category:" + operand2.getBrowserText() + "]]\n");
				}                
				break;
		    case 3:
        		RDFSClass operand3 = ((OWLComplementClass)operand).getComplement();
	        	sb.append(" ** '''not''' [[:Category:" + operand3.getBrowserText() + "]]\n");
			
				break;

		    case 4:
		    	RDFProperty onProp4 = ((OWLRestriction)operand).getOnProperty();
		    	sb.append(" ** [[" + onProp4.getName() + "::" + ((OWLRestriction)operand).getFillerText() + "]]\n");
                break;
		    case 5:
		    	RDFProperty onProp5 = ((OWLRestriction)operand).getOnProperty();
		    	sb.append(" ** [[" + onProp5.getName() + "::" + ((OWLRestriction)operand).getFillerText() + "]]\n");
                break;
		    case 6:
	        	Collection operands6 = ((OWLEnumeratedClass)operand).getOneOf();
				for(Iterator it6 = operands6.iterator(); it6.hasNext();){
					OWLIndividual operand6 = (OWLIndividual)it6.next();
		        	sb.append(" ** [[" + operand6.getBrowserText() + "]]\n");
				}

				break;
		    case 7:
		    	RDFProperty onProp7 = ((OWLRestriction)operand).getOnProperty();				
		    	sb.append(" ** [[" + onProp7.getName() + "::" + ((OWLRestriction)operand).getFillerText() + "]]\n");
		    	break;
		    	
		}
		
		return sb.toString();
	}


	
	
	private String getInheritedConditions(){
		StringBuffer sb = new StringBuffer();
		Collection superclses = selectedCls.getSuperclasses(false);
		for(Iterator it = superclses.iterator(); it.hasNext();){
			RDFSClass supercls = (RDFSClass) it.next();
			
			if(supercls instanceof OWLNamedClass)
		        sb.append(this.getAssertedConditions((OWLNamedClass)supercls));
		}
	
		
		return sb.toString();
	}
	
	private String getProperties(){
		StringBuffer sb = new StringBuffer();
		Collection props = selectedCls.getAssociatedProperties();
		for(Iterator it = props.iterator(); it.hasNext();){
			RDFProperty prop = (RDFProperty)it.next();
			sb.append(" * [[Relation:" + prop.getBrowserText() + "]]\n");
		}
		
		return sb.toString();
	}
	
	private String getDisjoints(){
		StringBuffer sb = new StringBuffer();
		Collection disjoints = selectedCls.getDisjointClasses();
		for(Iterator it = disjoints.iterator(); it.hasNext();){
			OWLNamedClass value = (OWLNamedClass) it.next();
			sb.append(" * [[:Category:" + value.getBrowserText() + "]]\n");
		}

		
		return sb.toString();
	}
	
	private String getSuperClsesNames(){
		StringBuffer sb = new StringBuffer();
		Collection superClses = selectedCls.getSuperclasses(false);
		Iterator it = superClses.iterator();
		while(it.hasNext()){
			RDFSClass superCls = (RDFSClass)it.next();
			if(superCls instanceof OWLNamedClass)
			   sb.append(" [[Category:" + superCls.getBrowserText() + "]]\n");
		}
		return sb.toString();
	}
}

