package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protegex.owl.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;
import java.net.MalformedURLException;
import java.net.URL;

import conexp.core.*;
import conexp.frontend.*;
import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

import org.LexGrid.LexBIG.LexBIGService.*;

public class OntologyExportToWikiForLexgridPanel extends JPanel implements
		ActionListener {

	private KnowledgeBase kb;

	private JPanel leftPanel;

	private JPanel rightPanel;

	private JSplitPane mainPane;

	private JLabel urlLabel;

	private JTextField jtfURL;

	private JLabel unLabel;

	private JTextField jtfUserName;

	private JLabel pwLabel;

	private JPasswordField jtfPassWord;

	private JButton btnCreateContent;

	private JButton btnGenerateTemplateContent;

	private JButton btnReadFromWiki;

	private JButton btnDetectChanges;

	private JLabel jlUrl;

	private JLabel jlUser;

	private JLabel jlPassword;

	private JLabel jlPrefix;

	private JTextField jtfUrl;

	private JTextField jtfUser;

	private JPasswordField jpfPassword;

	private JTextField jtfPrefix;

	private JLabel labelCodeSystems;

	private JComboBox jcbCodeSystems;

	private JLabel labelNameSpaces;

	private JComboBox jcbNameSpaces;

	private JList listConcepts;

	private JScrollPane listScrollPane;

	private JButton btnGetCodeSet;

	private JTextField jtfCodeSetFromFile;

	private JButton btnCodeSetFromFile;

	private JLabel labelRDFUrl;

	private JTextField jtfRDFUrl;

	private JButton btnRDFParsing;

	private String defaultURL;

	private JTextArea textArea;

	private JScrollPane scrollPane;

	private JLabel contentLabel;

	private JButton btnExport;

	private JButton btnBatchExport;

	private JButton btnBatchExportForTemplateContent;

	private JButton btnSave;

	private GenerateContentForLexgridModel model = new GenerateContentForLexgridModel();

	// private GenerateTemplateContentForLexgridModel templateModel =
	// new GenerateTemplateContentForLexgridModel();
	// private GenerateTemplateContentForNCITOwl templateModel =
	// new GenerateTemplateContentForNCITOwl();

	// private GenerateTemplateContentForMayoTable22Final templateModel =
	// new GenerateTemplateContentForMayoTable22Final();

	private GenerateTemplateContentForLexWikiICD10 templateModel = new GenerateTemplateContentForLexWikiICD10();
	private GenerateTemplateContentForLexWikiICD10IndexCSV indexModel;

	//private GenerateTemplateContentForICD10MorphOther templateModel = new GenerateTemplateContentForICD10MorphOther();
	
	// private GenerateICD10MappingsFromNCIMeta nciMetaModel =
	// new GenerateICD10MappingsFromNCIMeta();

	//private GenerateTemplateContentForICECI templateModel =
	 //new GenerateTemplateContentForICECI();
	//private GenerateTemplateContentForOrphanet templateModel =
		 //new GenerateTemplateContentForOrphanet();
	
	//private GenerateTemplateContentForLexWikiICD11 templateModel =
	   //new GenerateTemplateContentForLexWikiICD11();

	//private GenerateTemplateContentForLexWikiICD11Draft templateModel =
	  // new GenerateTemplateContentForLexWikiICD11Draft();
	
	
	//private GenerateTemplateContentForSCT templateModel =
		   //new GenerateTemplateContentForSCT();
	

	final String[] namespaces = { "NONE", "ICD", "ICD11", "ICD10", "ICD10Index", "ICD10AM", "ICD10CM",
			"ICECI", "Orphanet", "ICDO", "ICD9CM", "MT", "MU", "ICF", "NCI", "SN", "SCT",
			"SNOMEDCT", "ICD9", "ICD9d", "ICD9ei", "ICD9i", "ICD9n" };

	public OntologyExportToWikiForLexgridPanel(KnowledgeBase kb) {
		this.kb = kb;
		this.initUI();

	}

	private void initUI() {
		leftPanel = new JPanel(new BorderLayout());
		rightPanel = new JPanel(new BorderLayout());

		listConcepts = new JList();
		listConcepts
				.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listConcepts.addListSelectionListener(new ListSelectionChanged());

		listScrollPane = new JScrollPane(listConcepts);
		listScrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		// clsesPanel = new ClsesPanel(kb.getProject());
		leftPanel.add(listScrollPane, BorderLayout.CENTER);

		JPanel urlPanel = new JPanel();
		urlLabel = new JLabel("Wiki URL: ");
		jtfURL = new JTextField(40);
		// jtfURL.setText("http://wiktolog.com/index.php");
		jtfURL.setText("http://bmidev.mayo.edu/lexwiki/index.php");
		urlPanel.add(urlLabel);
		urlPanel.add(jtfURL);

		JPanel unPanel = new JPanel();
		unLabel = new JLabel("Login name: ");
		jtfUserName = new JTextField(10);
		jtfUserName.setText("LexWikiAdmin");
		unPanel.add(unLabel);
		unPanel.add(jtfUserName);

		JPanel pwPanel = new JPanel();
		pwLabel = new JLabel("Password: ");
		jtfPassWord = new JPasswordField(10);
		jtfPassWord.setText("lexlex");
		pwPanel.add(pwLabel);
		pwPanel.add(jtfPassWord);

		// JLabel projLabel = new JLabel("Project: ");

		JPanel codeSystemsPanel = new JPanel();
		labelCodeSystems = new JLabel("Availabe Code Systems");
		String[] tempCodes = { "UMLS SemNet", "NCI_Thesaurus" };
		jcbCodeSystems = new JComboBox(model.getAvailableCodeSystems());
		jcbCodeSystems.addActionListener(this);
		codeSystemsPanel.add(labelCodeSystems);
		codeSystemsPanel.add(jcbCodeSystems);
		btnGetCodeSet = new JButton("Get Code Set...");
		btnGetCodeSet.addActionListener(this);
		codeSystemsPanel.add(btnGetCodeSet);

		JPanel unpwPanel = new JPanel(new GridLayout(1, 2));
		unpwPanel.add(unPanel);
		unpwPanel.add(pwPanel);

		JPanel upperPanel = new JPanel(new GridLayout(3, 1));
		upperPanel.add(urlPanel);
		upperPanel.add(unpwPanel);
		upperPanel.add(codeSystemsPanel);

		leftPanel.add(upperPanel, BorderLayout.NORTH);

		JPanel btnPanel = new JPanel(new GridLayout(4, 1));

		JPanel nsPanel = new JPanel();
		labelNameSpaces = new JLabel("Namespace: ");
		jcbNameSpaces = new JComboBox(this.namespaces);
		jcbNameSpaces.addActionListener(this);
		nsPanel.add(labelNameSpaces);
		nsPanel.add(jcbNameSpaces);

		JPanel btnCreatePanel = new JPanel();
		btnCreatePanel.add(nsPanel);

		btnCreateContent = new JButton("Generate Wikitext...");
		btnCreateContent.addActionListener(this);
		btnCreatePanel.add(btnCreateContent);

		// JPanel btnGeneratePanel = new JPanel();
		btnGenerateTemplateContent = new JButton("Generate Template...");
		btnGenerateTemplateContent.addActionListener(this);
		btnCreatePanel.add(btnGenerateTemplateContent);

		JPanel btnReadPanel = new JPanel();
		// btnReadFromWiki = new JButton("Read from Wiki...");
		// btnReadFromWiki.addActionListener(this);
		// btnReadPanel.add(btnReadFromWiki);

		jlUrl = new JLabel("dburl:");
		jlPrefix = new JLabel("dbprefix:");
		jlUser = new JLabel("dbuser:");
		jlPassword = new JLabel("dbpassword:");

		jtfUrl = new JTextField(20);
		jtfUrl.setText("jdbc:mysql://bmidev.mayo.edu/lexwikidb");
		jtfPrefix = new JTextField(4);
		jtfPrefix.setText("lw_");
		jtfUser = new JTextField(10);
		jtfUser.setText("lexwikiuser");
		jpfPassword = new JPasswordField(10);
		jpfPassword.setText("lexlex");

		JPanel jpUrl = new JPanel();
		jpUrl.add(jlUrl);
		jpUrl.add(jtfUrl);
		jpUrl.add(jlPrefix);
		jpUrl.add(jtfPrefix);

		JPanel jpUser = new JPanel();
		jpUser.add(jlUser);
		jpUser.add(jtfUser);
		jpUser.add(jlPassword);
		jpUser.add(jpfPassword);

		btnDetectChanges = new JButton("Detect Changes...");
		btnDetectChanges.addActionListener(this);
		btnReadPanel.add(btnDetectChanges);

		btnPanel.add(btnCreatePanel);
		btnPanel.add(jpUrl);
		btnPanel.add(jpUser);
		// btnPanel.add(btnGeneratePanel);
		btnPanel.add(btnReadPanel);
		// btnPanel.add(btnExportPanel);

		leftPanel.add(btnPanel, BorderLayout.SOUTH);

		JPanel rightCodeSetPanel = new JPanel();
		JLabel labelCodeSet = new JLabel("    File: ");
		jtfCodeSetFromFile = new JTextField(40);

		String icdfilename = "C:\\whoproject\\icd10index.csv";
		jtfCodeSetFromFile.setText(icdfilename);

		JPanel btnCodeSetFromFilePanel = new JPanel();
		btnCodeSetFromFile = new JButton("Add CodeSet...");
		btnCodeSetFromFile.addActionListener(this);
		btnCodeSetFromFilePanel.add(btnCodeSetFromFile);

		rightCodeSetPanel.add(labelCodeSet);
		rightCodeSetPanel.add(jtfCodeSetFromFile);
		rightCodeSetPanel.add(btnCodeSetFromFilePanel);

		JPanel rdfUrlPanel = new JPanel();
		labelRDFUrl = new JLabel("URL:");
		jtfRDFUrl = new JTextField(60);
		defaultURL = "http://bmidev.mayo.edu/lexwiki/index.php/Special:ExportRDF";
		jtfRDFUrl.setText(defaultURL);
		JPanel btnRDFParsingPanel = new JPanel();
		btnRDFParsing = new JButton("Parse...");
		btnRDFParsing.addActionListener(this);
		btnRDFParsingPanel.add(btnRDFParsing);

		rdfUrlPanel.add(labelRDFUrl);
		rdfUrlPanel.add(jtfRDFUrl);
		rdfUrlPanel.add(btnRDFParsingPanel);

		JPanel upperRightPanel = new JPanel(new GridLayout(2, 1));
		upperRightPanel.add(rightCodeSetPanel);
		upperRightPanel.add(rdfUrlPanel);

		// contentLabel = new JLabel(" Contents: ");
		rightPanel.add(upperRightPanel, BorderLayout.NORTH);

		scrollPane = new JScrollPane();
		textArea = new JTextArea();
		scrollPane.getViewport().add(textArea);
		rightPanel.add(scrollPane, BorderLayout.CENTER);

		JPanel btnExportPanel = new JPanel();
		btnExport = new JButton("Export to Wiki...");
		btnExport.addActionListener(this);
		btnExportPanel.add(btnExport);

		btnBatchExport = new JButton("Batch Export...");
		btnBatchExport.addActionListener(this);
		btnExportPanel.add(btnBatchExport);

		btnBatchExportForTemplateContent = new JButton(
				"Batch Template Content...");
		btnBatchExportForTemplateContent.addActionListener(this);
		btnExportPanel.add(btnBatchExportForTemplateContent);
		btnSave = new JButton("Save...");
		btnSave.addActionListener(this);
		btnExportPanel.add(btnSave);

		rightPanel.add(btnExportPanel, BorderLayout.SOUTH);

		mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, leftPanel,
				rightPanel);
		mainPane.setOneTouchExpandable(true);

		this.setLayout(new BorderLayout());
		this.add(mainPane, BorderLayout.CENTER);

	}

	public void actionPerformed(ActionEvent e) {

		Object s = e.getSource();
		String ns = this.getNamespace();

		if (s == btnGetCodeSet) {
			if(ns.equals("ICD10Index")){
				this.getCodeSetFromIndexFile();
			}else{
			    this.getCodeSet();
			}
		}

		if (s == btnCreateContent) {
			if(ns.equals("ICD10Index")){
				this.generateContentForIndexName();
			}else{
			    this.generateContent();
			}
		}

		if (s == btnGenerateTemplateContent) {
			if(ns.equals("ICD10Index")){
				this.generateTemplateContentForIndexName();
			}else{
			    this.generateTemplateContent();
			}
		}

		// if(s == btnReadFromWiki){
		// this.readContentFromWiki();
		// }

		if (s == btnDetectChanges) {
			this.detectChanges();
		}

		if (s == btnCodeSetFromFile) {
			this.getCodeSetFromFileToTextArea();
		}

		if (s == btnRDFParsing) {
			this.getLexWikiRDFOutputParsed();
		}

		if (s == btnExport) {
			if(ns.equals("ICD10Index")){
				this.exportIndexContentToWiki();
			}else{
			    this.exportContentToWiki();
			}
		}

		if (s == btnBatchExport) {
			this.batchExportContentToWiki();
			// this.getAllAssociations();
		}

		if (s == btnBatchExportForTemplateContent) {
			this.batchExportTemplateContentToWiki();
		}

		if (s == btnSave) {
			this.saveContentToFile();
		}

	}

	public class ListSelectionChanged implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent lse) {
			String selectedCode = (String) listConcepts.getSelectedValue();
			String[] pairs = selectedCode.split("\\|");
			String ns = getNamespace();
			String codedConcept = "/Category:" + ns + "_"
					+ templateModel.mangle(pairs[1]) + "("
					+ pairs[0] + ")";
			

			String url = defaultURL + codedConcept;
			jtfRDFUrl.setText(url);
		}

	}

	private void getLexWikiRDFOutputParsed() {
		String rdfURL = jtfRDFUrl.getText();
		String ns = this.getNamespace();
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String selectedCode = (String) listConcepts.getSelectedValue();
		String[] pairs = selectedCode.split("\\|");
		String codedConcept = ns + "_"
				+ templateModel.mangle(pairs[1]) + "("
				+ pairs[0] + ")";
		
		
		//Map originalContents = templateModel.getContentMapForConceptCode(
				//selectedCode, localName, ns);

		ChangeSetDetectionModelByRDFParser rdfModel = new ChangeSetDetectionModelByRDFParser(
				rdfURL, kb);

		StringBuffer sb = new StringBuffer();

		//sb.append(rdfModel.getOriginalContents(selectedCode, originalContents));
		sb.append(rdfModel.getParsedContents());

		textArea.setText(sb.toString());		
		
		String pprjCode = ns + " " + pairs[1] + "(" + pairs[0] + ")";
		Cls pprjClsCode = kb.getCls(pprjCode);
		
		if(pprjClsCode != null){
			System.out.println("class name:" + pprjClsCode.getBrowserText());
        
		    rdfModel.createChangeSetUsingAnnotationOntology(pprjClsCode, null);
		

		}

	}

	private void getCodeSetFromFileToTextArea() {

		BufferedReader br = null;
		String fileName = jtfCodeSetFromFile.getText();
		StringBuffer sb = new StringBuffer();
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while (line != null) {
				sb.append(line + "\n");
				line = br.readLine();
			}

			br.close();
			textArea.setText(sb.toString());
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
	
	private void getCodeSetFromIndexFile(){
		String fileName = jtfCodeSetFromFile.getText();
		indexModel = new GenerateTemplateContentForLexWikiICD10IndexCSV(fileName);
		indexModel.getAllContents();
		Object[] codeSet =indexModel.getIndexNames();
		listConcepts.setListData(codeSet);
		listScrollPane.getViewport().add(listConcepts);
		textArea.append("concept number:" + codeSet.length + "\n");
		//textArea.setText(indexModel.getIndexFrequency());
        
		/*
		Context formalcontext = indexModel.getFormalContextAdapter().getContext();
	    FormalLatticeComponentPanel latticePanel = 
	    	new FormalLatticeComponentPanel(formalcontext);
	    scrollPane.getViewport().add(latticePanel, null);
	    latticePanel.setVisible(true);
		*/
		
	}

	private void getCodeSet() {
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);

		Object[] codeSet = templateModel.getAllConceptCodes(localName);
		listConcepts.setListData(codeSet);
		listScrollPane.getViewport().add(listConcepts);
		textArea.setText("concept number:" + codeSet.length + "\n");
		


	}

	private void getCodeSet_nciMetaModel() {
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String ns = this.getNamespace();
		if (ns == null) {
			ns = "NCI";
		}
		/*
		 * Object[] codeSet = model.getAllConceptCodes(localName);
		 * listConcepts.setListData(codeSet);
		 * listScrollPane.getViewport().add(listConcepts);
		 * textArea.setText("concept number:" + codeSet.length + "\n");
		 */

		// Object[] codeSet =
		// nciMetaModel.getAllConceptCodesForICD10(localName);
		// listConcepts.setListData(codeSet);
		// listScrollPane.getViewport().add(listConcepts);
		// textArea.setText("concept number:" + codeSet.length + "\n");
		// textArea.setText(nciMetaModel.getAllICD10Mappings(localName, "ICD10",
		// ns));
	}

	private String getNamespace() {
		String ns = (String) jcbNameSpaces.getSelectedItem();
		if (ns.equals("NONE")) {
			ns = "";
		}
		return ns;
	}
	
	private void generateContentForIndexName(){
		String idxName = (String) listConcepts.getSelectedValue();
		//Context formalcontext = indexModel.getFormalContextAdapterCodeLeadTerms(idxName).getContext();
	    
		Context formalcontext = indexModel.getFormalContextAdapterForNeighbors(idxName).getContext();
		
		Lattice lattice = indexModel.getFormalContextAdapterForNeighbors(idxName).getLattice();
		TransformLatticeToOWL transModel = new TransformLatticeToOWL((OWLModel) kb, lattice);
		//textArea.setText("transform done!");
		FormalLatticeComponentPanel latticePanel = 
	    	new FormalLatticeComponentPanel(formalcontext);
	    scrollPane.getViewport().add(latticePanel, null);
	    latticePanel.setVisible(true);		
		
	}

	private void generateContent() {

		String localName = (String) jcbCodeSystems.getSelectedItem();
		String selectedCode = (String) listConcepts.getSelectedValue();
		String ns = this.getNamespace();

		textArea.setText(model.getContentForConceptCode(selectedCode,
				localName, ns));

	}
	
	private void generateTemplateContentForIndexName(){
		String idxName = (String) listConcepts.getSelectedValue();
		textArea.setText(indexModel.getContentForIndexName(idxName));		
	}
	
	private String getLocatName (String displayName){
		String[] nameVersionPairs = displayName.split("\\|");
		String localName = nameVersionPairs[0];
		
		return localName;		
	}

	private void generateTemplateContent() {
		String ns = this.getNamespace();
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		
		String selectedCode = (String) listConcepts.getSelectedValue();
		textArea.setText(templateModel.getContentForConceptCode(selectedCode,
				localName, ns));
		
		GenerateClaMLXMLForICD clamlModel = new GenerateClaMLXMLForICD();
		clamlModel.getClaMLXMLForConceptCode(selectedCode, localName, ns);
		//clamlModel.getClaMLXMLForBatchExport(localName, ns);
		//**for umls definition processing only 2008/10/29
		//templateModel.getContentForConceptCodeForBatchExport(localName, ns);
		//String codecuilist = templateModel.getICDCodeCUIPaires();
		//String success = templateModel.getDefinitionMapping();
		//textArea.setText(success);
		
		// templateModel.getCodeSuperCodeForICD9CM(localName, ns);
		/*
		 * templateModel.getMapForSuperClass(localName, ns); Map highLevelCodes =
		 * templateModel.getSuperClasses(); for(Iterator it =
		 * highLevelCodes.keySet().iterator(); it.hasNext();){ String code =
		 * (String) it.next();
		 * 
		 * Collection superCodes = (Collection)highLevelCodes.get(code);
		 * for(Iterator it1 = superCodes.iterator(); it1.hasNext();){ String
		 * superCode = (String)it1.next(); textArea.append(code + "|" +
		 * superCode + "\n"); }
		 *  }
		 * 
		 * Collection introCodes = templateModel.getIntroducedIcd9Codes();
		 * textArea.append("=================================\n"); for(Iterator
		 * it1 = introCodes.iterator(); it1.hasNext();){ String introCode =
		 * (String) it1.next(); textArea.append(introCode + "\n"); }
		 * 
		 */
	}

	private void readContentFromWiki() {

		String codedConcept = this.getSelectedConcept();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			textArea.setText(wikiBot.readContentOf(codedConcept).getText());

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	/**
	 * This method compares the contents between a selected category and all
	 * articles in this category
	 */
	private void detectChanges() {
		String codedConcept = this.getSelectedConcept();
		codedConcept = codedConcept.replaceAll(" ", "_");
		Collection articles = new ArrayList();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			for (Iterator it = wikiBot.readCategory(codedConcept); it.hasNext();) {
				String articleName = (String) it.next();
				System.out.println(codedConcept + "-->" + articleName);
				articles.add(articleName);
			}
			String catName = codedConcept.substring(9);
			if (this.getNamespace().equals("")) {
				catName = codedConcept.substring(10);
			}
			System.out.println(catName);
			String dburl = jtfUrl.getText();
			String dbprefix = jtfPrefix.getText();
			String dbuser = jtfUser.getText();
			String dbpassword = new String(jpfPassword.getPassword());
			ChangesDetectionModel cdmodel = new ChangesDetectionModel(catName,
					articles, dbprefix, dburl, dbuser, dbpassword);
			textArea.setText(cdmodel.getChangeSets());
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}
	
	private void exportIndexContentToWiki(){
		String codedIndex = this.getSelectedIndex();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
					"lexwiki", "lexlex");
			// MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(codedIndex);
			sa.setText(textArea.getText());
			wikiBot.writeContent(sa);

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}		
	}

	private void exportContentToWiki() {

		String codedConcept = this.getSelectedConcept();
		String codedConceptTalk = this.getSelectedConceptTalk();
		// codedConcept = templateModel.mangle(codedConcept);
		// normalization
		// codedConcept = codedConcept.replaceAll("\\[", "(");
		// codedConcept = codedConcept.replaceAll("\\]", ")");
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
					"whodev", "icd11");
			// MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(codedConcept);
			sa.setText(textArea.getText());
			SimpleArticle satalk = new SimpleArticle();
			satalk.setLabel(codedConceptTalk);	
			satalk.setText("<Comments />");
			
			wikiBot.writeContent(sa);
			wikiBot.writeContent(satalk);
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	/*
	 * private void getAllAssociations(){ StringBuffer sb = new StringBuffer();
	 * String ns = this.getNamespace(); String localName = (String)
	 * jcbCodeSystems.getSelectedItem(); String textCodes = textArea.getText();
	 * String[] codes = textCodes.split("\n"); Collection colCodes = new
	 * ArrayList(); for(int i = 0; i < codes.length; i++){
	 * colCodes.add(codes[i]); } Map allasses =
	 * templateModel.getAssociationContentForCodeSet(colCodes, localName, ns);
	 * for(Iterator it = allasses.keySet().iterator(); it.hasNext();){ String
	 * code = (String)it.next(); System.out.println(code); Collection asses =
	 * (Collection) allasses.get(code); for(Iterator it1 = asses.iterator();
	 * it1.hasNext();){ String ass = (String) it1.next(); sb.append(code + "|" +
	 * ass + "\n"); } }
	 * 
	 * textArea.setText(sb.toString()); }
	 */
	private void batchExportContentToWiki() {
		String ns = this.getNamespace();
		String displayName = (String) jcbCodeSystems.getSelectedItem();
		String localName = this.getLocatName(displayName);
		String textCodes = textArea.getText();
		String[] codes = textCodes.split("\n");
		Collection colCodes = new ArrayList();
		for (int i = 0; i < codes.length; i++) {
			colCodes.add(codes[i]);
		}
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			// MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			// "lexwiki", "lexlex");
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			// Collection contents =
			// templateModel.getContentForCodeSet(colCodes, localName, ns);
			// wikiBot.writeMultContent(contents.iterator());

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	private void batchExportContentToWiki_bak08232007() {
		String ns = this.getNamespace();
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String selectedCode = (String) listConcepts.getSelectedValue();

		try {
			textArea.append("start time:" + new Date() + "\n");
			// textArea.append(templateModel.getContentForConceptCode(selectedCode,
			// localName, ns));

			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			// MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
			// "lexwiki", "lexlex");
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);
			/*
			 * Collection allContents =
			 * templateModel.getContentArticleForConceptCode(selectedCode,
			 * localName, ns); for(Iterator it = allContents.iterator();
			 * it.hasNext();){ SimpleArticle sa = (SimpleArticle)it.next();
			 * 
			 * if(wikiBot.readContentOf(sa.getLabel()) == null){
			 * textArea.append("null:" + sa.getLabel() + "\n");
			 * //wikiBot.writeContent(sa); }else{ textArea.append("contents:" +
			 * sa.getLabel()); } }
			 * 
			 * //wikiBot.writeMultContent(allContents.iterator());
			 * textArea.append("Number of all contents: " + allContents.size() +
			 * "\n"); textArea.append("Number of all anonymous nodes: " +
			 * templateModel.getAnonymousNodesNumber() + "\n");
			 * textArea.append("ending time:" + new Date() + "\n");
			 */
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void batchExportContentToWiki_bak() {
		String ns = this.getNamespace();
		Collection allContents = new ArrayList();
		try {
			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			textArea.setText("Login...OK\n");

			// get content for selectedCls

			String localName = (String) jcbCodeSystems.getSelectedItem();

			allContents = model.getContentForConceptCodeForBatchExport(
					localName, ns);

			textArea.append("Content preparation...OK\n");

			// export all to wiki
			wikiBot.writeMultContent(allContents.iterator());

			textArea.append("Export to wiki...OK\n");

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	// for nciowl
	private void batchExportTemplateContentToWiki_nciowl() {

		Collection allContents = new ArrayList();
		try {
			textArea.append("start time:" + new Date() + "\n");

			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			// get content for selectedCls
			String ns = this.getNamespace();

			String localName = (String) jcbCodeSystems.getSelectedItem();

			allContents = templateModel.getContentForConceptCodeForBatchExport(
					localName, ns);
			wikiBot.writeMultContent(allContents.iterator());

			textArea.append("Number of all contents: " + allContents.size()
					+ "\n");
			// textArea.append("Number of all anonymous nodes: " +
			// templateModel.getAnonymousNodesNumber() + "\n");
			textArea.append("ending time:" + new Date() + "\n");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	// for mayo table22
	private void batchExportTemplateContentToWiki() {

		Collection allContents = new ArrayList();
		Collection allProperties = new ArrayList();
		try {
			textArea.append("start time:" + new Date() + "\n");

			URL url = new URL(jtfURL.getText());
			String userName = jtfUserName.getText();
			String password = new String(jtfPassWord.getPassword());
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url,
					"whodev", "icd11");

			// MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password);

			// textArea.setText("Login...OK\n");

			// get content for selectedCls
			String ns = this.getNamespace();

			String displayName = (String) jcbCodeSystems.getSelectedItem();
			String localName = this.getLocatName(displayName);

			allContents = templateModel.getContentForConceptCodeForBatchExport(
					localName, ns);
			//allProperties = templateModel.getPropertyNames();

			// Collection nullCodes = templateModel.getNullConceptCodes();
			// for(Iterator it = nullCodes.iterator(); it.hasNext();){
			// String code = (String)it.next();
			// textArea.append(code + "\n");
			// }

			// textArea.append("Content preparation...OK\n");

			// export properties
			//wikiBot.writeMultContent(allProperties.iterator());

			// export all to wiki
			wikiBot.writeMultContent(allContents.iterator());
			/*
			 * Map highLevelCodes = templateModel.getSuperClasses();
			 * for(Iterator it = highLevelCodes.keySet().iterator();
			 * it.hasNext();){ String code = (String) it.next();
			 * 
			 * Collection superCodes = (Collection)highLevelCodes.get(code);
			 * for(Iterator it1 = superCodes.iterator(); it1.hasNext();){ String
			 * superCode = (String)it1.next(); textArea.append(code + "|" +
			 * superCode + "\n"); }
			 *  }
			 * 
			 * Collection introCodes = templateModel.getIntroducedIcd9Codes();
			 * Map allDescriptionsICD9CM =
			 * templateModel.getAllDescriptionsICD9CM();
			 * textArea.append("=================================\n");
			 * for(Iterator it1 = introCodes.iterator(); it1.hasNext();){ String
			 * introCode = (String) it1.next(); String introDescription =
			 * (String)allDescriptionsICD9CM.get(introCode);
			 * textArea.append(introCode + "|" + introDescription + "\n"); }
			 * 
			 * //textArea.append("Export to wiki...OK\n");
			 */
			textArea.append("Number of all contents: " + allContents.size()
					+ "\n");
			textArea.append("ending time:" + new Date() + "\n");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Login Error!", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	private void saveContentToFile() {
		try {
			BufferedWriter bw = new BufferedWriter(
					new FileWriter("content.txt"));
			bw.write(textArea.getText());
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private SimpleArticle getContentForEachClass(String code) {
		String ns = this.getNamespace();
		String localName = (String) jcbCodeSystems.getSelectedItem();
		String coded = this.getSelectedConcept(code);
		SimpleArticle sa = new SimpleArticle();
		sa.setLabel(coded);
		sa.setText(model.getContentForConceptCode(code, localName, ns));
		return sa;
	}

	private String getSelectedConceptTalk() {

		String selectedCode = (String) listConcepts.getSelectedValue();
		String[] pairs = selectedCode.split("\\|");
		String ns = this.getNamespace();
		String codedConcept = "";
		if(ns.equals("ICD")){
			codedConcept = "Category talk:"
				+ templateModel.mangle(ns + " " + pairs[2]);
		}else if(ns.equals("ICD10CM")){
			
			codedConcept = "Category:"
				+ ns + "_(" + pairs[0] + ")_" + templateModel.mangle(pairs[1]);			
		}else{
		    codedConcept = "Category:"
				+ templateModel.mangle(ns + "_" + pairs[1]) + "(" + pairs[0]
				+ ")";
		}

		return codedConcept;
	}	
	
	private String getSelectedConcept() {

		String selectedCode = (String) listConcepts.getSelectedValue();
		String[] pairs = selectedCode.split("\\|");
		String ns = this.getNamespace();
		String codedConcept = "";
		if(ns.equals("ICD")){
			codedConcept = "Category:"
				+ templateModel.mangle(ns + " " + pairs[2]);
		}else if(ns.equals("ICD10CM")){
			
			codedConcept = "Category:"
				+ ns + "_(" + pairs[0] + ")_" + templateModel.mangle(pairs[1]);			
		}else{
		    codedConcept = "Category:"
				+ templateModel.mangle(ns + "_" + pairs[1]) + "(" + pairs[0]
				+ ")";
		}

		return codedConcept;
	}

	private String getSelectedIndex() {

		String idxName = (String) listConcepts.getSelectedValue();
		String codedIndex = "Index:"
				+ templateModel.mangle(idxName);

		return codedIndex;
	}	
	
	private String getSelectedConcept(String code) {

		String[] pairs = code.split("\\|");
		String ns = this.getNamespace();
		String codedConcept = "Category: "
				+ templateModel.mangle(ns + "_" + pairs[1]) + "(" + pairs[0]
				+ ")";

		return codedConcept;
	}

}
