package edu.mayo.bmi.guoqian.lexwiki;

import java.util.ArrayList;
import java.util.Collection;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.util.CollectionUtilities;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.server_changes.ChangesProject;
import edu.stanford.smi.protegex.server_changes.model.ChangeModel.AnnotationCls;
import edu.stanford.smi.protegex.server_changes.model.generated.Annotation;
import edu.stanford.smi.protegex.server_changes.model.generated.Ontology_Component;
import edu.stanford.smi.protegex.server_changes.model.generated.Timestamp;

public class TestAnnotations {

	private OWLModel owlModel;
	private KnowledgeBase changes_kb;
	
	public static void main(String[] args) {
		ArrayList errors = new ArrayList();		
		
		/*
		 * Please update here the path to the collaborativePizza project from your Protege installation directory, examples/collaborativePizza
		 */
		Project prj = Project.loadProjectFromFile("C:\\Program Files\\Protege_3.3.1\\examples\\collaborativePizza\\collaborativePizza.owl.pprj", errors);
		
		if (errors.size() > 0) {
			System.out.println("There were erros at loading prj: " + prj);
			System.out.println(errors);
		}

		TestAnnotations _this = new TestAnnotations();
		if (prj != null) {
			_this.owlModel = (OWLModel) prj.getKnowledgeBase();
		}
		
		_this.initializeAnnotations();
		
		OWLNamedClass pizza = _this.owlModel.getOWLNamedClass("Pizza");
			
		_this.printAnnotations(pizza);
		_this.createAnnotation(pizza);
		_this.printAnnotations(pizza);
		_this.save();	
	}

	

	/**
	 * Just a temporary hack for a bug that will be fixed in the next beta.
	 * Then, you won't have to call this method anymore
	 */
	private void initializeAnnotations() {
		new ChangesProject().afterLoad(owlModel.getProject());
		changes_kb = ChangesProject.getChangesKB(owlModel);		
	}
	
	
	/**
	 * Prints the annotations associated to a resources.
	 * @param resource
	 */
	private void printAnnotations(RDFResource resource) {
		System.out.println("\nAnnotations on " + resource.getBrowserText());
		//Ontology_Component ontologyComponent = ChangeOntologyUtil.getOntologyComponent(resource, true);
		
		//Collection<Annotation> annotations = ontologyComponent.getAssociatedAnnotations();
		
		//if (annotations == null || annotations.size() == 0) {
		//	System.out.println("... none");
		//	return;
		//}
		
		//for (Annotation annotation : annotations) {			
		//	System.out.println("\tauthor: " + annotation.getAuthor());
		///	System.out.println("\tdate: " + ((Timestamp)annotation.getCreated()).getDate());
		//	System.out.println("\tbody: " + annotation.getBody());
		//}		
	}
		
	
	/**
	 * Creates an example annotation on resource
	 * @param resource
	 */
	private void createAnnotation(RDFResource resource) {	
		
		//Ontology_Component pizzaOntologyComponent = ChangeOntologyUtil.getOntologyComponent(resource, true);
		
		//Annotation comment = (Annotation) changes_kb.createInstance(null, ChangesProject.getChangesDb(owlModel).getModel().getCls(AnnotationCls.Comment));
		//ChangeOntologyUtil.fillAnnotationSystemFields(owlModel, comment);
		//comment.setBody("This is the comment text");
		
		//pizzaOntologyComponent.setAssociatedAnnotations(CollectionUtilities.createCollection(comment));
		
		//System.out.println("Created comment " + comment.getBrowserText() + " on " + resource.getBrowserText());
	}
	
	
	/**
	 * Saves the main project and the annotations project
	 */
	private void save() {
		System.out.println("\nSaving " + owlModel.getProject().getProjectURI());
		ArrayList errors = new ArrayList();
		owlModel.getProject().save(errors);
		
		System.out.println("\nSaving annotations in " + changes_kb.getProject().getProjectURI());
		changes_kb.getProject().save(errors);
		
		System.out.println(errors);
	}
	
}
