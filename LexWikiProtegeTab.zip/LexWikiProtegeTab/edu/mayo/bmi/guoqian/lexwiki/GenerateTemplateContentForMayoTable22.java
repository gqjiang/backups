package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;

public class GenerateTemplateContentForMayoTable22 {

	private Map superClasses = new HashMap();

	private Map highLevelClasses = new HashMap();

	public GenerateTemplateContentForMayoTable22() {

	}

	public Map getSuperClasses() {
		//return superClasses;
		
		return highLevelClasses;
	}



	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				vecCodeSystems.add(localName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}

	// for mayo table 22 only
	public Map getAllDescriptionForCodes(String localName) {

		Map ret = new HashMap();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.put(code, description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {
		Map allSuperClasses = this.getMapForSuperClass(localName, ns);
		Map allDescriptions = this.getAllDescriptionForCodes(localName);

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {

					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");
					if (ns.equals("MT")) {
						sb.append(this
								.getCodedEntryAssociationsForTable22(ref,
										localName, ns, allSuperClasses,
										allDescriptions));
					} else {
						sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					}

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm());

					sb
							.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public String getContentForDebug(String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				sb.append(this.getCodedEntryAssociations(ref, localName, ns));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();

	}

	// for mayo table 22 only
	public Map getMapForAllIcd9Codes(String localName, String ns) {

		Map allICD9Codes = new HashMap();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String icd9Code = this
						.getEquivalentICD9Code(ref, localName, ns);
				allICD9Codes.put(code, icd9Code);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return allICD9Codes;
	}

	// for mayo table 22 only
	public Map getMapForSuperClass(String localName, String ns) {

		Map allSuperClasses = new HashMap();
		Map allICD9Codes = this.getMapForAllIcd9Codes(localName, ns);
		Map allICD9Codes2 = this.getMapForAllIcd9Codes(localName, ns);
		int index = 0;

		// loop1
		for (Iterator it1 = allICD9Codes.keySet().iterator(); it1.hasNext();) {
			String code = (String) it1.next();
			System.out.println("loop1:" + index++);
			String icd9Code = (String) allICD9Codes.get(code);
			String nodotIcd9Code = null;
			if (icd9Code != null && icd9Code.indexOf(".") >= 0) {
				nodotIcd9Code = icd9Code.replaceAll("\\.", "");
			} else {
				nodotIcd9Code = icd9Code;
			}
			// System.out.println("icd9Code:" + nodotIcd9Code);
			if (nodotIcd9Code != null) {
				int len = nodotIcd9Code.length();
				Collection manySuperClses = new ArrayList();
				for (Iterator it2 = allICD9Codes2.keySet().iterator(); it2
						.hasNext();) {
					String code2 = (String) it2.next();
					String icd9Code2 = (String) allICD9Codes2.get(code2);
					String nodotIcd9Code2 = null;

					if (icd9Code2 != null && icd9Code2.indexOf(".") >= 0) {
						nodotIcd9Code2 = icd9Code2.replaceAll("\\.", "");
					} else {
						nodotIcd9Code2 = icd9Code2;
					}
					// System.out.println("icd9Code2:" + nodotIcd9Code2);
					if (nodotIcd9Code2 != null) {
						int len2 = nodotIcd9Code2.length();
						int lenDiff = len - len2;

						// determine the super class
						if (icd9Code2 != null && icd9Code2.indexOf(".") < 0) {
							icd9Code2 = icd9Code2 + ".";
						}

						if (lenDiff == 1 && icd9Code.startsWith(icd9Code2)) {

							manySuperClses.add(code2);
							// break;
						}
					}
				}
				if (manySuperClses.size() > 0) {
					allSuperClasses.put(code, manySuperClses);
				}
			}
		}
		index = 0;

		// loop2
		for (Iterator it1 = allICD9Codes.keySet().iterator(); it1.hasNext();) {
			String code = (String) it1.next();

			if (!allSuperClasses.containsKey(code)) {
				System.out.println("loop2:" + index++);
				String icd9Code = (String) allICD9Codes.get(code);
				String nodotIcd9Code = null;
				if (icd9Code != null && icd9Code.indexOf(".") >= 0) {
					nodotIcd9Code = icd9Code.replaceAll("\\.", "");
				} else {
					nodotIcd9Code = icd9Code;
				}
				// System.out.println("icd9Code:" + nodotIcd9Code);
				if (nodotIcd9Code != null) {
					int len = nodotIcd9Code.length();
					Collection manySuperClses = new ArrayList();
					for (Iterator it2 = allICD9Codes2.keySet().iterator(); it2
							.hasNext();) {
						String code2 = (String) it2.next();
						String icd9Code2 = (String) allICD9Codes2.get(code2);
						String nodotIcd9Code2 = null;

						if (icd9Code2 != null && icd9Code2.indexOf(".") >= 0) {
							nodotIcd9Code2 = icd9Code2.replaceAll("\\.", "");
						} else {
							nodotIcd9Code2 = icd9Code2;
						}
						// System.out.println("icd9Code2:" + nodotIcd9Code2);
						if (nodotIcd9Code2 != null) {
							int len2 = nodotIcd9Code2.length();
							int lenDiff = len - len2;

							// determine the super class
							if (icd9Code2 != null && icd9Code2.indexOf(".") < 0) {
								icd9Code2 = icd9Code2 + ".";
							}

							if (!icd9Code.equals(icd9Code2)
									&& icd9Code.startsWith(icd9Code2)) {

								manySuperClses.add(code2);
								// break;
							}
						}
					}
					if (manySuperClses.size() > 0) {
						allSuperClasses.put(code, manySuperClses);
					}
				}

			}
		}

		index = 0;

		// loop3
		for (Iterator it1 = allICD9Codes.keySet().iterator(); it1.hasNext();) {
			String code = (String) it1.next();

			if (!allSuperClasses.containsKey(code)) {
				System.out.println("loop3:" + index++);
				String icd9Code = (String) allICD9Codes.get(code);

				if (icd9Code != null) {
					if (icd9Code.startsWith("V")) {
						highLevelClasses.put(code, "V01-V86.1");
					} else {
						
						if(icd9Code.startsWith("0") ||
								icd9Code.startsWith("1") ||
								icd9Code.startsWith("2") ||					
								icd9Code.startsWith("3") ||
								icd9Code.startsWith("4") ||
								icd9Code.startsWith("5") ||					
								icd9Code.startsWith("6") ||
								icd9Code.startsWith("7") ||
								icd9Code.startsWith("8") ||					
								icd9Code.startsWith("9")){
						String nodotIcd9Code = icd9Code;
						if (icd9Code.indexOf(".") >= 0) {
							nodotIcd9Code = icd9Code.substring(0, icd9Code
									.indexOf("."));
						}
                        
						int intCode = Integer.parseInt(nodotIcd9Code);
						System.out.println(nodotIcd9Code + "|" + intCode);
						if (intCode >= 1 && intCode <= 139) {
							highLevelClasses.put(code, "001-139.8");
						} else if (intCode >= 140 && intCode <= 239) {
							highLevelClasses.put(code, "140-239.9");
						} else if (intCode >= 240 && intCode <= 279) {
							highLevelClasses.put(code, "240-279.9");
						} else if (intCode >= 280 && intCode <= 289) {
							highLevelClasses.put(code, "280-289.9");
						} else if (intCode >= 290 && intCode <= 319) {
							highLevelClasses.put(code, "290-319");
						} else if (intCode >= 320 && intCode <= 389) {
							highLevelClasses.put(code, "320-389.9");
						} else if (intCode >= 390 && intCode <= 459) {
							highLevelClasses.put(code, "390-459.9");
						} else if (intCode >= 460 && intCode <= 519) {
							highLevelClasses.put(code, "460-519.9");
						} else if (intCode >= 520 && intCode <= 579) {
							highLevelClasses.put(code, "520-579.9");
						} else if (intCode >= 580 && intCode <= 629) {
							highLevelClasses.put(code, "580-629.9");
						} else if (intCode >= 630 && intCode <= 677) {
							highLevelClasses.put(code, "630-677");
						} else if (intCode >= 680 && intCode <= 709) {
							highLevelClasses.put(code, "680-709.9");
						} else if (intCode >= 710 && intCode <= 739) {
							highLevelClasses.put(code, "710-739.9");
						} else if (intCode >= 740 && intCode <= 759) {
							highLevelClasses.put(code, "740-759.9");
						} else if (intCode >= 760 && intCode <= 779) {
							highLevelClasses.put(code, "760-779.9");
						} else if (intCode >= 780 && intCode <= 799) {
							highLevelClasses.put(code, "780-799.9");
						} else if (intCode >= 800 && intCode <= 999) {
							highLevelClasses.put(code, "800-999.9");
						}
					}
					}

				}

			}
		}

		superClasses = allSuperClasses;

		return allSuperClasses;
	}
	
	private Map getHighLevelCodeMap() {
		Map highLevelMap = new HashMap();
		highLevelMap.put("001-139.8", "Infectious and Parasitic Diseases");
		highLevelMap.put("140-239.9", "Neoplasms");
		highLevelMap.put("240-279.9",
				"Endocrine, Nutritional and Metabolic, Immunity");
		highLevelMap.put("280-289.9", "Blood and Blood Forming Organs");
		highLevelMap.put("290-319", "Mental Disorders");
		highLevelMap.put("320-389.9", "Nervous Systems and Sense Organs");
		highLevelMap.put("390-459.9", "Circulatory System");
		highLevelMap.put("460-519.9", "Respiratory System");
		highLevelMap.put("520-579.9", "Digestive System");
		highLevelMap.put("580-629.9", "Genitourinary System");
		highLevelMap.put("630-677",
				"Complications of Pregnancy, Childbirth & Puerperium");
		highLevelMap.put("680-709.9", "Skin and Subcurtaneous Tissue");
		highLevelMap.put("710-739.9", "Musculoskeletal and Connective Tissue");
		highLevelMap.put("740-759.9", "Congenital Anomalies");
		highLevelMap.put("760-779.9", "Conditions in the Perinatal Period");
		highLevelMap.put("780-799.9",
				"Symptoms, Signs, and Ill-Defined Conditions");
		highLevelMap.put("800-999.9", "Injury and Poisoning");
		highLevelMap.put("V01-V86.1", "V Codes");

		return highLevelMap;
	}	

	private boolean isFirstLoop(Map map, String code) {
		boolean ret = false;
		for (Iterator it = map.keySet().iterator(); it.hasNext();) {
			String key = (String) it.next();
			if (key.equals(code)) {
				ret = true;
				break;
			}
		}

		return ret;
	}

	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {

		Map allSuperClasses = this.getMapForSuperClass(localName, ns);
		Map allDescriptions = this.getAllDescriptionForCodes(localName);

		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				if (!allSuperClasses.containsKey(code)) {
					SimpleArticle sa = new SimpleArticle();
					sa.setLabel("Category:" + ns + " " + description + "("
							+ code + ")");
					System.out.println("Category:" + ns + " " + description
							+ "(" + code + ")");
					StringBuffer sb = new StringBuffer();

					// if (ns.equals("NCI") && code.startsWith("R")){
					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					if (ns.equals("MT")) {
						sb.append(this
								.getCodedEntryAssociationsForTable22(ref,
										localName, ns, allSuperClasses,
										allDescriptions));
					} else {
						sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					}
					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm());

					sb
							.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

					sa.setText(sb.toString());
					allContents.add(sa);
				}

				// special for NCI attributes and relations
				if (ns.equals("NCI")) {
					if (// code.startsWith("A") ||
					// code.startsWith("K") ||
					code.startsWith("P")) {
						SimpleArticle saAttr = new SimpleArticle();
						saAttr.setLabel("Attribute:" + ns + "_" + description);
						StringBuffer sbAttr = new StringBuffer();
						sbAttr.append("#REDIRECT [[:Category:" + ns + "_"
								+ description + "]]\n");
						sbAttr.append("[[has type::Type:String]]");
						saAttr.setText(sbAttr.toString());
						allContents.add(saAttr);
					}

					if (code.startsWith("R")) {
						SimpleArticle saRel = new SimpleArticle();
						saRel.setLabel("Relation:" + ns + "_" + description);
						StringBuffer sbRel = new StringBuffer();
						sbRel.append("#REDIRECT [[:Category:" + ns + "_"
								+ description + "]]\n");
						saRel.setText(sbRel.toString());
						allContents.add(saRel);

					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			sb.append("{{LexWiki Coding Scheme|Coding Scheme=" + codingScheme
					+ "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getDefaultForm() {
		return "<noinclude>[[has default form::Form:LexWiki Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "{{LexWiki Basic Data Header}}\n";
	}

	private String getHeaderProperties() {
		return "{{LexWiki Concept Property Header}}\n";
	}

	private String getHeaderAssoications() {
		return "{{LexWiki Association Header}}\n";
	}

	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}

	private String getCodedEntryCode(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append("{{LexWiki Concept Code|Concept Code=" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryDescription(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		sb.append("{{LexWiki Entity Description|Entity Description="
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			sb.append("{{LexWiki Definition|Definition="
					+ entry.getDefinition(ii).getText().getContent() + "}}\n");
		}

		return sb.toString();

	}

	private String getCodedEntryPresentations(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String text = pres.getText().getContent();
			text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			if (isPref) {
				// String attrName = "Has Preferred " + propName;
				sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
						+ "}}\n");
			} else {
				// String fidelity = pres.getDegreeOfFidelity();
				// String attrName = "Has " + fidelity + " "
				// + propName;
				sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
						+ text + "}}\n");
			}
		}

		return sb.toString();

	}

	private String getCodedEntryConceptProperty(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			String cpText = cp.getText().getContent();
			sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
					+ "}}\n");
		}

		return sb.toString();
	}

	private String getCodedEntryComment(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|Comment="
					+ entry.getComment(j).getText().getContent() + "}}\n");
		}

		return sb.toString();
	}

	// for mayo table 22 only
	private String getEquivalentICD9Code(ResolvedConceptReference ref,
			String localName, String ns) {
		String ret = null;

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						// System.out.println(assName);
						// System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						// if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							if (assName.equals("equivalentClass")) {
								ret = assConcept.getConceptCode().trim();
								break;
							}

						}

					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	// for mayo table 22 only
	private String getCodedEntryAssociationsForTable22(
			ResolvedConceptReference ref, String localName, String ns,
			Map allSuperClasses, Map allDescriptions) {
		StringBuffer sb = new StringBuffer();
		// Map allSuperClasses = this.getMapForSuperClass(localName, ns);
		// Map allDescriptions = this.getAllDescriptionForCodes(localName);
        Map highLevelCodeMap = this.getHighLevelCodeMap();
		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);
			String code = ref.getConceptCode();
			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						// System.out.println(assName);
						// System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						// if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assName
									+ "|"
									+ "ICD9CM"
									+ " "
									+ assConcept.getEntityDescription()
											.getContent() + "("
									+ assConcept.getConceptCode() + ")}}\n");

						}

					}
				}
			}

			if (allSuperClasses.containsKey(code)) {
				Collection superCodes = (Collection) allSuperClasses.get(code);
				for (Iterator it = superCodes.iterator(); it.hasNext();) {
					String superCode = (String) it.next();
					String superDescription = (String) allDescriptions
							.get(superCode);
					sb.append("<noinclude>[[Category:" + ns + " "
							+ superDescription + "(" + superCode + ")"
							+ "]]</noinclude>\n");
				}

			} else if (highLevelClasses.containsKey(code)){
                String superCode = (String)highLevelClasses.get(code);
                String superDescription = (String)highLevelCodeMap.get(superCode);
				sb.append("<noinclude>[[Category:" + ns + " "
						+ superDescription + "(" + superCode + ")"
						+ "]]</noinclude>\n");
			}else{
				sb.append("<noinclude>[[Category:" + localName
						+ "]]</noinclude>\n");
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}



	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		// StringBuffer sb_debug = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println(assName);
						System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						// if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							/*
							 * sb .append("{{LexWiki Association|" + ns + "_" +
							 * assName + "|" + "ICD9CM" + " " + assConcept
							 * .getEntityDescription() .getContent() + "(" +
							 * assConcept.getConceptCode() + ")}}\n");
							 */
							if (assName.equals("CHD")) {
								isaIndex++;
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
							}
						}

					}
				}
				// }
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					// if(altes != null){
					for (int jt = 0; jt < altes.length; jt++) {
						// while(aListTarget != null &&
						// aListTarget.enumerateAssociation().hasMoreElements()){
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof:" + assName);
						System.out.println("targetof:"
								+ ass.getDirectionalName());
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}
						System.out.println("targetof:" + assName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assDisplayName
									+ "|"
									+ "ICD9CM"
									+ " "
									+ assConcept.getEntityDescription()
											.getContent() + "("
									+ assConcept.getConceptCode() + ")}}\n");

							if (assDisplayName.equals("PAR")) {
								isaIndex++;
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
							}
						}
					}
				}
			}

			String code = ref.getConceptCode();

			// different groups of NCI concepts
			if (ns.equals("NCI")) {
				if (code.startsWith("K")) {
					sb.append("<noinclude>[[Category:" + "NCI Kind"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("A")) {
					sb.append("<noinclude>[[Category:" + "NCI MetaA"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("P")) {
					sb.append("<noinclude>[[Category:" + "NCI Property"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("R")) {
					sb.append("<noinclude>[[Category:" + "NCI Relation"
							+ "]]</noinclude>\n");

				} else if (isaIndex == 0) {
					sb.append("<noinclude>[[Category:" + localName
							+ "]]</noinclude>\n");
				}
			} else {
				if (isaIndex == 0) {
					sb.append("<noinclude>[[Category:" + localName
							+ "]]</noinclude>\n");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + "_" + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						// if (!assName.equals("hasSubtype")) {

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = "ICD9CM"
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");

							sb.append("[ " + thisConcept + "] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + ass.getDirectionalName()
									+ " --> {link:Relation:" + ns + "_"
									+ assName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 3; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");

						}

					}
				}
				// }
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = "ICD9CM"
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");

							sb.append("[ " + thisConcept + "] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assDisplayName
									+ " --> {link:Relation:" + ns + "_"
									+ assDisplayName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");

						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + " " + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}

}
