package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import edu.stanford.smi.protege.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;

//first implementation of new lexwiki templates
public class GenerateTemplateContentForLexWikiICD10 {

	private Map superClasses = new HashMap();
	
	private Collection icdcuis = new ArrayList();

	private Collection propertyNames = new ArrayList();

	private KnowledgeBase kb = null;

	private Map propertyNameValues;

	private Collection nullConceptCodes = new ArrayList();

	public GenerateTemplateContentForLexWikiICD10() {

	}

	public Map getSuperClasses() {
		return superClasses;
	}

	public Collection getNullConceptCodes() {
		return nullConceptCodes;
	}
	
	public String getDefinitionMapping(){
		StringBuffer sb = new StringBuffer();
		BufferedReader br1, br2, br3;
		BufferedWriter bw1, bw2;
		Map mapCodeCui = new HashMap();
		try{
			br1 = new BufferedReader(new FileReader("icdcuilist.txt"));
			String line1 = br1.readLine();
			while(line1 != null){
				String[] pairs = line1.split("\\|");
				mapCodeCui.put(pairs[0], pairs[1]);
				line1 = br1.readLine();
			}
			
			//bw1 = new BufferedWriter(new FileWriter("defsubset.rrf"));
			
			//br2 = new BufferedReader(new FileReader("mrdef.rrf"));
			//String line2 = br2.readLine();
			//while(line2 != null){
			//	String[] pairs = line2.split("\\|");
			//	
			//	if(mapCodeCui.containsValue(pairs[0])){
			//		//bw1.write(line2 + "\n");
			//	}
			//	
			//	line2 = br2.readLine();
			//	
			//}
			
			br1.close();
			//br2.close();
			//bw1.close();
			
			bw2 = new BufferedWriter(new FileWriter("deffinal.txt"));
			br3 = new BufferedReader(new FileReader("defsubset.rrf"));
			String line3 = br3.readLine();
			Collection sourceDefs = new ArrayList();
			while(line3 != null){
				String[] pairs = line3.split("\\|");
				
				for(Iterator it = mapCodeCui.keySet().iterator(); it.hasNext();){
					String code = (String) it.next();
					String cui = (String) mapCodeCui.get(code);
					if(cui.equals(pairs[0])){
						if(!sourceDefs.contains(code + "|" + pairs[4] + "|" +pairs[5])){
						    sourceDefs.add(code + "|" + pairs[4] + "|" +pairs[5]);
							bw2.write(code + "|" + cui 
								+ "|" + pairs[4]
								+ "|" + pairs[5] + "\n");
						
						}
					}
				}
				
				line3 = br3.readLine();
				
			}
			bw2.close();
			br3.close();
			sb.append("success");
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		
		return sb.toString();
		
	}
	
	public String getICDCodeCUIPaires(){
		StringBuffer sb = new StringBuffer();
		BufferedWriter bw;
		try{
			bw = new BufferedWriter(new FileWriter("icdcuilist.txt"));
		for(Iterator it = icdcuis.iterator(); it.hasNext();){
			String codecui = (String) it.next();
			sb.append(codecui + "\n");
			System.out.println(codecui);
			bw.write(codecui + "\n");
			
		}
		bw.close();
		
		}catch(IOException io){
			io.printStackTrace();
		}
		
		return sb.toString();
		
	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				vecCodeSystems.add(localName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}

	// this should be called before any loading
	public Collection getPropertyNames() {
		Collection ret = new ArrayList();
		for (Iterator it = propertyNames.iterator(); it.hasNext();) {
			String propertyName = (String) it.next();
			String label = "Attribute:" + propertyName;
			String text = "[[has type::Type:String]]";
			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(label);
			sa.setText(text);
			ret.add(sa);
		}

		return ret;
	}

	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
					
					if(ns.equals("ICD10AM")){
						sb.append(this.getAccessControlToICD10AM(conceptCode));
					}

					sb.append(this.getHeaderBasicData());
					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName, ns));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getCodedEntryURI(entry, localName, ns));

					sb.append(this.getTrailerBasicData());

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					// sb.append(this.getCodedEntryComment(entry));

					if (ns.equals("ICD10")) {
						sb.append(this.getDPLQuery1ForICD10(entry));
					}

					sb.append(this.getTrailerProperties());

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this
							.getCodedEntryAssociations(ref, localName, ns));

					if (ns.equals("ICD10")) {
						sb.append(this.getDPLQuery2ForICD10(entry));
					}

					sb.append(this.getTrailerAssoications());

					//sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					//sb.append(this.getCodedEntryAssociationsGraph(ref,
					//		localName, ns));

					//sb.append(this.getTrailerAssociationsGraph());

					if (ns.equals("ICD10")) {
						if (!isLeafNode(ref, localName, ns)) {
							sb.append(this.getHeaderReferences());
							sb.append(this.getLexWikiCategoryTree(entry));
							sb.append(this.getTrailerReferences());

						}
					}

					sb.append(this.getDefaultForm(ns));

					sb
							.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public Map getContentMapForConceptCode(String conceptCode,
			String localName, String ns) {
		propertyNameValues = new HashMap();
		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {

					this.getCodedEntryCodeCollection(entry);

					// sb.append("== Entity Description ==\n");
					this.getCodedEntryDescriptionCollection(entry);

					// sb.append("== Coding Scheme ==\n");
					this.getCodingSchemeCollection(localName, ns);

					// sb.append("== Definition ==\n");
					this.getCodedEntryDefinitionCollection(entry);

					// sb.append("== Presentations ==\n");
					this.getCodedEntryPresentationsCollection(entry, ns);

					this.getCodedEntryURICollection(entry, localName, ns);

					// sb.append("== Concept Property ==\n");
					this.getCodedEntryConceptPropertyCollection(entry, ns);

					// sb.append("== Comment ==\n");
					// sb.append(this.getCodedEntryComment(entry));
					// sb.append("== Associations ==\n");

					this.getCodedEntryAssociationsCollection(ref, localName, ns);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return propertyNameValues;
	}

	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {

		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				String conceptLabel = "Category:" + ns + "_"
				                      + "(" + code 	+ ")_"
						+ this.mangle(description);

				System.out.println(conceptLabel);
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel(conceptLabel);

				StringBuffer sb = new StringBuffer();

				if(ns.equals("ICD10AM")){
					sb.append(this.getAccessControlToICD10AM(entry));
				}
				
				
				// if (ns.equals("NCI") && code.startsWith("R")){
				sb.append(this.getHeaderBasicData());
				// sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(entry));

				// sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(entry));

				// sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName, ns));

				// sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(entry));

				// sb.append("== Presentations ==\n");
				sb.append(this.getCodedEntryPresentations(entry, ns));

				sb.append(this.getCodedEntryURI(entry, localName, ns));

				sb.append(this.getTrailerBasicData());

				sb.append(this.getHeaderProperties());

				// sb.append("== Concept Property ==\n");
				sb.append(this.getCodedEntryConceptProperty(entry, ns));

				// sb.append("== Comment ==\n");
				// sb.append(this.getCodedEntryComment(entry));

				if (ns.equals("ICD10")) {
					sb.append(this.getDPLQuery1ForICD10(entry));

				}

				sb.append(this.getTrailerProperties());

				sb.append(this.getHeaderAssoications());

				// sb.append("== Associations ==\n");

				sb.append(this.getCodedEntryAssociations(ref, localName, ns));

				if (ns.equals("ICD10")) {
					sb.append(this.getDPLQuery2ForICD10(entry));
				}

				sb.append(this.getTrailerAssoications());

				//sb.append(this.getHeaderAssociationsGraph());

				// sb.append("== Associations Graph ==\n");
				//sb.append(this.getCodedEntryAssociationsGraph(ref, localName,
				//		ns));

				//sb.append(this.getTrailerAssociationsGraph());

				if (ns.equals("ICD10")) {
					if (!isLeafNode(ref, localName, ns)) {
						sb.append(this.getHeaderReferences());
						sb.append(this.getLexWikiCategoryTree(entry));
						sb.append(this.getTrailerReferences());

					}
				}

				sb.append(this.getDefaultForm(ns));

				sb.append(this.getCodedEntryIncludeOnly(ref, localName, ns));

				sa.setText(sb.toString());
				allContents.add(sa);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			if (ns.equals("ICD10")) {
				codingScheme = codingScheme + " SECOND EDITION";
			} else if (ns.equals("ICD10AM")) {
				codingScheme = codingScheme + " FIFTH EDITION";
			} else if (ns.equals("ICD10CM")) {
				codingScheme = codingScheme + " JULY2007 RELEASE";
			}

			sb.append("{{LexWiki inScheme|" + codingScheme + "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private void getCodingSchemeCollection(String localName, String ns) {
		Collection codingSchemes = new ArrayList();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			if (ns.equals("ICD10")) {
				codingScheme = codingScheme + " SECOND EDITION";
			} else if (ns.equals("ICD10AM")) {
				codingScheme = codingScheme + " FIFTH EDITION";
			} else if (ns.equals("ICD10CM")) {
				codingScheme = codingScheme + " JULY2007 RELEASE";
			}

			codingSchemes.add(codingScheme);
			
			propertyNameValues.put("Attribute:LexWiki_inScheme", codingSchemes);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}	
	
	private String getCodingSchemeName(String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			if (ns.equals("ICD10")) {
				codingScheme = codingScheme + " SECOND EDITION";
			} else if (ns.equals("ICD10AM")) {
				codingScheme = codingScheme + " FIFTH EDITION";
			} else if (ns.equals("ICD10CM")) {
				codingScheme = codingScheme + " JULY2007 RELEASE";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codingScheme;
	}

	private String getDefaultForm(String ns) {
		return "<noinclude>[[has default form::Form:LexWiki ICD10 Form]]</noinclude>\n";
	}
	
	private String getAccessControlToICD10AM(String code){
		if(code.indexOf(".") < 0){
			return "<accesscontrol>Sysops,,ICD10AMAccess,,</accesscontrol>\n";
		}else{
			return "";
		}
	}

	private String getAccessControlToICD10AM(CodedEntry entry){
		String code = entry.getConceptCode();
		if(code.indexOf(".") < 0){
			return "<accesscontrol>Sysops,,ICD10AMAccess,,</accesscontrol>\n";
		}else{
			return "";
		}
	}	
	
	private String getHeaderBasicData() {
		return "<noinclude>{{LexWiki Basic Data Header}}</noinclude>\n";
	}

	private String getTrailerBasicData() {
		return "<noinclude>{{LexWiki Basic Data Trailer}}</noinclude>\n";
	}

	private String getHeaderProperties() {
		return "<noinclude>{{LexWiki Concept Property Header}}</noinclude>\n";
	}

	private String getTrailerProperties() {
		return "<noinclude>{{LexWiki Concept Property Trailer}}</noinclude>\n";
	}

	private String getHeaderAssoications() {
		return "<noinclude>{{LexWiki Association Header}}</noinclude>\n";
	}

	private String getTrailerAssoications() {
		return "<noinclude>{{LexWiki Association Trailer}}</noinclude>\n";
	}

	private String getHeaderReferences() {
		return "<noinclude>{{LexWiki Reference Header}}</noinclude>\n";
	}

	private String getTrailerReferences() {
		return "<noinclude>{{LexWiki Reference Trailer}}</noinclude>\n";
	}

	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}

	private String getTrailerAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Trailer}}</noinclude>\n";
	}

	private String getDPLQuery1ForICD10(CodedEntry entry) {
		String code = entry.getConceptCode();
		return "<noinclude>{{LexWiki DPL Query1|ICD10xx Properties|ICD10CM %("
				+ code + "){{!}}ICD10AM %(" + code + ")" + "}}</noinclude>\n";
	}

	private String getDPLQuery2ForICD10(CodedEntry entry) {
		String code = entry.getConceptCode();
		return "<noinclude>{{LexWiki DPL Query2|ICD10xx Associations|ICD10CM %("
				+ code + "){{!}}ICD10AM %(" + code + ")" + "}}</noinclude>\n";
	}

	private String getLexWikiCategoryTree(CodedEntry entry) {
		String code = entry.getConceptCode();
		return "<noinclude>{{LexWiki CategoryTree|{{LexWiki DPL Query3|ICD10CM %("
				+ code
				+ ")}}|{{LexWiki DPL Query3|ICD10AM %("
				+ code
				+ ")}}}}</noinclude>";
	}

	private String getCodedEntryCode(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		return sb.toString();
	}

	private void getCodedEntryCodeCollection(CodedEntry entry) {

		Collection codes = new ArrayList();
		String code = entry.getConceptCode();
		codes.add(code);
		propertyNameValues.put("Attribute:LexWiki_Concept_Code", codes);
		
	}

	private String getCodedEntryDescription(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		description = this.mangle(description);
		sb.append("{{LexWiki Preferred Name|" + description + "}}\n");
		return sb.toString();

	}

	private void getCodedEntryDescriptionCollection(CodedEntry entry) {
		Collection descriptions = new ArrayList();
		String description = entry.getEntityDescription().getContent();
		description = this.mangle(description);
		descriptions.add(description);
		propertyNameValues
				.put("Attribute:LexWiki_Preferred_Name", descriptions);

	}

	private String getCodedEntryURI(CodedEntry entry, String localName,
			String ns) {
		StringBuffer sb = new StringBuffer();
		String scheme = this.getCodingSchemeName(localName, ns);
		String code = entry.getConceptCode();
		sb.append("{{LexWiki URI|" + scheme + ":" + code + "}}\n");
		return sb.toString();

	}

	private void getCodedEntryURICollection(CodedEntry entry, String localName,
			String ns) {
		Collection uris = new ArrayList();
		String scheme = this.getCodingSchemeName(localName, ns);
		String code = entry.getConceptCode();
		uris.add(scheme + ":" + code);
		propertyNameValues.put("Attribute:LexWiki_URI", uris);

	}

	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			if (ii == 0) {
				sb.append("{{LexWiki Definition|"
						+ entry.getDefinition(ii).getText().getContent()
						+ "}}\n");
			} else {
				sb.append("{{LexWiki AltDefinition|"
						+ entry.getDefinition(ii).getText().getContent()
						+ "}}\n");

			}
		}

		return sb.toString();

	}

	private void getCodedEntryDefinitionCollection(CodedEntry entry) {
		Collection defs = new ArrayList();
		Collection altdefs = new ArrayList();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			if (ii == 0) {
				defs.add(entry.getDefinition(ii).getText().getContent());
			} else {
				altdefs.add(entry.getDefinition(ii).getText().getContent());

			}
		}
		if (defs.size() >= 0)
			propertyNameValues.put("Attribute:LexWiki_Definition", defs);

		if (altdefs.size() >= 0)
			propertyNameValues.put("Attribute:LexWiki_AltDefinition", altdefs);
	}

	private String getCodedEntryPresentations(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String nsPropName = ns + "_" + propName;
			if (!propertyNames.contains(nsPropName))
				propertyNames.add(nsPropName);
			String text = pres.getText().getContent();
			text = this.mangle(text);
			boolean isPref = pres.getIsPreferred();

			// if (isPref) {
			// String attrName = "Has Preferred " + propName;
			// sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
			// + "}}\n");
			// } else {
			// String fidelity = pres.getDegreeOfFidelity();
			// String attrName = "Has " + fidelity + " "
			// + propName;
			sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
					+ text + "}}\n");
			// }
		}

		return sb.toString();

	}

	private void getCodedEntryPresentationsCollection(CodedEntry entry,
			String ns) {
		StringBuffer sb = new StringBuffer();

		Collection propNames = this.getPropNames(entry, ns);
		for (Iterator it = propNames.iterator(); it.hasNext();) {
			String pName = (String) it.next();
			Collection pValues = new ArrayList();
			int pIndex = entry.getPresentationCount();
			for (int ip = 0; ip < pIndex; ip++) {
				Presentation pres = entry.getPresentation(ip);
				String propName = pres.getProperty();
				String nsPropName = ns + "_" + propName;
				if (nsPropName.equals(pName)) {
					String text = pres.getText().getContent();
					text = this.mangle(text);
					pValues.add(text);
				}

			}
			propertyNameValues.put("Attribute:" + pName, pValues);
		}

	}

	private Collection getPropNames(CodedEntry entry, String ns) {
		Collection props = new ArrayList();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String nsPropName = ns + "_" + propName;
			if (!props.contains(nsPropName))
				props.add(nsPropName);
		}

		return props;
	}

	private String getCodedEntryConceptProperty(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			cpName = cpName.replaceAll("Includes", "Inclusion");
			cpName = cpName.replaceAll("Excludes", "Exclusion");
			cpName = cpName.replaceAll("Inclusion/Synonym Terms", "Inclusion");
            cpName = cpName.replaceAll(" ", "_");
			if (!propertyNames.contains(cpName))
				propertyNames.add(cpName);

			String cpText = cp.getText().getContent();
			if (cpName.equals(ns + "_" + "UMLS_CUI")){
				String codecui = entry.getConceptCode() + "|" + cpText;
				if(!icdcuis.contains(codecui)){
					icdcuis.add(codecui);
				}
			}			
			
			cpText = this.mangleProperty(cpText);
			sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
					+ "}}\n");
		}

		return sb.toString();
	}

	private void getCodedEntryConceptPropertyCollection(CodedEntry entry,
			String ns) {
		StringBuffer sb = new StringBuffer();
		Collection propNames = this.getConceptProperyNames(entry, ns);
		for (Iterator it = propNames.iterator(); it.hasNext();) {
			String propName = (String) it.next();
			Collection pValues = new ArrayList();
			int cpIndex = entry.getConceptPropertyCount();
			for (int cpi = 0; cpi < cpIndex; cpi++) {
				ConceptProperty cp = entry.getConceptProperty(cpi);
				String cpName = ns + "_" + cp.getProperty();

				if (cpName.equals(propName)) {
					String cpText = cp.getText().getContent();
					cpText = this.mangleProperty(cpText);
					pValues.add(cpText);
				}
			}
			propertyNameValues.put("Property:" + propName, pValues);
		}
	}

	private Collection getConceptProperyNames(CodedEntry entry, String ns) {
		Collection propNames = new ArrayList();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			cpName = cpName.replaceAll("Includes", "Inclusion");
			cpName = cpName.replaceAll("Excludes", "Exclusion");
			cpName = cpName.replaceAll("Inclusion/Synonym Terms", "Inclusion");
			if (!propNames.contains(cpName))
				propNames.add(cpName);
		}

		return propNames;
	}

	private String getCodedEntryComment(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|"
					+ entry.getComment(j).getText().getContent() + "}}\n");
		}

		return sb.toString();
	}

	private boolean isLeafNode(ResolvedConceptReference ref, String localName,
			String ns) {
		boolean ret = false;

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("isleafnode:" + assName);
						if (assName.equals("CHD")) {
							ret = true;
						}
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	private void getCodedEntryAssociationsCollection(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();
			
			Collection associationNames = this.getAssociationNames(ref, localName, ns);
			for(Iterator it = associationNames.iterator(); it.hasNext();){
				String associationName = (String) it.next();
				Collection associationValues = new ArrayList();
		

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();
								
								if(associationName.equals(ns + "_" + assDirectionalName)){
									associationValues.add(ns
												+ " "
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent()) + "("
												+ assConcept.getConceptCode()
												+ ")");
								}



							}
						}

					}
				}
			}
			
			propertyNameValues.put("Relation:" + associationName, associationValues);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}


	}	

	private Collection getAssociationNames(ResolvedConceptReference ref,
			String localName, String ns) {
		Collection associationNames = new ArrayList();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();
                                
								if(!associationNames.contains(ns + "_" + assDirectionalName))
								    associationNames.add(ns + "_" + assDirectionalName);



							}
						}

					}
				}
			}



		} catch (Exception e) {
			e.printStackTrace();
		}
        return associationNames;

	}	
	
	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}
							System.out.println("sourceOf-assDirecName:"
									+ assDirectionalName);

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();

								sb
										.append("{{LexWiki Association|"
												+ ns
												+ "_"
												+ assDirectionalName
												+ "|"
												+ ns
												+ "_"
												+ "("
												+ assConcept.getConceptCode()
												 + ")_"
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent()) 
												+ "}}\n");

								/*
								 * if (assDirectionalName.equals("PAR")) {
								 * isaIndex++;
								 * 
								 * sb.append("<noinclude>{{LexWiki Parent|" +
								 * ns + " " +
								 * this.mangle(assConcept.getEntityDescription()
								 * .getContent()) + "(" +
								 * assConcept.getConceptCode() + ")}}</noinclude>\n");
								 */
								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							}
						}

					}
				}

				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);

						// if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:"
								+ assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();

							if (assDirectionalName.equals("CHD")) {
								isaIndex++;

								if (assConcept.getEntityDescription() != null) {

									sb.append("<noinclude>{{LexWiki Parent|"
											+ ns
											+ "_"
											+ "("
											+ assConcept.getConceptCode()
											 + ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) 
											+ "}}</noinclude>\n");
									
								} else {
									nullConceptCodes.add(ref.getConceptCode());
								}

								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							} else {
								sb
										.append("<noinclude>{{LexWiki Inverse Association|"
												+ ns
												+ "_"
												+ assDirectionalName
												+ "|"
												+ ns
												+ "_"
												+ "("
												+ assConcept.getConceptCode()
												 + ")_"
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent()) 
												+ "}}</noinclude>\n");

							}
						}
					}
				}
			}
			// }

			if (isaIndex == 0) {
				sb.append("<noinclude>{{LexWiki Parent|" + localName
						+ "}}</noinclude>\n");

				/*
				 * sb.append("<noinclude>[[Category:" + localName + "]]</noinclude>\n");
				 */
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + "_" + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		thisConcept = this.mangle(thisConcept);

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}

							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];

								String thisAssEntityDescription = ns
										+ "_"
										+ assConcept.getEntityDescription()
												.getContent().replaceAll(" ",
														"_");
								thisAssEntityDescription = this
										.mangle(thisAssEntityDescription);

								sb.append("[ " + thisConcept + "] "
										+ "{ fill: 5; link:" + thisConcept
										+ "; } " + "-- " + assDirectionalName
										+ " --> {link:Relation:" + ns + "_"
										+ assDirectionalName
										+ "; start: front, 0; } "
										+ " [ Category:"
										+ thisAssEntityDescription + "("
										+ assConcept.getConceptCode() + ") ] "
										+ "{ fill:3; link: Category:"
										+ thisAssEntityDescription + "("
										+ assConcept.getConceptCode() + "); }"
										+ "\n");

							}

						}
					}
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");
							thisAssEntityDescription = this
									.mangle(thisAssEntityDescription);
							if (!assDirectionalName.equals("CHD")) {

								sb.append("[ " + thisConcept + "] "
										+ "{ fill: 5; link:"
										+ thisConcept
										+ "; } "
										+ "-- "
										+ assDirectionalName
										+ "(inverse) --> {link:Relation:"
										+ ns
										+ "_"
										+ assDirectionalName
										+ "; start: front, 0; } "
										+ " [ Category:"
										+ thisAssEntityDescription
										// + "(" + assConcept.getConceptCode()
										// + ") ] "

										+ " ] { fill: 4 ; link: Category:"
										+ thisAssEntityDescription + "("
										+ assConcept.getConceptCode() + "); }"
										+ "\n");

							}
						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = this.mangle(ref.getEntityDescription()
				.getContent());

		String thisConcept = "Category:" + ns + "_" + "("
		+ ref.getConceptCode() + ")_" + thisConceptName ;

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		lwn = lwn.replaceAll("[- ,]", "_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		lwn = lwn.trim().replaceAll("^_+", "").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangleProperty(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		// lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		// lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}

}
