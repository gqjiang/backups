package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;

public class GenerateContentForLexgridModel {

	public GenerateContentForLexgridModel() {

	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
				.getLocalName();
				String version = csrs[i].getCodingSchemeSummary().getRepresentsVersion();
				vecCodeSystems.add(localName + "|" + version);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
					.getCodingSchemeConcepts(
							csr.getCodingSchemeSummary()
							.getCodingSchemeURN(),
							Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {


			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
				.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}

	public String getContentForConceptCode(String conceptCode, 
			String localName, String ns) {
		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];


		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
			.createConceptReferenceList(new String[] { code_ },
					localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(
					null, null, null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
				.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
					sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));
					
					sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));
					
					sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));
					
					sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));
					
					sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry));
					
					sb.append("== Concept Property ==\n");
                    sb.append(this.getCodedEntryConceptProperty(entry));
            		
                    sb.append("== Comment ==\n");
            		sb.append(this.getCodedEntryComment(entry));
					
                    sb.append("== Associations ==\n");
                    sb.append(this.getCodedEntryAssociations(ref, localName, ns));
                    
                    sb.append("== Associations Graph ==\n");
                    sb.append(this.getCodedEntryAssociationsGraph(ref, localName, ns));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public Collection getContentForConceptCodeForBatchExport(String localName,
			  String ns) {

		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null,
					null, null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
				.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel("Category: " + description + "(" + code + ")");
				StringBuffer sb = new StringBuffer();

				sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName));
				
				sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(entry));
				
				sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(entry));
				
				sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(entry));
				
				sb.append("== Presentations ==\n");
                sb.append(this.getCodedEntryPresentations(entry));
                
				sb.append("== Comment ==\n");
				sb.append(this.getCodedEntryComment(entry));

				sb.append("== Associations ==\n");
                sb.append(this.getCodedEntryAssociations(ref, localName, ns));
 
                sb.append("== Associations Graph ==\n");
                sb.append(this.getCodedEntryAssociationsGraph(ref, localName, ns));
                
				sa.setText(sb.toString());
				allContents.add(sa);
			}



		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = localName
					+ " - "
					+ csrs[i].getCodingSchemeSummary()
					.getCodingSchemeURN();
					break;
				}
			}
			
			sb.append(" " + codingScheme + "\n");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		

		return sb.toString();
	}
	
	private String getCodedEntryCode(CodedEntry entry){
		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append(" [[ID:=" + code + "]]\n");	
		return sb.toString();
	}
	
	private String getCodedEntryDescription(CodedEntry entry){
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		sb.append(" [[Description:=" + description + "]]\n");        		
		return sb.toString();
		
	}
	
	private String getCodedEntryDefinition(CodedEntry entry){
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			sb.append(" * [[Definition:="
					+ entry.getDefinition(ii).getText()
					.getContent() + "]]\n");
		}
		
		return sb.toString();
		
	}
	
	private String getCodedEntryPresentations(CodedEntry entry){
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String text = pres.getText().getContent();
			text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			if (isPref) {
				String attrName = "Has Preferred " + propName;
				sb.append(" * " + attrName + ": [[" + attrName
						+ ":=" + text + "]]\n");
			} else {
				String fidelity = pres.getDegreeOfFidelity();
				String attrName = "Has " + fidelity + " "
				+ propName;
				sb.append(" * " + attrName + ": [[" + attrName
						+ ":=" + text + "]]\n");
			}
		}
		
		return sb.toString();
		
	}
	
	private String getCodedEntryConceptProperty(CodedEntry entry){
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry
			.getConceptProperty(cpi);
			String cpName = cp.getProperty();
			String cpText = cp.getText().getContent();
			sb.append(" * " + cpName + ": [[" + cpName
					+ ":=" + cpText + "]]\n");
		}

		
		return sb.toString();
	}
	
	private String getCodedEntryComment(CodedEntry entry){
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append(" * [[Comment:="
					+ entry.getComment(j).getText()
					.getContent() + "]]\n");
		}
		
		
		return sb.toString();
	}
	
	private String getCodedEntryAssociations(ResolvedConceptReference ref, 
			          String localName, String ns){
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng
			.resolveAsList(Constructors
					.createConceptReference(ref
							.getConceptCode(), ref
							.getCodingSchemeURN()),
							true, true, 1, 1, null, null, null,
							500);
			ResolvedConceptReference[] refGraphes = refList
			.getResolvedConceptReference();
			
			//to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph
				.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource
					.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
								// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						AssociatedConceptList acList = ass
						.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
						.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							if (ass.getDirectionalName()
									.length() > 1 &&
									assConcept
									.getEntityDescription()!= null)
									//&& !ass.getDirectionalName().equals("SIB")
									//&& !ass.getDirectionalName().equals("PAR")
									//&& !ass.getDirectionalName().equals("CHD")
									 {
								sb.append(" * [[Relation: "
										+ ass
										.getDirectionalName()
										+ "]] "
										+ " [["
										+ ass
										.getDirectionalName()
										+ "::Category:" + ns + " "
										+ assConcept
										.getEntityDescription()
										.getContent()
										+ "("
										+ assConcept
										.getConceptCode()
										+ ")]]\n");
							}

							if (ass.getDirectionalName()
									.equals("isa")
									|| ass.getDirectionalName()
									.equals("is_a")
									|| ass.getDirectionalName()
									.equals("CHD")) {
								if(assConcept
										.getEntityDescription()!= null){
								isaIndex++;
								sb.append("[[Category:" + ns + " "
										+ assConcept
										.getEntityDescription()
										.getContent()
										+ "("
										+ assConcept
										.getConceptCode()
										+ ")]]\n");
								}
							}
						}
					}
				}
				AssociationList aListTarget = refGraph
				.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget
					.getAssociation();
					// if(altes != null){
					for (int jt = 0; jt < altes.length; jt++) {
						// while(aListTarget != null &&
						// aListTarget.enumerateAssociation().hasMoreElements()){
						Association ass = altes[jt];
						AssociatedConceptList acList = ass
						.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
						.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							if (ass.getDirectionalName()
									.length() > 1 &&
									assConcept
									.getEntityDescription()!= null)
									//&& !ass
									//.getDirectionalName()
									//.equals("SIB")
									//&& !ass
									//.getDirectionalName()
									//.equals("PAR")
									//&& !ass
									//.getDirectionalName()
									//.equals("CHD")
									 {

								sb
								.append(" * [[Relation: "
										+ ass
										.getDirectionalName()
										+ "]] "
										+ " [["
										+ ass
										.getDirectionalName()
										+ "::Category:" + ns + " "
										+ assConcept
										.getEntityDescription()
										.getContent()
										+ "("
										+ assConcept
										.getConceptCode()
										+ ")]]\n");
							}

							if (ass.getDirectionalName()
									.equals("isa")
									|| ass.getDirectionalName()
									.equals("is_a")
									|| ass.getDirectionalName()
									.equals("CHD")) {
								if(assConcept
										.getEntityDescription()!= null){

								isaIndex++;
								sb
								.append("[[Category:" + ns + " "
										+ assConcept
										.getEntityDescription()
										.getContent()
										+ "("
										+ assConcept
										.getConceptCode()
										+ ")]]\n");
								}
							}
						}
					}
				}

			}
			if (isaIndex == 0) {
				sb.append("[[Category:" + localName + "]]\n");
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref, 
			String localName, String ns){
		StringBuffer sb = new StringBuffer();
		sb.append("<graph>\n");
		
		String thisConceptName = ref.getEntityDescription().getContent().replaceAll(" ", "_");
		
		String thisConcept = "Category:" + ns + " " + thisConceptName
		     + "(" +
		    ref.getConceptCode() + ")";
		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng
			.resolveAsList(Constructors
					.createConceptReference(ref
							.getConceptCode(), ref
							.getCodingSchemeURN()),
							true, true, 1, 1, null, null, null,
							500);
			ResolvedConceptReference[] refGraphes = refList
			.getResolvedConceptReference();
			
			//to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph
				.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource
					.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
								// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						AssociatedConceptList acList = ass
						.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
						.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							if (ass.getDirectionalName()
									.length() > 1 &&
									assConcept
									.getEntityDescription()!= null)
									//&& !ass.getDirectionalName().equals("SIB")
									//&& !ass.getDirectionalName().equals("PAR")
									//&& !ass.getDirectionalName().equals("CHD")
									 {
								String thisAssEntityDescription = ns + "_" + assConcept.getEntityDescription().getContent().replaceAll(" ","_");
								
								sb.append("[ " + thisConcept + "] " +
										"{ fill: 5; link:" + thisConcept + "; } " 
										+ "-- "
										+ ass.getDirectionalName()
										+ " --> {link:Relation:" 
										+ ass.getDirectionalName() 
										+ "; start: front, 0; } "
										+ " [ Category:" 
										+ thisAssEntityDescription
										+ "("
										+ assConcept
										.getConceptCode()
										+ ") ] " 
										+ "{ fill: 3; link: Category:" 
										+ thisAssEntityDescription
										+ "("
										+ assConcept.getConceptCode()
										+ "); }"
										+ "\n");
							}

						}
					}
				}
				AssociationList aListTarget = refGraph
				.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget
					.getAssociation();
					// if(altes != null){
					for (int jt = 0; jt < altes.length; jt++) {
						// while(aListTarget != null &&
						// aListTarget.enumerateAssociation().hasMoreElements()){
						Association ass = altes[jt];
						AssociatedConceptList acList = ass
						.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
						.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							if (ass.getDirectionalName()
									.length() > 1 &&
									assConcept
									.getEntityDescription()!= null) {

								String thisAssEntityDescription = ns + "_" + assConcept.getEntityDescription().getContent().replaceAll(" ","_");
								
								sb.append("[ " + thisConcept + "] " +
										"{ fill: 5; link:" + thisConcept + "; } " 
										+ "-- "
										+ ass.getDirectionalName()
										+ " --> {link:Relation:" 
										+ ass.getDirectionalName() 
										+ "; start: front, 0; } "
										+ " [ Category:" 
										+ thisAssEntityDescription
										+ "("
										+ assConcept
										.getConceptCode()
										+ ") ] " 
										+ "{ fill: 4 ; link: Category:" 
										+ thisAssEntityDescription
										+ "("
										+ assConcept.getConceptCode()
										+ "); }"
										+ "\n");

							}

						}
					}
				}

			}
        sb.append("</graph>");
		
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}	

}
