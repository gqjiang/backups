package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protegex.owl.*;

import conexp.core.*;
import conexp.frontend.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.FormalContextAdapter;

import net.sourceforge.jwbf.actions.http.mw.*;

public class GenerateTemplateContentForLexWikiICD10IndexCSV {

	private String fileName;

	private Map contents;

	private Frequency freqAll;

	private FormalContextAdapter adapter;

	private Map leadTermMap;

	public GenerateTemplateContentForLexWikiICD10IndexCSV(String fileName) {
		this.fileName = fileName;
	}

	public String getIndexFrequency() {
		this.calculateFrquency();
		StringBuffer sb = new StringBuffer();
		sb.append("Types|" + freqAll.getTypes() + "\n");
		sb.append("Tokens|" + freqAll.getTokens() + "\n");
		for (Iterator it = freqAll.iterator(); it.hasNext();) {
			String idxName = (String) it.next();
			int freq = freqAll.getFreq(idxName);
			if (this.isStartsWithUpperLetter(idxName)) {
				sb.append(idxName + "|" + freq + "|" + "HT" + "\n");
			} else {
				sb.append(idxName + "|" + freq + "|" + "ST" + "\n");
			}
		}

		return sb.toString();
	}

	public FormalContextAdapter getFormalContextAdapter() {
		adapter = new FormalContextAdapter();
		leadTermMap = new HashMap();
		freqAll = new Frequency();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				// if(items.length >= 10){
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];

				if (type.equals("K")) {
					idxName = idxName.substring(1);
					idxName = idxName.replaceAll("\"", "");
					// Collection atomicTerms =
					// this.getAllAtomicTermsForIndexName(idxName);
					String leadTerm = this.getLeadTerm(idxName);

					// this.addLeadTermModifiers(leadTerm, atomicTerms);
					adapter.addFormalObject(leadTerm);
					if (code1.length() > 1) {
						adapter.addFormalAttribute(code1);
						adapter.setRelation(leadTerm, code1);
					}
					if (code2.length() > 1) {
						adapter.addFormalAttribute(code2);
						adapter.setRelation(leadTerm, code2);
					}
					if (code3.length() > 1) {
						adapter.addFormalAttribute(code3);
						adapter.setRelation(leadTerm, code3);
					}

				}
				// }

				line = br.readLine();

			}

			br.close();

			/*
			 * for(Iterator it = leadTermMap.keySet().iterator();
			 * it.hasNext();){ String lTerm = (String)it.next(); Collection
			 * aTerms = (Collection)leadTermMap.get(lTerm); if(aTerms.size() >=
			 * 20){ adapter.addFormalObject(lTerm); for(Iterator it1 =
			 * aTerms.iterator(); it1.hasNext();){ String aterm =
			 * (String)it1.next(); adapter.addFormalAttribute(aterm);
			 * adapter.setRelation(lTerm, aterm); } } }
			 */

		} catch (IOException ie) {
			ie.printStackTrace();
		}
		return adapter;
	}
	

	
	

	
	public FormalContextAdapter getFormalContextAdapterForNeighbors(
			String selectedIdxName) {

		String selectedLeadTerm = this.getLeadTerm(selectedIdxName);
		
		Collection entriesWithinLeadTerm = this.getAllEntriesForSelectedLeadTerm(selectedLeadTerm);
		Collection codesWithinSelectedLeadTerm = new ArrayList();

		adapter = new FormalContextAdapter();
		Map nonLeadTermMap = new HashMap();
		freqAll = new Frequency();
		
		for(Iterator it0 = entriesWithinLeadTerm.iterator(); it0.hasNext();){

				String[] items = (String[])it0.next();
				// if(items.length >= 10){
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];
				
				idxName = idxName.substring(1);
				idxName = idxName.replaceAll("\"", "");
				

				if (idxName.indexOf(selectedIdxName) >= 0 || level.equals("0")) {
					// this.addLeadTermModifiers(leadTerm, atomicTerms);
					Collection atomicTerms = this
							.getAllAtomicTermsForIndexName(idxName);

					if (code1.length() > 1) {
						adapter.addFormalObject(code1);
						//String supercode = this.getSuperCode(code1);
						//adapter.addFormalObject(supercode);
						//adapter.addFormalAttribute(supercode);
						//adapter.setRelation(code1, supercode);

						codesWithinSelectedLeadTerm.add(code1);
						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code1, aterm);
							//adapter.setRelation(supercode, aterm);
						}

					}

					if (code2.length() > 1) {
						adapter.addFormalObject(code2);
						codesWithinSelectedLeadTerm.add(code2);
						//String supercode = this.getSuperCode(code1);
						//adapter.addFormalObject(supercode);
						//adapter.addFormalAttribute(supercode);
						//adapter.setRelation(code2, supercode);

						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code2, aterm);
							//adapter.setRelation(supercode, aterm);
						}
					}
					if (code3.length() > 1) {
						adapter.addFormalObject(code3);
						codesWithinSelectedLeadTerm.add(code1);
						//String supercode = this.getSuperCode(code1);
						//adapter.addFormalObject(supercode);
						//adapter.addFormalAttribute(supercode);
						//adapter.setRelation(code3, supercode);

						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code3, aterm);
							//adapter.setRelation(supercode, aterm);
						}
					}
				}else{
					nonLeadTermMap.put(idxName, items);
				}
		}
		
		for(Iterator it1 = nonLeadTermMap.keySet().iterator(); it1.hasNext();){
			String idxxName = (String)it1.next();
			String[] items = (String[]) nonLeadTermMap.get(idxxName);
			String level = items[0];
			String type = items[1];
			String numcodes = items[2];
			String code1 = items[3];
			String code2 = items[4];
			String code3 = items[5];
			String idxName = items[6];
			String cumText = items[7];
			String seeText = items[8];
			String seeAlsoText = items[9];
			
			idxName = idxName.substring(1);
			idxName = idxName.replaceAll("\"", "");
			
			Collection atomicTerms = this.getAllAtomicTermsForIndexName(idxName);
			
			
			if (code1.length() > 1 && codesWithinSelectedLeadTerm.contains(code1)) {
				adapter.addFormalObject(code1);
				//String supercode = this.getSuperCode(code1);
				//adapter.addFormalObject(supercode);
				//adapter.addFormalAttribute(supercode);
				//adapter.setRelation(code1, supercode);

				for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
					String aterm = (String) it.next();
					adapter.addFormalAttribute(aterm);
					adapter.setRelation(code1, aterm);
					//adapter.setRelation(supercode, aterm);
				}

			}

			if (code2.length() > 1 && codesWithinSelectedLeadTerm.contains(code2)) {
				adapter.addFormalObject(code2);
				//String supercode = this.getSuperCode(code1);
				//adapter.addFormalObject(supercode);
				//adapter.addFormalAttribute(supercode);
				//adapter.setRelation(code2, supercode);
				for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
					String aterm = (String) it.next();
					adapter.addFormalAttribute(aterm);
					adapter.setRelation(code2, aterm);
					//adapter.setRelation(supercode, aterm);
				}
			}
			if (code3.length() > 1 && codesWithinSelectedLeadTerm.contains(code3)) {
				adapter.addFormalObject(code3);
				//String supercode = this.getSuperCode(code1);
				//adapter.addFormalObject(supercode);
				//adapter.addFormalAttribute(supercode);
				//adapter.setRelation(code3, supercode);
				for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
					String aterm = (String) it.next();
					adapter.addFormalAttribute(aterm);
					adapter.setRelation(code3, aterm);
					//adapter.setRelation(supercode, aterm);
				}
			}			
		}
		
		return adapter;
	}
	
	private String getSuperCode(String code){
		String ret = "";
		int index = code.indexOf(".");
		if(index >= 0){
			ret = code.substring(0, index);
		}else{
			ret = code;
		}
		
		
		return ret;
	}
	
	private Collection getAllEntriesForSelectedLeadTerm(String selectedLeadTerm){
		Collection ret = new ArrayList();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				String idxName = items[6];
				idxName = idxName.substring(1);
				idxName = idxName.replaceAll("\"", "");
				String leadTerm = this.getLeadTerm(idxName);
				if (leadTerm.equals(selectedLeadTerm)) {
				    ret.add(items);
				}
				line = br.readLine();
			}
			br.close();
		} catch (IOException ie) {
			ie.printStackTrace();
		}		
		
		
		return ret;
		
	}
	
	private Collection getEntriesForCode(String code, Collection entries){
		Collection ret = new ArrayList();
		for(Iterator it = entries.iterator(); it.hasNext();){
			String[] items = (String[])it.next();
			// if(items.length >= 10){
			String level = items[0];
			String type = items[1];
			String numcodes = items[2];
			String code1 = items[3];
			String code2 = items[4];
			String code3 = items[5];
			String idxName = items[6];
			String cumText = items[7];
			String seeText = items[8];
			String seeAlsoText = items[9];
			
			if(code1.length() > 1 && code1.equals(code)){
				ret.add(items);
			}else if(code2.length() > 1 && code2.equals(code)){
				ret.add(items);
			}else if(code3.length() > 1 && code3.equals(code)){
				ret.add(items);
			}
			
			
		}
		
		return ret;
	}
	
	
	public FormalContextAdapter getFormalContextAdapterCodeLeadTerms(
			String selectedIdxName) {

		String selectedLeadTerm = this.getLeadTerm(selectedIdxName);
		Collection codesWithinLeadTerm = new ArrayList();

		adapter = new FormalContextAdapter();
		Map nonLeadTermMap = new HashMap();
		freqAll = new Frequency();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				// if(items.length >= 10){
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];

				// if(type.equals("K")){
				idxName = idxName.substring(1);
				idxName = idxName.replaceAll("\"", "");
				String leadTerm = this.getLeadTerm(idxName);
				if (leadTerm.equals(selectedLeadTerm)) {
					// this.addLeadTermModifiers(leadTerm, atomicTerms);
					Collection atomicTerms = this
							.getAllAtomicTermsForIndexName(idxName);

					if (code1.length() > 1) {
						adapter.addFormalObject(code1);
						codesWithinLeadTerm.add(code1);
						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code1, aterm);
						}

					}

					if (code2.length() > 1) {
						adapter.addFormalObject(code2);
						codesWithinLeadTerm.add(code2);
						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code2, aterm);
						}
					}
					if (code3.length() > 1) {
						adapter.addFormalObject(code3);
						codesWithinLeadTerm.add(code1);
						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code3, aterm);
						}
					}
				}else{
					nonLeadTermMap.put(idxName, items);
				}
				// }
				// }

				line = br.readLine();

			}

			br.close();
			
			this.addDuplicateCodesInOtherDomains(nonLeadTermMap, codesWithinLeadTerm);

		} catch (IOException ie) {
			ie.printStackTrace();
		}
		return adapter;
	}

	private void addDuplicateCodesInOtherDomains(Map nonLeadTerms,
			Collection codes) {
        for(Iterator it0 = nonLeadTerms.keySet().iterator(); it0.hasNext();){
        	String idxName = (String) it0.next();
        	
				String[] items = (String[]) nonLeadTerms.get(idxName);
				// if(items.length >= 10){
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				//String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];
					Collection atomicTerms = this
							.getAllAtomicTermsForIndexName(idxName);

					if (code1.length() > 1 && codes.contains(code1)) {
						adapter.addFormalObject(code1);
						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code1, aterm);
						}

					}

					if (code2.length() > 1 && codes.contains(code2)) {
						adapter.addFormalObject(code2);

						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code2, aterm);
						}
					}
					if (code3.length() > 1 && codes.contains(code3)) {
						adapter.addFormalObject(code3);
						for (Iterator it = atomicTerms.iterator(); it.hasNext();) {
							String aterm = (String) it.next();
							adapter.addFormalAttribute(aterm);
							adapter.setRelation(code3, aterm);
						}
					}
				}


	}

	public FormalContextAdapter getFormalContextAdapterLeadTermCodes() {
		adapter = new FormalContextAdapter();
		leadTermMap = new HashMap();
		freqAll = new Frequency();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				// if(items.length >= 10){
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];

				if (type.equals("K")) {
					idxName = idxName.substring(1);
					idxName = idxName.replaceAll("\"", "");
					String leadTerm = this.getLeadTerm(idxName);

					adapter.addFormalObject(leadTerm);
					if (code1.length() > 1) {
						adapter.addFormalAttribute(code1);
						adapter.setRelation(leadTerm, code1);
					}
					if (code2.length() > 1) {
						adapter.addFormalAttribute(code2);
						adapter.setRelation(leadTerm, code2);
					}
					if (code3.length() > 1) {
						adapter.addFormalAttribute(code3);
						adapter.setRelation(leadTerm, code3);
					}

				}
				// }

				line = br.readLine();

			}

			br.close();

		} catch (IOException ie) {
			ie.printStackTrace();
		}
		return adapter;
	}

	public Frequency getFrequencyForLeadTermEntries(String strType) {
		Frequency freq = new Frequency();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];

				if (type.equals(strType)) {
					idxName = idxName.substring(1);
					idxName = idxName.replaceAll("\"", "");
					String leadTerm = this.getLeadTerm(idxName);
                    freq.add(leadTerm);
				}
				

				line = br.readLine();

			}

			br.close();

		} catch (IOException ie) {
			ie.printStackTrace();
		}
		return freq;
	}	
	
	public FormalContextAdapter getFormalContextAdapterLeadTermModifiers() {
		adapter = new FormalContextAdapter();
		leadTermMap = new HashMap();
		freqAll = new Frequency();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				// if(items.length >= 10){
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];

				if (type.equals("K")) {
					idxName = idxName.substring(1);
					idxName = idxName.replaceAll("\"", "");
					Collection atomicTerms = this
							.getAllAtomicTermsForIndexName(idxName);
					String leadTerm = this.getLeadTerm(idxName);

					this.addLeadTermModifiers(leadTerm, atomicTerms);

				}
				// }

				line = br.readLine();

			}

			br.close();

			for (Iterator it = leadTermMap.keySet().iterator(); it.hasNext();) {
				String lTerm = (String) it.next();
				Collection aTerms = (Collection) leadTermMap.get(lTerm);
				if (aTerms.size() >= 20) {
					adapter.addFormalObject(lTerm);
					for (Iterator it1 = aTerms.iterator(); it1.hasNext();) {
						String aterm = (String) it1.next();
						adapter.addFormalAttribute(aterm);
						adapter.setRelation(lTerm, aterm);
					}
				}
			}

		} catch (IOException ie) {
			ie.printStackTrace();
		}
		return adapter;
	}

	private void addLeadTermModifiers(String leadTerm, Collection atomicTerms) {
		if (leadTermMap.containsKey(leadTerm)) {
			Collection terms = (Collection) leadTermMap.get(leadTerm);
			terms.addAll(atomicTerms);
		} else {
			leadTermMap.put(leadTerm, atomicTerms);
		}
	}
	
	

	public Map getAllContents() {
		contents = new HashMap();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while (line != null) {
				String[] items = line.split(",");
				String level = items[0];
				String type = items[1];
				String numcodes = items[2];
				String code1 = items[3];
				String code2 = items[4];
				String code3 = items[5];
				String idxName = items[6];
				String cumText = items[7];
				String seeText = items[8];
				String seeAlsoText = items[9];

				StringBuffer sb = new StringBuffer();
				sb.append(this.getLexWikiIndexTermTemplate(idxName, level));
				if (level.equals("0") && type.equals("K")) {
					sb.append(this
							.getLexWikiSemanticTypeTemplate("Disease Type"));
				} else if (level.equals("0") && type.equals("N")) {
					sb.append(this.getLexWikiSemanticTypeTemplate("Neoplasms"));
				} else if (level.equals("0") && type.equals("U")) {
					sb.append(this
							.getLexWikiSemanticTypeTemplate("External Causes"));
				} else if (level.equals("0") && type.equals("C")) {
					sb
							.append(this
									.getLexWikiSemanticTypeTemplate("Drugs and Chemical Substances"));

				}
				sb.append(this.getLexWikiPreferredNameTemplate(idxName));
				sb.append(this.getLexWikiIsLeadTermTemplate(level));

				if (seeText.length() > 2)
					sb.append(this.getLexWikiSeeAlsoTemplate("See", seeText));

				if (seeAlsoText.length() > 2)
					sb.append(this.getLexWikiSeeAlsoTemplate("See Also",
							seeAlsoText));

				sb.append(this.getLexWikiParentTemplate(type));
				if (code1.length() > 1)
					sb.append(this.getLexWikiIndexToTemplate(code1, "ICD10"));
				if (code2.length() > 1)
					sb.append(this.getLexWikiIndexToTemplate(code2, "ICD10"));
				if (code3.length() > 1)
					sb.append(this.getLexWikiIndexToTemplate(code3, "ICD10"));

				sb.append(this.getLexWikiSubIndexesTemplate());

				idxName = idxName.substring(1);
				idxName = idxName.replaceAll("\"", "");
				contents.put(idxName, sb.toString());
				line = br.readLine();
			}

			br.close();
		} catch (IOException ie) {
			ie.printStackTrace();
		}

		return contents;
	}

	public Object[] getIndexNames() {
		Object[] ret = contents.keySet().toArray();
		Arrays.sort(ret);
		return ret;
	}

	public String getContentForIndexName(String idxName) {
		return (String) contents.get(idxName);
	}

	public Collection getWikiSimpleArticles() {
		Collection ret = new ArrayList();
		for (Iterator it = contents.keySet().iterator(); it.hasNext();) {
			String idxName = (String) it.next();
			String content = (String) contents.get(idxName);
			SimpleArticle sa = new SimpleArticle();
			idxName = idxName.replaceAll("\\|", "/");
			String label = "Index:" + this.mangle(idxName);
			sa.setLabel(label);
			sa.setText(content);
			ret.add(sa);
		}

		return ret;
	}

	private void calculateFrquency() {
		freqAll = new Frequency();
		for (Iterator it = contents.keySet().iterator(); it.hasNext();) {
			String idxName = (String) it.next();
			String[] items = idxName.split("|");
			for (int i = 0; i < items.length; i++) {
				String item = items[i];
				if (hasTokenParentheses(item)) {
					// System.out.println("Yes: has parentheses tokens");
					this.getFrequencyTokenParentheses(item);
					this.getFrequencyTokenNestedParentheses(item);

					item = item.replaceAll("\\(.+\\)", "");
					item = item.trim();
					if (item.indexOf(",") >= 0) {
						String[] terms = item.split(",");
						for (int j = 0; j < terms.length; j++) {
							freqAll.add(terms[j].trim());
						}
					} else {
						freqAll.add(item.trim());
					}
				} else {
					if (item.indexOf(",") >= 0) {
						String[] terms = item.split(",");
						for (int j = 0; j < terms.length; j++) {
							freqAll.add(terms[j].trim());
						}
					} else {
						freqAll.add(item.trim());
					}

				}

			}

		}

	}

	private String getLeadTerm(String idxName) {
		Collection ret = new ArrayList();
		String[] items = idxName.split("\\|");
		// for (int i = 0; i < items.length; i++) {
		String item = items[0];
		if (hasTokenParentheses(item)) {
			item = item.replaceAll("\\(.+\\)", "");
			item = item.trim();
		}

		return item;

	}

	private Collection getAllAtomicTermsForIndexName(String idxName) {
		Collection ret = new ArrayList();
		String[] items = idxName.split("\\|");
		for (int i = 0; i < items.length; i++) {
			String item = items[i];
			if (hasTokenParentheses(item)) {
				
				if(i == 0){
				// System.out.println("Yes: has parentheses tokens");
				    //ret.addAll(this.getFrequencyTokenParentheses(item));
				    //ret.addAll(this.getFrequencyTokenNestedParentheses(item));
				  ret.add("unspecified");
				}

				item = item.replaceAll("\\(.+\\)", "");
				item = item.trim();
				if (item.indexOf(",") >= 0) {
					String[] terms = item.split(",");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim().toLowerCase());
					}
				} else if (item.indexOf(" or ") >= 0) {
					String[] terms = item.split(" or ");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim().toLowerCase());
					}
				} else {

					freqAll.add(item.trim());
					ret.add(item.trim().toLowerCase());
				}
			} else {
				if (item.indexOf(",") >= 0) {
					String[] terms = item.split(",");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim().toLowerCase());
					}
				} else if (item.indexOf(" or ") >= 0) {
					String[] terms = item.split(" or ");
					for (int j = 0; j < terms.length; j++) {
						freqAll.add(terms[j].trim());
						ret.add(terms[j].trim().toLowerCase());
					}
				} else {
					freqAll.add(item.trim());
					ret.add(item.trim().toLowerCase());
				}

			}

		}

		return ret;
	}


	
	private boolean isStartsWithUpperLetter(String line) {
		boolean ret = false;
		if (line != null && line.length() > 0) {

			String firstLetter = line.substring(0, 1);

			Pattern p = Pattern.compile("[A-Z]");

			Matcher m = p.matcher(firstLetter);

			if (m.find()) {
				ret = true;
			}
		}

		return ret;
	}

	private boolean hasTokenParentheses(String line) {
		boolean ret = false;

		Pattern p = Pattern.compile("(\\(.+\\))");

		Matcher m = p.matcher(line);

		if (m.find()) {
			int count = m.groupCount();
			// System.out.println(count);

			ret = true;
		}

		return ret;
	}

	private Collection getFrequencyTokenParentheses(String line) {
		Collection ret = new ArrayList();

		Pattern p = Pattern.compile("(\\([a-zA-Z' ]+?\\))");

		Matcher m = p.matcher(line);

		if (m.find()) {
			int count = m.groupCount();
			// System.out.println(count);
			for (int i = 0; i < count; i++) {
				String group = m.group(i);
				group = group.replaceAll("\\(", "");
				group = group.replaceAll("\\)", "");
				System.out.println(group);
				freqAll.add(group.trim());
				ret.add(group.trim());
			}
		}

		return ret;

	}

	private Collection getFrequencyTokenNestedParentheses(String line) {
		Collection ret = new ArrayList();

		Pattern p = Pattern.compile("(\\([a-zA-Z' ]+?\\()");

		Matcher m = p.matcher(line);

		if (m.find()) {
			int count = m.groupCount();
			// System.out.println(count);
			for (int i = 0; i < count; i++) {
				String group = m.group(i);
				group = group.replaceAll("\\(", "");
				group = group.replaceAll("\\)", "");
				System.out.println(group);
				freqAll.add(group.trim());
				ret.add(group.trim());
			}
		}

		return ret;

	}

	private String getLexWikiIndexTermTemplate(String name, String level) {
		StringBuffer sb = new StringBuffer();
		name = name.substring(1);
		name = name.replaceAll("\"", "");
		if (level.equals("0")) {
			sb.append("{{LexWiki Index Term|" + name + "}}\n");
		} else {
			int index = name.lastIndexOf("|");
			name = name.substring(index + 1);
			sb.append("{{LexWiki Index Term|" + name + "}}\n");
		}

		return sb.toString();
	}

	private String getLexWikiSemanticTypeTemplate(String type) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Index Semantic Type|" + type + "}}\n");

		return sb.toString();
	}

	private String getLexWikiPreferredNameTemplate(String name) {
		StringBuffer sb = new StringBuffer();
		name = name.substring(1);
		name = name.replaceAll("\"", "");
		name = name.replaceAll("\\|", "/");
		sb.append("{{LexWiki Preferred Name|" + name + "}}\n");

		return sb.toString();
	}

	private String getLexWikiIsLeadTermTemplate(String level) {
		StringBuffer sb = new StringBuffer();
		if (level.equals("0")) {
			sb.append("{{LexWiki Concept Property|isLeadTerm|true}}\n");
		} else {
			sb.append("{{LexWiki Concept Property|isLeadTerm|false}}\n");
		}

		return sb.toString();
	}

	private String getLexWikiSeeAlsoTemplate(String see, String term) {
		StringBuffer sb = new StringBuffer();
		term = term.substring(1);
		term = term.replaceAll("\"", "");
		sb.append("{{LexWiki SeeAlso|" + see + "|" + term + "}}\n");
		return sb.toString();
	}

	private String getLexWikiParentTemplate(String type) {
		StringBuffer sb = new StringBuffer();
		if (type.equals("K")) {
			sb.append("{{LexWiki Parent|Index To Diseases}}\n");
		} else if (type.equals("N")) {
			sb.append("{{LexWiki Parent|Index To Neoplasms}}\n");
		} else if (type.equals("U")) {
			sb.append("{{LexWiki Parent|Index To External Causes}}\n");
		} else if (type.equals("C")) {
			sb
					.append("{{LexWiki Parent|Index To Drugs And Chemical Substances}}\n");
		}
		return sb.toString();
	}

	private String getLexWikiIndexToTemplate(String code, String ns) {
		StringBuffer sb = new StringBuffer();
		code = code.replaceAll("\\+", "");
		code = code.replaceAll("\\*", "");
		sb.append("{{LexWiki IndexTo|" + ns + "|(" + code + ")}}\n");

		return sb.toString();
	}

	private String getLexWikiSubIndexesTemplate() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki SubIndexes|{{PAGENAME}}}}\n");
		return sb.toString();
	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		// lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		// lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}
	
	public void printFrequency(Frequency freq){
		for(Iterator it = freq.iterator(); it.hasNext();){
			String term = (String)it.next();
			int intValue = freq.getFreq(term);
			System.out.println(term + "|" + intValue);
		}
	}
	
	public static void main(String[] args){
		final String fileName = "c:\\whoproject\\icd10index.csv";
		GenerateTemplateContentForLexWikiICD10IndexCSV model =
			new GenerateTemplateContentForLexWikiICD10IndexCSV(fileName);
		Frequency freq = model.getFrequencyForLeadTermEntries("C");
		model.printFrequency(freq);
		
	}

}
