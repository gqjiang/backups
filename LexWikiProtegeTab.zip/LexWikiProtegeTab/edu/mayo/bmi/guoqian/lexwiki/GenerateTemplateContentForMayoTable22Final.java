package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;

public class GenerateTemplateContentForMayoTable22Final {

	private Map superClasses = new HashMap();

	private Map highLevelClasses = new HashMap();

	private Collection introducedIcd9Codes = new ArrayList();

	private Map allIcd9CodesMap = new HashMap();
	
	private Map allDescriptionsICD9CM = new HashMap();

	public GenerateTemplateContentForMayoTable22Final() {
	}

	public Map getSuperClasses() {
		return superClasses;
	}

	public Collection getIntroducedIcd9Codes() {
		return introducedIcd9Codes;
	}
	
	public Map getAllDescriptionsICD9CM(){
		
		return allDescriptionsICD9CM;
	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				vecCodeSystems.add(localName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}

	// for mayo table 22 only
	public Map getAllDescriptionForCodes(String localName) {

		Map ret = new HashMap();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.put(code, description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {
		Map allSuperClasses = this.getMapForSuperClass(localName, ns);
		Map allDescriptions = this.getAllDescriptionForCodes(localName);
		Map allDescriptionsICD9CM = this.getAllDescriptionForCodes("ICD-9-CM");

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {

					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");
					if (ns.equals("MT")) {
						sb.append(this
								.getCodedEntryAssociationsForTable22(ref,
										localName, ns, allSuperClasses,
										allDescriptions, allDescriptionsICD9CM));
					} else {
						sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					}

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm());

					sb
							.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public String getContentForDebug(String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				sb.append(this.getCodedEntryAssociations(ref, localName, ns));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();

	}

	// for mayo table 22 only
	public Map getMapForAllIcd9Codes(String localName, String ns) {
		System.out.println("geting icd9codes for table22 codes");
		Map allICD9Codes = new HashMap();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String icd9Code = this
						.getEquivalentICD9Code(ref, localName, ns);
				allICD9Codes.put(code, icd9Code);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return allICD9Codes;
	}

	// for mayo table 22 only
	public Map getMapForSuperClass(String localName, String ns) {

		Map allSuperClasses = new HashMap();
		Map allICD9Codes = this.getMapForAllIcd9Codes(localName, ns);
		Map allICD9Codes2 = this.getMapForAllIcd9Codes(localName, ns);
		allIcd9CodesMap = this.getCodeSuperCodeForICD9CM("ICD-9-CM", "ICD9CM");

		int index = 0;

		// loop1: search for direct super code
		for (Iterator it1 = allICD9Codes.keySet().iterator(); it1.hasNext();) {
			String code = (String) it1.next();
			System.out.println("loop1:" + index++);
			String icd9Code = (String) allICD9Codes.get(code);
			String nodotIcd9Code = null;
			if (icd9Code != null && icd9Code.indexOf(".") >= 0) {
				nodotIcd9Code = icd9Code.replaceAll("\\.", "");
			} else {
				nodotIcd9Code = icd9Code;
			}
			// System.out.println("icd9Code:" + nodotIcd9Code);
			if (nodotIcd9Code != null) {
				int len = nodotIcd9Code.length();
				Collection manySuperClses = new ArrayList();
				for (Iterator it2 = allICD9Codes2.keySet().iterator(); it2
						.hasNext();) {
					String code2 = (String) it2.next();
					String icd9Code2 = (String) allICD9Codes2.get(code2);
					String nodotIcd9Code2 = null;

					if (icd9Code2 != null && icd9Code2.indexOf(".") >= 0) {
						nodotIcd9Code2 = icd9Code2.replaceAll("\\.", "");
					} else {
						nodotIcd9Code2 = icd9Code2;
					}
					// System.out.println("icd9Code2:" + nodotIcd9Code2);
					if (nodotIcd9Code2 != null) {
						int len2 = nodotIcd9Code2.length();
						int lenDiff = len - len2;

						// determine the super class
						if (icd9Code2 != null && icd9Code2.indexOf(".") < 0) {
							icd9Code2 = icd9Code2 + ".";
						}

						if (lenDiff == 1 && icd9Code.startsWith(icd9Code2)) {

							manySuperClses.add(code2);
							// break;
						}
					}
				}
				if (manySuperClses.size() > 0) {
					allSuperClasses.put(code, manySuperClses);
				}
			}
		}

		index = 0;

		// loop2: to get all dot codes role up to non dot codes

		// for(int i = 0; i < 2; i++){
		for (Iterator it1 = allICD9Codes.keySet().iterator(); it1.hasNext();) {
			String code = (String) it1.next();

			if (!allSuperClasses.containsKey(code)) {
				System.out.println("loop2:" + index++);
				String icd9Code = (String) allICD9Codes.get(code);
				if (icd9Code != null && icd9Code.indexOf(".") >= 0) {
					if (allIcd9CodesMap.containsKey(icd9Code)) {
						String superIcd9Code = (String) allIcd9CodesMap
								.get(icd9Code);

						Collection uniSuperClses = new ArrayList();
						uniSuperClses.add("I" + superIcd9Code);
						if (!introducedIcd9Codes.contains(superIcd9Code)) {
							introducedIcd9Codes.add(superIcd9Code);
						}
						allSuperClasses.put(code, uniSuperClses);

						// System.out.println(code + "|" + superIcd9Code);

						// if super code still contains dot
						if (superIcd9Code.indexOf(".") >= 0) {

							if (allIcd9CodesMap.containsKey(superIcd9Code)) {
								String ssuperIcd9Code = (String) allIcd9CodesMap
										.get(superIcd9Code);

								// if some codes have mapping with this ssuper
								// code
								if (allICD9Codes2.containsValue(ssuperIcd9Code)) {

									Collection manySuperClses = new ArrayList();

									for (Iterator it2 = allICD9Codes2.keySet()
											.iterator(); it2.hasNext();) {
										String code2 = (String) it2.next();
										String icd9Code2 = (String) allICD9Codes2
												.get(code2);
										if (icd9Code2 != null
												&& icd9Code2
														.equals(ssuperIcd9Code)) {
											manySuperClses.add(code2);
										}
									}
									// put super codes as table 22 code
									allSuperClasses.put("I" + superIcd9Code,
											manySuperClses);

								} else {// no mapping
									Collection manySuperClses = new ArrayList();
									manySuperClses.add("I" + ssuperIcd9Code);
									if (!introducedIcd9Codes
											.contains(ssuperIcd9Code)) {
										introducedIcd9Codes.add(ssuperIcd9Code);
									}

									// then put super codes as icd9code (without
									// dot)
									allSuperClasses.put("I" + superIcd9Code,
											manySuperClses);

								}

							}
						}
					}
				}
			}
		}
		// }

		index = 0;

		// loop3: for no dot code only
		for (Iterator it1 = allICD9Codes.keySet().iterator(); it1.hasNext();) {
			String code = (String) it1.next();

			if (!allSuperClasses.containsKey(code)) {
				System.out.println("loop3:" + index++);
				String icd9Code = (String) allICD9Codes.get(code);

				if (icd9Code != null && icd9Code.indexOf(".") < 0) {
					if (allIcd9CodesMap.containsKey(icd9Code)) {
						String superIcd9Code = (String) allIcd9CodesMap
								.get(icd9Code);
						if (!introducedIcd9Codes.contains(superIcd9Code)) {
							introducedIcd9Codes.add(superIcd9Code);
						}
						Collection uniSuperCode = new ArrayList();
						uniSuperCode.add("I" + superIcd9Code);
						allSuperClasses.put(code, uniSuperCode);
						if (allIcd9CodesMap.containsKey(superIcd9Code)) {
							String ssuperIcd9Code = (String) allIcd9CodesMap
									.get(superIcd9Code);
							if (!introducedIcd9Codes.contains(ssuperIcd9Code)) {
								introducedIcd9Codes.add(ssuperIcd9Code);
							}
							Collection uniSSuperCode = new ArrayList();
							uniSSuperCode.add("I" + ssuperIcd9Code);
							allSuperClasses.put("I" + superIcd9Code,
									uniSSuperCode);
						}
					}

				} else {
					System.out.println("strange code:" + code + "|" + icd9Code
							+ "\n");
				}

			}
		}

		Collection tempIcd9Codes = new ArrayList();

		// loop4
		index = 0;
		for (Iterator it1 = introducedIcd9Codes.iterator(); it1.hasNext();) {
			String introCode = (String) it1.next();
			if (!allSuperClasses.containsKey(introCode)) {
				System.out.println("loop4:" + index++);

				if (allIcd9CodesMap.containsKey(introCode)) {
					String superIcd9Code = (String) allIcd9CodesMap
							.get(introCode);
					tempIcd9Codes.add(superIcd9Code);
					Collection uniSuperCode = new ArrayList();
					uniSuperCode.add("I" + superIcd9Code);
					allSuperClasses.put("I" + introCode, uniSuperCode);
					if (allIcd9CodesMap.containsKey(superIcd9Code)) {
						String ssuperIcd9Code = (String) allIcd9CodesMap
								.get(superIcd9Code);
						tempIcd9Codes.add(ssuperIcd9Code);
						Collection uniSSuperCode = new ArrayList();
						uniSSuperCode.add("I" + ssuperIcd9Code);
						allSuperClasses.put("I" + superIcd9Code, uniSSuperCode);
					}
				}
			}
		}

		for (Iterator it = tempIcd9Codes.iterator(); it.hasNext();) {
			String tempIcd9Code = (String) it.next();
			if (!introducedIcd9Codes.contains(tempIcd9Code)) {
				introducedIcd9Codes.add(tempIcd9Code);
			}
		}

		superClasses = allSuperClasses;

		return allSuperClasses;
	}

	private Map getHighLevelCodeMap() {
		Map highLevelMap = new HashMap();
		highLevelMap.put("001-139.8", "Infectious and Parasitic Diseases");
		highLevelMap.put("140-239.9", "Neoplasms");
		highLevelMap.put("240-279.9",
				"Endocrine, Nutritional and Metabolic, Immunity");
		highLevelMap.put("280-289.9", "Blood and Blood Forming Organs");
		highLevelMap.put("290-319", "Mental Disorders");
		highLevelMap.put("320-389.9", "Nervous Systems and Sense Organs");
		highLevelMap.put("390-459.9", "Circulatory System");
		highLevelMap.put("460-519.9", "Respiratory System");
		highLevelMap.put("520-579.9", "Digestive System");
		highLevelMap.put("580-629.9", "Genitourinary System");
		highLevelMap.put("630-677",
				"Complications of Pregnancy, Childbirth & Puerperium");
		highLevelMap.put("680-709.9", "Skin and Subcurtaneous Tissue");
		highLevelMap.put("710-739.9", "Musculoskeletal and Connective Tissue");
		highLevelMap.put("740-759.9", "Congenital Anomalies");
		highLevelMap.put("760-779.9", "Conditions in the Perinatal Period");
		highLevelMap.put("780-799.9",
				"Symptoms, Signs, and Ill-Defined Conditions");
		highLevelMap.put("800-999.9", "Injury and Poisoning");
		highLevelMap.put("V01-V86.1", "V Codes");

		return highLevelMap;
	}

	// for ICD9cm only
	public Map getCodeSuperCodeForICD9CM(String localName, String ns) {
		System.out.println("geting supercodes  for icd9cm codes");

		Map allContents = new HashMap();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String superCode = this.getSuperCodeForIcd9cmCode(ref,
						localName, ns);
				// System.out.println(code + "|" + superCode);
				allContents.put(code, superCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {

		Map allSuperClasses = this.getMapForSuperClass(localName, ns);
		Map allDescriptions = this.getAllDescriptionForCodes(localName);
		allDescriptionsICD9CM = this.getAllDescriptionForCodes("ICD-9-CM");
        //Map topLevelCodesMap = this.getHighLevelCodeMap();
        
		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			
			//This loop goes through all table22 original codes
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel("Category:" + description + "(" + ns + code + ")");
				//System.out.println("Category:" + ns + " " + description + "("
				//		+ code + ")");
				StringBuffer sb = new StringBuffer();

				// if (ns.equals("NCI") && code.startsWith("R")){
				sb.append(this.getHeaderBasicData());

				// sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName));

				// sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(entry));

				// sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(entry));

				// sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(entry));

				// sb.append("== Presentations ==\n");
				sb.append(this.getCodedEntryPresentations(entry, ns));

				//sb.append(this.getHeaderProperties());

				// sb.append("== Concept Property ==\n");
				sb.append(this.getCodedEntryConceptProperty(entry, ns));

				// sb.append("== Comment ==\n");
				sb.append(this.getCodedEntryComment(entry));

				//sb.append(this.getHeaderAssoications());

				// sb.append("== Associations ==\n");

				
				sb.append(this.getCodedEntryAssociationsForTable22(ref,
							localName, ns, allSuperClasses, allDescriptions,
							allDescriptionsICD9CM));
				
				sb.append(this.getHeaderAssociationsGraph());

				// sb.append("== Associations Graph ==\n");
				sb.append(this.getCodedEntryAssociationsGraph(ref, localName,
						ns));

				sb.append(this.getDefaultForm());

				sb.append(this.getCodedEntryIncludeOnly(ref, localName, ns));

				sa.setText(sb.toString());
				allContents.add(sa);
			}
           
			//this loop goes through all introduced codes from ICD9CM
			for (Iterator it = introducedIcd9Codes.iterator(); it.hasNext();) {
				String introCode = (String) it.next();
				
				String introDescription = "";
				if(allDescriptionsICD9CM.containsKey(introCode)){
				    introDescription = (String) allDescriptionsICD9CM
						.get(introCode);
				}
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel("Category:" + introDescription + "(MI" + introCode
						+ ")");
				StringBuffer sb = new StringBuffer();
				sb.append(this.getHeaderBasicData());

				// sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName));

				// sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(introCode));

				// sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(introDescription));

				// sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(""));

				// sb.append("== Presentations ==\n");
				sb.append(this.getCodedEntryPresentations(introDescription));

				sb.append(this.getHeaderProperties());

				// sb.append("== Concept Property ==\n");
				//sb.append(this.getCodedEntryConceptProperty("", "", ns));

				// sb.append("== Comment ==\n");
				sb.append(this.getCodedEntryComment("This code is introduced from ICD9CM for hierarchy building."));

				sb.append(this.getHeaderAssoications());

				// sb.append("== Associations ==\n");


				sb.append(this.getCodedEntryAssociationsForTable22(introDescription,
						introCode, "equivalentClass", ns));
				
				sb.append(this.getHeaderAssociationsGraph());

				// sb.append("== Associations Graph ==\n");
				sb.append(this.getCodedEntryAssociationsGraphForTable22(introDescription,
						introCode, "equivalentClass", "MI"));

				sb.append(this.getDefaultForm());

				sb.append(this.getCodedEntryIncludeOnly(introDescription, introCode, ns));
			
				if(allSuperClasses.containsKey("I"+ introCode)){
					Collection superCodes = (Collection)allSuperClasses.get("I" + introCode);
					for(Iterator it1 = superCodes.iterator(); it1.hasNext();){
						String superCode = (String)it1.next();
						if (superCode.startsWith("I")) {
							String superICode = superCode.substring(1);
							String superDescription = (String) allDescriptionsICD9CM
									.get(superICode);
							//only need sublevel of 001-999.999
							if(superICode.equals("001-999.99") ||
									superICode.equals("V-ICD9CM")){
								sb.append("<noinclude>[[Category:" + "Mayo Table22"
										+ "]]</noinclude>\n");
							}else{
							    sb.append("<noinclude>[[Category:" + superDescription
									+ "(" + "MI" + superICode + ")"
									+ "]]</noinclude>\n");
							}

						} else {
							String superDescription = (String) allDescriptions
									.get(superCode);
							sb.append("<noinclude>[[Category:" + superDescription
									+ "(" + ns + superCode + ")"
									+ "]]</noinclude>\n");
						}
					}
				
				}
				sa.setText(sb.toString());
				allContents.add(sa);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			sb.append("{{LexWiki Coding Scheme|Coding Scheme=" + codingScheme
					+ "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getDefaultForm() {
		return "<noinclude>[[has default form::Form:LexWiki Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "{{LexWiki Basic Data Header}}\n";
	}

	private String getHeaderProperties() {
		return "{{LexWiki Concept Property Header}}\n";
	}

	private String getHeaderAssoications() {
		return "{{LexWiki Association Header}}\n";
	}

	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}

	private String getCodedEntryCode(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append("{{LexWiki Concept Code|Concept Code=" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryCode(String code) {

		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Concept Code|Concept Code=" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryDescription(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		sb.append("{{LexWiki Entity Description|Entity Description="
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryDescription(String description) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Entity Description|Entity Description="
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			sb.append("{{LexWiki Definition|Definition="
					+ entry.getDefinition(ii).getText().getContent() + "}}\n");
		}

		return sb.toString();

	}

	private String getCodedEntryDefinition(String definition) {
		StringBuffer sb = new StringBuffer();

		sb.append("{{LexWiki Definition|Definition=" + definition + "}}\n");

		return sb.toString();

	}

	private String getCodedEntryPresentations(String preferredName) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Preferred Name|Preferred Name=" + preferredName
				+ "}}\n");

		return sb.toString();
	}

	private String getCodedEntryPresentations(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String text = pres.getText().getContent();
			text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			if (isPref) {
				// String attrName = "Has Preferred " + propName;
				sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
						+ "}}\n");
			} else {
				// String fidelity = pres.getDegreeOfFidelity();
				// String attrName = "Has " + fidelity + " "
				// + propName;
				sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
						+ text + "}}\n");
			}
		}

		return sb.toString();

	}

	private String getCodedEntryConceptProperty(String name, String value,
			String ns) {
		StringBuffer sb = new StringBuffer();
		String cpName = ns + "_" + name;
		String cpText = ns + "_" + value;
		sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
				+ "}}\n");

		return sb.toString();
	}

	private String getCodedEntryConceptProperty(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			String cpText = cp.getText().getContent();
			sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
					+ "}}\n");
		}

		return sb.toString();
	}

	private String getCodedEntryComment(String entry) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Comment|Comment=" + entry + "}}\n");

		return sb.toString();
	}

	private String getCodedEntryComment(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|Comment="
					+ entry.getComment(j).getText().getContent() + "}}\n");
		}

		return sb.toString();
	}

	// for mayo table 22 only
	private String getEquivalentICD9Code(ResolvedConceptReference ref,
			String localName, String ns) {
		String ret = null;

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						// System.out.println(assName);
						// System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						// if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							if (assName.equals("equivalentClass")) {
								ret = assConcept.getConceptCode().trim();
								break;
							}

						}

					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	private String getCodedEntryAssociationsForTable22(String entry,
			String code, String assName, String ns) {

		StringBuffer sb = new StringBuffer();

		sb.append("{{LexWiki Association|" + ns + "_" + assName + "|"
				+ "ICD9CM" + " " + entry + "(" + code + ")}}\n");

		return sb.toString();

	}

	// for mayo table 22 only
	private String getCodedEntryAssociationsForTable22(
			ResolvedConceptReference ref, String localName, String ns,
			Map allSuperClasses, Map allDescriptions, Map allDescriptionsICD9CM) {
		StringBuffer sb = new StringBuffer();
		Map highLevelCodeMap = this.getHighLevelCodeMap();
		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);
			String code = ref.getConceptCode();
			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						// System.out.println(assName);
						// System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						// if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							sb.append(this.getHeaderProperties());							
							//make icd9cm code searchable
							sb.append("{{LexWiki Concept Property|"
									+ "ICD9CM_Code"
									+ "|"
									+ "ICD9CM "
									+ assConcept.getConceptCode() + "}}\n");
							sb.append(this.getHeaderAssoications());
							
							if(assConcept.getEntityDescription() != null)
							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assName
									+ "|"
									+ "ICD9CM"
									+ " "
									+ assConcept.getEntityDescription()
											.getContent() + "("
									+ assConcept.getConceptCode() + ")}}\n");

						}

					}
				}
			}

			if (allSuperClasses.containsKey(code)) {
				Collection superCodes = (Collection) allSuperClasses.get(code);
				for (Iterator it = superCodes.iterator(); it.hasNext();) {
					String superCode = (String) it.next();
					if (superCode.startsWith("I")) {
						String superICode = superCode.substring(1);
						String superDescription = (String) allDescriptionsICD9CM
								.get(superICode);
						sb.append("<noinclude>[[Category:" + superDescription
								+ "(" + "MI" + superICode + ")"
								+ "]]</noinclude>\n");

					} else {
						String superDescription = (String) allDescriptions
								.get(superCode);
						sb.append("<noinclude>[[Category:" + superDescription
								+ "(" + ns + superCode + ")"
								+ "]]</noinclude>\n");
					}
				}
				/*
				 * } else if (highLevelClasses.containsKey(code)) { String
				 * superCode = (String) highLevelClasses.get(code); String
				 * superDescription = (String) highLevelCodeMap .get(superCode);
				 * sb.append("<noinclude>[[Category:" + ns + " " +
				 * superDescription + "(" + superCode + ")" + "]]</noinclude>\n");
				 */
			} else {
				sb.append("<noinclude>[[Category:" + localName
						+ " Others]]</noinclude>\n");

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getSuperCodeForIcd9cmCode(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListTarget = refGraph.getSourceOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						// System.out.println(assName);
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
							// System.out.println(assDisplayName);

						}
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							if (assName.equals("CHD")) {
								sb.append(assConcept.getConceptCode());
							}
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		// StringBuffer sb_debug = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println(assName);
						System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						// if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							/*
							 * sb .append("{{LexWiki Association|" + ns + "_" +
							 * assName + "|" + "ICD9CM" + " " + assConcept
							 * .getEntityDescription() .getContent() + "(" +
							 * assConcept.getConceptCode() + ")}}\n");
							 */
							if (assName.equals("CHD")) {
								isaIndex++;
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
							}
						}

					}
				}
				// }
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					// if(altes != null){
					for (int jt = 0; jt < altes.length; jt++) {
						// while(aListTarget != null &&
						// aListTarget.enumerateAssociation().hasMoreElements()){
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof:" + assName);
						System.out.println("targetof:"
								+ ass.getDirectionalName());
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}
						System.out.println("targetof:" + assName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assDisplayName
									+ "|"
									+ "ICD9CM"
									+ " "
									+ assConcept.getEntityDescription()
											.getContent() + "("
									+ assConcept.getConceptCode() + ")}}\n");

							if (assDisplayName.equals("PAR")) {
								isaIndex++;
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
							}
						}
					}
				}
			}

			String code = ref.getConceptCode();

			// different groups of NCI concepts
			if (ns.equals("NCI")) {
				if (code.startsWith("K")) {
					sb.append("<noinclude>[[Category:" + "NCI Kind"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("A")) {
					sb.append("<noinclude>[[Category:" + "NCI MetaA"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("P")) {
					sb.append("<noinclude>[[Category:" + "NCI Property"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("R")) {
					sb.append("<noinclude>[[Category:" + "NCI Relation"
							+ "]]</noinclude>\n");

				} else if (isaIndex == 0) {
					sb.append("<noinclude>[[Category:" + localName
							+ "]]</noinclude>\n");
				}
			} else {
				if (isaIndex == 0) {
					sb.append("<noinclude>[[Category:" + localName
							+ "]]</noinclude>\n");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsGraphForTable22(String entry,
			String code, String assName, String ns) {

		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");
		String reEntry = entry.replaceAll(" ", "_");

		String thisConcept = "Category:" + reEntry + "(" + "MI"
				+ code + ")";

		String thisAssEntityDescription = "ICD9CM" + "_"
				+ reEntry + "(" + code + ")";

		sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept
				+ "; } " + "-- " + assName + " --> {link:Relation:" + ns + "_"
				+ assName + "; start: front, 0; } " + " [ Category:"
				+ thisAssEntityDescription + " ] "
				+ "{ fill: 3; link: Category:" + thisAssEntityDescription
				+ "; }" + "\n");

		sb.append("</graph></noinclude>\n");

		return sb.toString();

	}

	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + thisConceptName + "(" + ns
				+ ref.getConceptCode() + ")";

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						// if (!assName.equals("hasSubtype")) {

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
                 
							String thisAssEntityDescription = "ICD9CM"
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");

							sb.append("[ " + thisConcept + "] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + ass.getDirectionalName()
									+ " --> {link:Relation:" + ns + "_"
									+ assName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 3; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");

						}

					}
				}
				// }
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = "ICD9CM"
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");

							sb.append("[ " + thisConcept + "] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assDisplayName
									+ " --> {link:Relation:" + ns + "_"
									+ assDisplayName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");

						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	
	private String getCodedEntryIncludeOnly(String entry,
			String code, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = entry.replaceAll(" ", "_");

		String thisConcept = "Category:" + thisConceptName + "(" + ns
				+ code + ")";

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}
	
	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + " " + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}

	
}
