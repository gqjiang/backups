package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;


public class GenerateContentForFrameModel {
	
	private StringBuffer result;
	private KnowledgeBase kb;
	private Cls selectedCls;
	
	
	//todo: index should indicate wether a template needed
	public GenerateContentForFrameModel(int index,
			                      Cls selectedCls,
			                      KnowledgeBase kb){
		this.kb = kb;
		this.selectedCls = selectedCls;
		this.generateContent();

	}
	
	public String getContent(){
		return result.toString();
	}
	
	private void generateContent(){
		result = new StringBuffer();
		
		result.append("== Name ==\n");
		result.append(" * [[Name:= " + selectedCls.getBrowserText() + "]]\n");
		
		result.append("== Role ==\n");
		result.append(this.getAbstractOrConcrete());
		
		result.append("== Description ==\n");
		result.append(this.getStringFromDocumentation());
		
		result.append("== Template Slots ==\n");
		result.append(this.getTemplateSlots());
		
		result.append("== Has Instances ==\n");
		result.append(this.getStringInstances());
		
		result.append(this.getSuperClsesNames());
		
	}
	
	private String getAbstractOrConcrete(){
		StringBuffer sb = new StringBuffer();
		if(selectedCls.isAbstract()){
			sb.append(" * [[Role:=Abstract]]\n");
		}else{
			sb.append(" * [[Role:=Concrete]]\n");
		}
		
		return sb.toString();
	}
	
	private String getStringFromDocumentation(){
		StringBuffer sb = new StringBuffer();
		Collection docs = selectedCls.getDocumentation();
		Iterator it = docs.iterator();
		while(it.hasNext()){
			String doc = (String)it.next();
			sb.append(" * [[Description:=" + doc + "]]\n");
		}
		
		return sb.toString();
	}
	
	private String getTemplateSlots(){
		StringBuffer sb = new StringBuffer();
		Collection templateSlots = selectedCls.getTemplateSlots();
		for(Iterator it = templateSlots.iterator(); it.hasNext();){
			Slot slot = (Slot)it.next();
			ValueType vt = slot.getValueType();
			if(vt.equals(ValueType.INSTANCE) ||
					vt.equals(ValueType.CLS)){
	            sb.append("* [[Relation:" + slot.getBrowserText() + "]] ");
	            if(slot.getAllowsMultipleValues()){
	            	sb.append("Cardinality: Multiple " );
	            }else{
	            	sb.append("Cardinality: Single ");
	            }
				sb.append("Type: " + vt.toString() + " ");
				Collection allowedClses = slot.getAllowedClses();
				for(Iterator it1 = allowedClses.iterator(); it1.hasNext();){
					Cls allowedCls = (Cls) it1.next();
					sb.append("[[:Category:" + 
							allowedCls.getBrowserText() + "]] ");
				}
			}else{
	            sb.append("* [[Attribute:" + slot.getBrowserText() + "]] ");
	            if(slot.getAllowsMultipleValues()){
	            	sb.append("Cardinality: Multiple " );
	            }else{
	            	sb.append("Cardinality: Single ");
	            }
				sb.append("Type: " + vt.toString() + " ");
				
			}
			sb.append("\n");
			
		}
		
		return sb.toString();
	}
	
	//todo: get contents of each instance into an article
	private String getStringInstances(){
		StringBuffer sb = new StringBuffer();
		Collection instances = selectedCls.getInstances();
		for(Iterator it = instances.iterator(); it.hasNext();){
			Instance ins = (Instance)it.next();
			sb.append("* [[" + ins.getBrowserText() + "]]\n");
		}
		
		return sb.toString();
	}
	
	private String getSuperClsesNames(){
		StringBuffer sb = new StringBuffer();
		Collection superClses = selectedCls.getDirectSuperclasses();
		Iterator it = superClses.iterator();
		while(it.hasNext()){
			Cls superCls = (Cls)it.next();
			sb.append(" [[Category: " + superCls.getBrowserText() + "]]\n");
		}
		return sb.toString();
	}
	
	
	//todo
	private String getStringFromConstraints(){
		StringBuffer sb = new StringBuffer();
		
		return sb.toString();
	}
}