package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.apache.log4j.Logger;


import edu.mayo.bmi.guoqian.claml.ClaML;
import edu.mayo.bmi.guoqian.claml.ClassKind;
import edu.mayo.bmi.guoqian.claml.ClassKinds;
import edu.mayo.bmi.guoqian.claml.Identifier;
import edu.mayo.bmi.guoqian.claml.Label;
import edu.mayo.bmi.guoqian.claml.Meta;
import edu.mayo.bmi.guoqian.claml.ObjectFactory;
import edu.mayo.bmi.guoqian.claml.Rubric;
import edu.mayo.bmi.guoqian.claml.RubricKind;
import edu.mayo.bmi.guoqian.claml.RubricKinds;
import edu.mayo.bmi.guoqian.claml.SubClass;
import edu.mayo.bmi.guoqian.claml.SuperClass;
import edu.mayo.bmi.guoqian.claml.Title;
import edu.mayo.bmi.guoqian.claml.UsageKind;
import edu.mayo.bmi.guoqian.claml.UsageKinds;

import java.util.*;
import java.io.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;



//first implementation of new lexwiki templates
public class GenerateClaMLXMLForICD {

    private int rubricIndex = 1000000;
    
    private String icdFileName = "C:\\Temp\\icd10cm\\icd10cm.txt";
    private String icdNoteFileName = "C:\\Temp\\icd10cm\\icd10cm_notes.txt";

    private Map mapSuperClasses = new HashMap();
    private Collection colSupers = new ArrayList();
    private Map mapLabels = new HashMap();
    private Map mapSubClasses = new HashMap();
    private Map mapInclusions = new HashMap();
    private Map mapNotes = new HashMap();
    private Map mapExclusions1 = new HashMap();
    private Map mapExclusions2 = new HashMap();
    private Collection colChapters = new ArrayList();
    
	public GenerateClaMLXMLForICD() {

	}
	
	public void processingClaMLXML(){
		
		System.out.println("starting..." + new Date());		
		this.processingSuperClasses();
		////System.out.println("superclasses:" + mapSuperClasses.size());
		System.out.println("chapters:" + colChapters.size());
		this.processingSubClasses();
		System.out.println("subclasses:" + mapSubClasses.keySet().size());
		
		this.processingInclusions();
		System.out.println("inclusions:" + mapInclusions.keySet().size());
		
		this.processingExclusions1();
		System.out.println("exclusions1:" + mapExclusions1.keySet().size());
		
		this.processingExclusions2();
		System.out.println("exclusions2:" + mapExclusions2.keySet().size());
		
		this.processingNotes();
		System.out.println("notes:" + mapNotes.keySet().size());		
		
		String output = "C:\\Temp\\icd10cm\\claml01\\icd10cm_claml.xml";	
		try {
			
			Collection colDuplicates = new ArrayList();
			
			BufferedReader br = new BufferedReader(new FileReader(icdFileName));
			
			FileOutputStream fos = new FileOutputStream(output);
			ObjectFactory factory = new ObjectFactory();
			
            ClaML claml = factory.createClaML();
            claml.setVersion("2.0.0");
            
            Title title = factory.createTitle();
            title.setDate("2009-06-28");
            title.setName("ICD-10-CM");
            title.setVersion("July 2007");
            
            claml.setTitle(title);
            
            Identifier identifier = factory.createIdentifier();
            identifier.setAuthority("WHO");
            identifier.setUid("id-to-be-added-later");
            claml.getIdentifier().add(identifier);
            
            Meta meta = factory.createMeta();
            meta.setName("lang");
            meta.setValue("en");
            claml.getMeta().add(meta);
            
            ClassKinds clsKinds = factory.createClassKinds();
			ClassKind cKind1 = factory.createClassKind();
			cKind1.setName("chapter");
			clsKinds.getClassKind().add(cKind1);
			ClassKind cKind2 = factory.createClassKind();
			cKind2.setName("block");
			clsKinds.getClassKind().add(cKind2);
			ClassKind cKind3 = factory.createClassKind();
			cKind3.setName("category");
			clsKinds.getClassKind().add(cKind3);
            claml.setClassKinds(clsKinds);
            
            UsageKinds useKinds = factory.createUsageKinds();
            UsageKind useKind = factory.createUsageKind();
            useKind.setMark("!");
            useKind.setName("optional");
            useKinds.getUsageKind().add(useKind);
            claml.setUsageKinds(useKinds);
            
            RubricKinds rubKinds = factory.createRubricKinds();
            RubricKind rKind1 = factory.createRubricKind();
            rKind1.setInherited("false");
            rKind1.setName("preferred");
            rubKinds.getRubricKind().add(rKind1);
            RubricKind rKind2 = factory.createRubricKind();
            rKind2.setInherited("false");
            rKind2.setName("inclusion");
            rubKinds.getRubricKind().add(rKind2);
            RubricKind rKind3 = factory.createRubricKind();
            rKind3.setInherited("false");
            rKind3.setName("exclusion1");
            rubKinds.getRubricKind().add(rKind3);
            RubricKind rKind4 = factory.createRubricKind();
            rKind4.setInherited("false");
            rKind4.setName("exclusion2");
            rubKinds.getRubricKind().add(rKind4);
            RubricKind rKind5 = factory.createRubricKind();
            rKind5.setInherited("false");
            rKind5.setName("note");
            rubKinds.getRubricKind().add(rKind5);
            claml.setRubricKinds(rubKinds);
            
			String line = br.readLine();
			line = br.readLine();
			int index = 0;
			while(line != null){
				String[] items = line.split("\\t");            
            
            //for(Iterator it1 = mapLabels.keySet().iterator(); it1.hasNext();){
            	//String code = (String) it1.next();
				String code = items[0].trim();
				
				if(code.length()  > 0){
				
				if(code.indexOf("\"") >= 0){
				   code = code.replaceAll("\"", "").trim();		
				}
				
				if(!colDuplicates.contains(code)){
				
					 colDuplicates.add(code);
            	edu.mayo.bmi.guoqian.claml.Class cls = factory.createClass();
            	cls.setCode(code);
        		if(colChapters.contains(code)){
        			ClassKind cKind = factory.createClassKind();
        			cKind.setName("chapter");
        			cls.setKind(cKind);
        			clsKinds.getClassKind().add(cKind);

        		}else if(code.indexOf("-") >= 0){
        			ClassKind cKind = factory.createClassKind();
        			cKind.setName("block");
        			cls.setKind(cKind);
        		}else{
        			ClassKind cKind = factory.createClassKind();
        			cKind.setName("category");
        			cls.setKind(cKind);
        		} 
        		
        		String superclassCode = (String) items[3].trim();
        		if(superclassCode == null || superclassCode.length() < 1){
        			superclassCode = items[0].trim().substring(0, 5);
        			System.out.println(superclassCode + "|" + items[3].trim());
        		}
        		if(superclassCode.indexOf("\"") >= 0){
        			superclassCode = superclassCode.replaceAll("\"", "").trim();
        		}
        		SuperClass superclass = factory.createSuperClass();
        		superclass.setCode(superclassCode);
        		cls.getSuperClass().add(superclass);
        		
        		//for (Iterator it = colSupers.iterator(); it.hasNext();){
        		//	String item = (String) it.next();
        		//	String[] pair = item.split("\\|");
        		//	if(code.equals(pair[0])){
                //		SuperClass superclass = factory.createSuperClass();
                //		superclass.setCode(pair[1]);
                //		break;       				
        		//	}
        		//}
        		
        		Collection colSubclasses = (Collection) mapSubClasses.get(code);
        		if(colSubclasses != null){
        		for(Iterator it2 = colSubclasses.iterator(); it2.hasNext();){
        			String subclassCode = (String) it2.next();
        			//System.out.println(code + "|" + subclassCode);
        			SubClass subclass = factory.createSubClass();
        			subclass.setCode(subclassCode);
        			cls.getSubClass().add(subclass);
        		}
        		}
        		
        		
            	String label = (String) this.cleanupString(items[5]);
            	Rubric rubricLabel = factory.createRubric();
        		rubricLabel.setId("id-to-be-added-later-" + rubricIndex++);
        		ClassKind cKind = factory.createClassKind();
        		cKind.setName("preferred");
        		rubricLabel.setKind(cKind);

        		Label clsLabel = factory.createLabel();
        		clsLabel.setLang("en");
        		clsLabel.setSpace("default");
        		clsLabel.getContent().add(label);
        		rubricLabel.getLabel().add(clsLabel);
        		cls.getRubric().add(rubricLabel);
        		
        		Collection colInclusions = (Collection) mapInclusions.get(code);
        		if(colInclusions != null){
        		for(Iterator it3 = colInclusions.iterator(); it3.hasNext();){
        			String inclusionLabel = (String) it3.next();
    				Rubric rubricInclusion = factory.createRubric();
    				rubricInclusion.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindInclusion = factory.createClassKind();
    				cKindInclusion.setName("inclusion");
    				rubricInclusion.setKind(cKindInclusion);
    				Label labelInclusion = factory.createLabel();
    				labelInclusion.setLang("en");
    				labelInclusion.setSpace("default");
    				labelInclusion.getContent().add(inclusionLabel);
    				rubricInclusion.getLabel().add(labelInclusion);
                    cls.getRubric().add(rubricInclusion);

        		}
        		}
        		
        		Collection colExclusions1 = (Collection)mapExclusions1.get(code);
        		
        		if(colExclusions1 != null){
        		for(Iterator it4 = colExclusions1.iterator(); it4.hasNext();){
        			String exclusion1Label = (String) it4.next();
    				Rubric rubricExclusion1 = factory.createRubric();
    				rubricExclusion1.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindExclusion1 = factory.createClassKind();
    				cKindExclusion1.setName("exclusion1");
    				rubricExclusion1.setKind(cKindExclusion1);
    				Label labelExclusion1 = factory.createLabel();
    				labelExclusion1.setLang("en");
    				labelExclusion1.setSpace("default");

    				if(exclusion1Label.lastIndexOf("(") >=0){
    					int lindex = exclusion1Label.lastIndexOf("(");
    					String ecode = exclusion1Label.substring(lindex+1, exclusion1Label.length()-1);
    					
    					if(isCode(ecode)){
    						if(ecode.indexOf(",") >= 0 ||
    								ecode.endsWith("-") ||
    								ecode.length() > 8 ||
    								ecode.indexOf(" ") >= 0){
    							labelExclusion1.getContent().add(exclusion1Label);
    							rubricExclusion1.getLabel().add(labelExclusion1);
    							cls.getRubric().add(rubricExclusion1);    						
    						}else{
    	    					String etext = exclusion1Label.substring(0, lindex-1);
    	    					ecode = ecode.replaceAll("\\)", "");
    	    					edu.mayo.bmi.guoqian.claml.Reference reference = factory.createReference();
    	    					reference.setClazz("in brackets");
    	    					reference.setContent(ecode);
    	    					
    	    					//if(ecode.endsWith("-")){
    	    					//	ecode = ecode.substring(0, ecode.length()-1);
    	    					//}
    	    					reference.setCode(ecode);
    	    					labelExclusion1.getContent().add(etext);
    	    					labelExclusion1.getContent().add(reference);
    	    					rubricExclusion1.getLabel().add(labelExclusion1);
    	    					cls.getRubric().add(rubricExclusion1);									
   							
    						}
    					}else{
    							labelExclusion1.getContent().add(exclusion1Label);
    							rubricExclusion1.getLabel().add(labelExclusion1);
    							cls.getRubric().add(rubricExclusion1);    						
    						
    					}
    					
    				}else{    				
    				
    					labelExclusion1.getContent().add(exclusion1Label);
    					rubricExclusion1.getLabel().add(labelExclusion1);
    					cls.getRubric().add(rubricExclusion1);
    				}
        			
        		}
        		}
        		
        		Collection colExclusions2 = (Collection)mapExclusions2.get(code);
        		
        		if(colExclusions2 != null){
        		for(Iterator it5 = colExclusions2.iterator(); it5.hasNext();){
        			String exclusion2Label = (String) it5.next();
    				Rubric rubricExclusion2 = factory.createRubric();
    				rubricExclusion2.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindExclusion2 = factory.createClassKind();
    				cKindExclusion2.setName("exclusion2");
    				rubricExclusion2.setKind(cKindExclusion2);
    				Label labelExclusion2 = factory.createLabel();
    				labelExclusion2.setLang("en");
    				labelExclusion2.setSpace("default");

    				if(exclusion2Label.lastIndexOf("(") >=0){
    					int lindex = exclusion2Label.lastIndexOf("(");
    					String ecode = exclusion2Label.substring(lindex+1, exclusion2Label.length()-1);
    					if(isCode(ecode)){
    						if(ecode.indexOf(",") >= 0  ||
    								ecode.endsWith("-") ||
    								ecode.length() > 8  ||
    								ecode.trim().indexOf(" ") >= 0){
    	    					labelExclusion2.getContent().add(exclusion2Label);
    	    					rubricExclusion2.getLabel().add(labelExclusion2);
    	    					cls.getRubric().add(rubricExclusion2);
    							
    						}else{
    	    					String etext = exclusion2Label.substring(0, lindex-1);
    	    					ecode = ecode.replaceAll("\\)", "");

    	    					edu.mayo.bmi.guoqian.claml.Reference reference = factory.createReference();
    	    					reference.setClazz("in brackets");
    	    					reference.setContent(ecode);
    	    					
    	    					//if(ecode.endsWith("-")){
    	    					//	ecode = ecode.substring(0, ecode.length()-1);
    	    					//}
    	    					reference.setCode(ecode);

    	    					labelExclusion2.getContent().add(etext);
    	    					labelExclusion2.getContent().add(reference);
    	    					rubricExclusion2.getLabel().add(labelExclusion2);
    	    					cls.getRubric().add(rubricExclusion2);	    							
    						}
    					}else{
        					labelExclusion2.getContent().add(exclusion2Label);
        					rubricExclusion2.getLabel().add(labelExclusion2);
        					cls.getRubric().add(rubricExclusion2);
    						
    					}
    					
								
    				}else{    				
    					labelExclusion2.getContent().add(exclusion2Label);
    					rubricExclusion2.getLabel().add(labelExclusion2);
    					cls.getRubric().add(rubricExclusion2);
    				}
        			
        		} 
        		}
/*
        		Collection colNotes = (Collection)mapNotes.get(code);
        		if(colNotes != null){
        		for(Iterator it6 = colNotes.iterator(); it6.hasNext();){
        			String noteLabel = (String) it6.next();
    				Rubric rubricNote = factory.createRubric();
    				rubricNote.setId("id-to-be-added-later-" + rubricIndex++);
    				ClassKind cKindNote = factory.createClassKind();
    				cKindNote.setName("note");
    				rubricNote.setKind(cKindNote);
    				Label labelNote = factory.createLabel();
    				labelNote.setLang("en");
    				labelNote.setSpace("default");
    				labelNote.getContent().add(noteLabel);
    				rubricNote.getLabel().add(labelNote);
                    cls.getRubric().add(rubricNote);
        			
        		}
        		
        		}
*/        		
        		
        		
        		claml.getClazz().add(cls);
				}
				}
        		
        		line = br.readLine();
        		
            }
            
			JAXBContext jaxbContext = JAXBContext.newInstance("edu.mayo.bmi.guoqian.claml");
			Marshaller marshaller = jaxbContext.createMarshaller();
	
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal( claml, fos );
			System.out.println("ending..." + new Date());		
           
            
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	private boolean isCode(String code){
		boolean ret = false;
		if (code.indexOf("0") >= 0 ||
				code.indexOf("1") >= 0 ||
				code.indexOf("2") >= 0 ||
				code.indexOf("3") >= 0 ||
				code.indexOf("4") >= 0 ||
				code.indexOf("5") >= 0 ||
				code.indexOf("6") >= 0 ||
				code.indexOf("7") >= 0 ||
				code.indexOf("8") >= 0 ||
				code.indexOf("9") >= 0){
			ret = true;
		}
		
		
		return ret;
	}
	
	private void processingSuperClasses(){
		BufferedReader br = null;
		//Collection colSuperClasses = new ArrayList();
		try{
			br = new BufferedReader(new FileReader(icdFileName));
			String line = br.readLine();
			line = br.readLine();
			int index = 0;
			while(line != null){
				String[] items = line.split("\\t");
				
				//superclasses
				//if(items[0] != null){
                    
					//mapSuperClasses.put(new String(items[0].trim()), new String(items[3].trim()));
					//colSupers.add(items[0] + "|" + items[3]);
					//index++;
					//System.out.println(index + "|" + items[0] + "|" + mapSuperClasses.size());

				//}
				
				//labels
				//if(items[0] != null && items[5] != null)
					//mapLabels.put(items[0].trim(), this.cleanupString(items[5]));
				
				
				//chapter code
				if(items[1].trim().equals("MH")){
					if(!colChapters.contains(items[0].trim())){
						colChapters.add(items[0].trim());
					}
				}
				line = br.readLine();
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	private String cleanupString(String label){
		String ret = label;
		if(label.startsWith("\"")){ 
			label = label.substring(1);
			label = label.substring(0, label.length()-1);
			ret = label.trim();
	    }else{
	    	ret = label.trim();
	    }
		
		return ret;
	}
	
	private void processingSubClasses(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdFileName));
			String line = br.readLine();
			line = br.readLine();
			while(line != null){
				String[] items = line.split("\\t");

				
				if(items[3] != null && items[0] != null && items[0].trim().length() > 1){
					
					String subcode = items[0].trim();
					if(subcode.indexOf("\"") >= 0){
						subcode = subcode.replaceAll("\"", "").trim();
					}
					String supercode = items[3].trim();
					if(supercode.indexOf("\"") >= 0){
						supercode = supercode.replaceAll("\"", "");
					}
					
					if(!mapSubClasses.containsKey(supercode)){
						Collection colSubs = new ArrayList();
						if(!colSubs.contains(subcode)){						
							colSubs.add(subcode);
						}
						mapSubClasses.put(supercode, colSubs);
					}else{
						Collection colSubs = (Collection) mapSubClasses.get(supercode);
					    if(!colSubs.contains(subcode))
					    	colSubs.add(subcode);
					    mapSubClasses.put(supercode, colSubs);
					}
				}

				line = br.readLine();
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	private void processingInclusions(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
					if(items[2].equals("1")){
                        if(items[3].startsWith("Includes")){
                	     
                	     this.addInclusions(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0] + "|" + items[2] + "|" + this.removeHeader(items[3]));
                	     isInclusion = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  		if (items[3].startsWith("Excludes1") ||
	                		   items[3].startsWith("Excludes2") ||
								items[3].startsWith("The following") ||
	                		   items[3].startsWith("Notes")){
                  			
                  		}else{
                   	     
                   	     this.addInclusions(items[0].trim(), this.removeHeader(items[3]));
                   	     //System.out.println(items[0] + "|" + items[2] + "|" + this.removeHeader(items[3]));
                   	     isInclusion = true;    
                   	     previousCode = items[0];                  			
                  		}
                      }
				}else{
					 if(items[0].equals(previousCode)){
						if(items[3].indexOf("Excludes1") >= 0 ||
		                		   items[3].indexOf("Excludes2") >= 0 ||
									items[3].startsWith("The following") ||
		                		   items[3].indexOf("Notes") >= 0){
							isInclusion = false;
						}
						if(isInclusion){
							this.addInclusions(items[0].trim(), this.removeHeader(items[3]));
	                	    // System.out.println(items[0] + "2|" + items[2] + "|" + this.removeHeader(items[3]));
					 }
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 100) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}

	private void processingExclusions1(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
                       if(items[3].startsWith("Excludes1")){
                	     
                	     this.addExclusions1(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0] + "|" + items[2] + "|" + items[3]);
                	     isExcludes1 = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  
					 if(items[0].equals(previousCode)){
						if(isExcludes1){
							
							if(items[3].startsWith("Excludes2") ||
									items[3].startsWith("Notes") ||
									items[3].startsWith("The following") ||									
									items[3].length() < 1){
								isExcludes1 = false;
							}else{
							
							this.addExclusions1(items[0].trim(), this.removeHeader(items[3]));
	                	     //System.out.println(items[0] + "2|" + items[2] + "|" + this.removeHeader(items[3]));
							}
						}
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 100) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}	

	private void processingExclusions2(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
                       if(items[3].startsWith("Excludes2")){
                	     
                	     this.addExclusions2(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0] + "|" + items[2] + "|" + items[3]);
                	     isExcludes2 = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  
					 if(items[0].equals(previousCode)){
						if(isExcludes2){
							
							if(items[3].startsWith("Excludes1") ||
									items[3].startsWith("Notes") ||
									items[3].startsWith("The following") ||
									items[3].length() < 1){
								isExcludes2 = false;
							}else{
							
							this.addExclusions2(items[0].trim(), this.removeHeader(items[3]));
	                	     //System.out.println(items[0] + "2|" + items[2] + "|" + this.removeHeader(items[3]));
							}
						}
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 1000) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}	

	private void processingNotes(){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(icdNoteFileName));
			String line = br.readLine();
			line = br.readLine();
			boolean isInclusion = false;
			boolean isExcludes1 = false;
			boolean isExcludes2 = false;
			boolean isNote = false;
			int index = 0;
			String previousCode = "";
			while(line != null){
				String[] items = line.split("\\t");
				if(items[0] != null){
                       if(items[3].startsWith("Note") ||
                    		   items[3].startsWith("The following")){
                	     
                	     this.addNotes(items[0].trim(), this.removeHeader(items[3]));
                	     //System.out.println(items[0].trim() + "|" + items[2] + "|" + items[3]);
                	     isNote = true;    
                	     previousCode = items[0];
                      }else{
                    	  
                  
					 if(items[0].equals(previousCode)){
						if(isNote){
							
							if(items[3].startsWith("Excludes1") ||
									items[3].startsWith("Excludes2") ||
									items[3].length() < 1){
								isNote = false;
							}else{
							
							this.addNotes(items[0].trim(), this.removeHeader(items[3]));
	                	     //System.out.println(items[0].trim() + "2|" + items[2] + "|" + this.removeHeader(items[3]));
							}
						}
					 }
					
                	   
				}
				}

				line = br.readLine();
				index++;
				//if(index > 1000) break;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}		
	
	private String removeHeader(String note){
		String ret = note;
		if(note.startsWith("Includes:")){
			ret = note.substring(10);
		}else if(note.startsWith("Excludes1:")){
			ret = note.substring(11);
		}else if(note.startsWith("Excludes2:")){
			ret = note.substring(11);
		}else if(note.startsWith("Note:")){
			ret = note.substring(6);
		}
		
		return ret;
	}
	
	private void addInclusions(String code, String inclusion){
        if(!mapInclusions.containsKey(code)){
     	   Collection colInclusions = new ArrayList();
     	   if(!colInclusions.contains(inclusion))
     		   colInclusions.add(inclusion);
     	   mapInclusions.put(code, colInclusions);
        }else{
        	Collection colInclusions = (Collection) mapInclusions.get(code);
        	if(!colInclusions.contains(inclusion))
        		colInclusions.add(inclusion);
        	mapInclusions.put(code, colInclusions);
        }
	}

	private void addExclusions1(String code, String exclusion){
        if(!mapExclusions1.containsKey(code)){
     	   Collection colExclusions = new ArrayList();
     	   if(!colExclusions.contains(exclusion))
     		  colExclusions.add(exclusion);
     	   mapExclusions1.put(code, colExclusions);
        }else{
        	Collection colExclusions = (Collection) mapExclusions1.get(code);
        	if(!colExclusions.contains(exclusion))
        		colExclusions.add(exclusion);
        	mapExclusions1.put(code, colExclusions);
        }
	}	

	private void addExclusions2(String code, String exclusion){
        if(!mapExclusions2.containsKey(code)){
     	   Collection colExclusions = new ArrayList();
     	   if(!colExclusions.contains(exclusion))
     		   colExclusions.add(exclusion);
     	   mapExclusions2.put(code, colExclusions);
        }else{
        	Collection colExclusions = (Collection) mapExclusions2.get(code);
        	if(!colExclusions.contains(exclusion))
        		colExclusions.add(exclusion);
        	mapExclusions2.put(code, colExclusions);
        }
	}		

	private void addNotes(String code, String note){
        if(!mapNotes.containsKey(code)){
     	   Collection colNotes = new ArrayList();
     	   if(!colNotes.contains(note))
     	     colNotes.add(note);
     	   mapNotes.put(code, colNotes);
        }else{
        	Collection colNotes = (Collection) mapNotes.get(code);
        	if(!colNotes.contains(note))
        		colNotes.add(note);
        	mapNotes.put(code, colNotes);
        }
	}			
	
	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public void getClaMLXMLForConceptCode(String conceptCode,
			String localName, String ns) {
		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];
		String output = "icd10cm_claml_"  + code_ + ".xml";

		System.out.println(code_ + "|" + description_);
		try {

			FileOutputStream fos = new FileOutputStream(output);
			
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);
			
			ObjectFactory factory = new ObjectFactory();
			
            ClaML claml = factory.createClaML();
            
            Title title = factory.createTitle();
            title.setDate("2009-06-25");
            title.setName("ICD-10-CM");
            title.setVersion("July 2007");
            
            claml.setTitle(title);
            
			
			
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
                 
                    edu.mayo.bmi.guoqian.claml.Class clsClass = this.getClassClass(ref, localName, ns);
                    claml.getClazz().add(clsClass);

				}
			}
			
			JAXBContext jaxbContext = JAXBContext.newInstance("edu.mayo.bmi.guoqian.claml");
			Marshaller marshaller = jaxbContext.createMarshaller();
	
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal( claml, fos );

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void getClaMLXMLForBatchExport(String localName,
			String ns) {

		Collection allContents = new ArrayList();
		String output = "icd10cm_claml.xml";
		
		
		try {
			
			FileOutputStream fos = new FileOutputStream(output);
			ObjectFactory factory = new ObjectFactory();
			
            ClaML claml = factory.createClaML();
            
            Title title = factory.createTitle();
            title.setDate("2009-06-25");
            title.setName("ICD-10-CM");
            title.setVersion("July 2007");
            
            claml.setTitle(title);

			
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			
			int index = 0;
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				//String code = entry.getConceptCode();

				//String description = entry.getEntityDescription().getContent();
                edu.mayo.bmi.guoqian.claml.Class clsClass = this.getClassClass(ref, localName, ns);
                claml.getClazz().add(clsClass);

                index++;
                
                if(index >100) break;
			}

			JAXBContext jaxbContext = JAXBContext.newInstance("edu.mayo.bmi.guoqian.claml");
			Marshaller marshaller = jaxbContext.createMarshaller();
	
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal( claml, fos );

		
		} catch (Exception e) {
			e.printStackTrace();
		}


	}	



	//for claml
	private edu.mayo.bmi.guoqian.claml.Class getClassClass(
			ResolvedConceptReference ref,
			String localName, String ns) {
        
		CodedEntry entry = ref.getReferencedEntry();
		//StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
        String description = entry.getEntityDescription().getContent();
		
		ObjectFactory factory = new ObjectFactory();
		
		edu.mayo.bmi.guoqian.claml.Class classClass = factory.createClass();
		classClass.setCode(code);
		if(description.indexOf("CHAPTER") >= 0){
			ClassKind cKind = factory.createClassKind();
			cKind.setName("chapter");
			classClass.setKind(cKind);

		}else if(code.indexOf("-") >= 0){
			ClassKind cKind = factory.createClassKind();
			cKind.setName("block");
			classClass.setKind(cKind);
		}else{
			ClassKind cKind = factory.createClassKind();
			cKind.setName("category");
			classClass.setKind(cKind);
		}
		
		Collection subclasses = this.getClassSubclasses(ref, localName, ns);
		for(Iterator it1 = subclasses.iterator(); it1.hasNext();){
		    SubClass subclass = (SubClass) it1.next();
		    classClass.getSubClass().add(subclass);
		}
		
		Collection superclasses = this.getClassSuperclasses(ref, localName, ns);
		for(Iterator it2 = superclasses.iterator(); it2.hasNext();){
		    SuperClass superclass = (SuperClass) it2.next();
		    classClass.getSuperClass().add(superclass);
		}
		
		Rubric rubricLabel = this.getClassRubricLabel(entry);
		classClass.getRubric().add(rubricLabel);
		
		Collection rubricInclusionExclusion = this.getClassRubricInclusionExclusion(entry, ns);
		for(Iterator it3 = rubricInclusionExclusion.iterator(); it3.hasNext();){
			Rubric rubric = (Rubric) it3.next();
			classClass.getRubric().add(rubric);
		}
		
		return classClass;
	}
		
	
	
	//for claml
	private String getClassCode(CodedEntry entry) {

		//StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		//sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		return code;
	}
	
	

    
	//for claml
	private Rubric getClassRubricLabel(CodedEntry entry) {
		ObjectFactory factory = new ObjectFactory();
		Rubric rubric = factory.createRubric();
		rubric.setId("id-to-be-added-later" + rubricIndex++);
		ClassKind cKind = factory.createClassKind();
		cKind.setName("preferred");
		rubric.setKind(cKind);

		Label label = factory.createLabel();
		label.setLang("en");
		label.setSpace("default");
		label.getContent().add(entry.getEntityDescription().getContent());
		rubric.getLabel().add(label);

		return rubric;

	}	
	
	
	// claml
	private Collection getClassRubricInclusionExclusion(CodedEntry entry, String ns) {
		Collection rubrics = new ArrayList();
		int pIndex = entry.getConceptPropertyCount();
		for (int ip = 0; ip < pIndex; ip++) {
			ConceptProperty cp = entry.getConceptProperty(ip);
			String propName = cp.getProperty();
			String text = cp.getText().getContent();
			if(propName.indexOf("Inclu") >= 0){
				ObjectFactory factory = new ObjectFactory();
				Rubric rubric = factory.createRubric();
				rubric.setId("id-to-be-added-later" + rubricIndex++);
				ClassKind cKind = factory.createClassKind();
				cKind.setName("inclusion");
				rubric.setKind(cKind);
				Label label = factory.createLabel();
				label.setLang("en");
				label.setSpace("default");
				label.getContent().add(text);
				rubric.getLabel().add(label);
				rubrics.add(rubric);
				
			}else if (propName.indexOf("Excludes") >= 0){
				ObjectFactory factory = new ObjectFactory();
				Rubric rubric = factory.createRubric();
				rubric.setId("id-to-be-added-later-" + propName + "-" + rubricIndex++ );
				ClassKind cKind = factory.createClassKind();
				cKind.setName("exclusion");
				rubric.setKind(cKind);
				Label label = factory.createLabel();
				label.setLang("en");
				label.setSpace("default");

				if(text.lastIndexOf("(") >=0){
					int lindex = text.lastIndexOf("(");
					String ecode = text.substring(lindex+1, text.length()-1);
					String etext = text.substring(0, lindex-1);
					edu.mayo.bmi.guoqian.claml.Reference reference = factory.createReference();
					reference.setClazz("in brackets");
					reference.setCode(ecode);
					reference.setContent(ecode);
					label.getContent().add(etext);
					label.getContent().add(reference);
					rubric.getLabel().add(label);
					rubrics.add(rubric);									
				}else{
					label.getContent().add(text);
					rubric.getLabel().add(label);
					rubrics.add(rubric);						
				}
				
			}

		}

		return rubrics;

	}	

	private boolean isLeafNode(ResolvedConceptReference ref, String localName,
			String ns) {
		boolean ret = false;

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("isleafnode:" + assName);
						if (assName.equals("CHD")) {
							ret = true;
						}
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}



	//claml
	private Collection getClassSubclasses(ResolvedConceptReference ref,
			String localName, String ns) {
		Collection subclasses = new ArrayList();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						//if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}
							System.out.println("sourceOf-assDirecName:"
									+ assDirectionalName);

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();
                                if(assDirectionalName.equals("CHD")){
    								System.out.println("source of sub:" + assConceptCode);
    								 
                                	ObjectFactory factory = new ObjectFactory();
                                	SubClass subclass = factory.createSubClass();
                                	subclass.setCode(assConceptCode);
                                	subclasses.add(subclass);
                                }

							}
						}

					//}
				}

				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);

						// if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:"
								+ assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();

							if (assDirectionalName.equals("CHD")) {
								//System.out.println("targe of sub:" + assConceptCode);
								 								//isaIndex++;
                            	//ObjectFactory factory = new ObjectFactory();
                            	//SubClass subclass = factory.createSubClass();
                            	//subclass.setCode(assConceptCode);
                            	//subclasses.add(subclass);



								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							} else {
							}
						}
					}
				}
			}

			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return subclasses;
	}
	
	//claml
	private Collection getClassSuperclasses(ResolvedConceptReference ref,
			String localName, String ns) {
		Collection superclasses = new ArrayList();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}
							System.out.println("sourceOf-assDirecName:"
									+ assDirectionalName);

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();
                                if(assDirectionalName.equals("CHD")){
            						System.out.println("source of super:" + assConceptCode);                                	
                                }

							}
						}

					}
				}

				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);

						// if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:"
								+ assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
                            
							if (assDirectionalName.equals("CHD")) {
								System.out.println("targe of super:" + assConceptCode);
                            	ObjectFactory factory = new ObjectFactory();
                            	SuperClass superclass = factory.createSuperClass();
                            	superclass.setCode(assConceptCode);
                            	superclasses.add(superclass);



								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							} else {
							}
						}
					}
				}
			}

			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return superclasses;
	}	

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		lwn = lwn.replaceAll("[- ,]", "_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		lwn = lwn.trim().replaceAll("^_+", "").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}
	
	public static void main(String[] args){
		GenerateClaMLXMLForICD model = new GenerateClaMLXMLForICD();
		//model.processingInclusions();
		//model.processingExclusions1();
		//model.processingExclusions2();
		//model.processingNotes();
		model.processingClaMLXML();
	}


}

