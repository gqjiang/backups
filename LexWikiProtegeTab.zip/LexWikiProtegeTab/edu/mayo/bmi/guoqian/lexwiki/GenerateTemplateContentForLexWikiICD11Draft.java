package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
import org.LexGrid.emf.commonTypes.PropertyQualifier;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import edu.stanford.smi.protege.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;

//first implementation of new lexwiki templates
public class GenerateTemplateContentForLexWikiICD11Draft {
	
	final private String notspecified = "Not Specified";
	
	private String hugoFileName = "hgnc.txt";
	
	private String residualCatFileName = "residual.txt";
	
	private Collection allHugoNames = new ArrayList();
	
	private Collection allResidualCodes = new ArrayList();
	
	private Map codeMap = new HashMap();

	private Map superClasses = new HashMap();

	private Collection propertyNames = new ArrayList();

	private KnowledgeBase kb = null;

	private Map propertyNameValues;

	private Collection nullConceptCodes = new ArrayList();
	
	private LexBIGService lbs = null;

	public GenerateTemplateContentForLexWikiICD11Draft() {
		allHugoNames = this.getAllHugoGenes();
		allResidualCodes = this.getAllResidualCodes();
		codeMap = this.generateMeaninglessCodeForICDCode("ICD10 WHO", "ICD");

	}

	public Map getSuperClasses() {
		return superClasses;
	}

	public Collection getNullConceptCodes() {
		return nullConceptCodes;
	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				vecCodeSystems.add(localName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String mcode = (String)codeMap.get(code);
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + mcode + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}

	// this should be called before any loading
	public Collection getPropertyNames() {
		Collection ret = new ArrayList();
		for (Iterator it = propertyNames.iterator(); it.hasNext();) {
			String propertyName = (String) it.next();
			String label = "Property:" + propertyName;
			String text = "[[has type::Type:String]]";
			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(label);
			sa.setText(text);
			ret.add(sa);
		}

		return ret;
	}

	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String mcode_ = pairs[1];
		String description_ = pairs[2];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			
			
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);


			
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
					
					sb.append(this.getHeaderHierarchyView());

					sb.append(this.getHeaderNameTextualDefinition());
					
					sb.append(this.getCodedEntryEntityID(entry));
					
					sb.append(this.getCodedEntryEntityDescription(entry));

					sb.append(this.getCodedEntryPreferredName(entry));
					
					sb.append(this.getCodedEntrySynonym(entry, ns));

					sb.append(this.getCodedEntryDefinition(entry));

					sb.append(this.getTrailerNameTextualDefintion());
					
					sb.append(this.getHeaderOntologicalMapping());
					
					sb.append(this.getCodedEntryOntologyReference());
					
					sb.append(this.getTrailerOntologicalMapping());
					
					sb.append(this.getHeaderParentCategory());
					sb.append(this.getCodedEntryAssociations(ref, localName, ns));
					sb.append(this.getTrailerParentCategory());
							
					sb.append(this.getHeaderLinearizationMTV());
					sb.append(this.getCodedEntryPreviousParentMTV(ref, localName, ns));
					sb.append(this.getCodedEntryPreferredParentMTV());
					sb.append(this.getCodedEntryMTVLegacyCode());
					sb.append(this.getCodedEntryKindMTV());
					sb.append(this.getCodedEntryIncludesMTV());
					sb.append(this.getCodedEntryExcludesMTV(ref, localName, ns));
					sb.append(this.getCodedEntryIndexTermMTV());
					sb.append(this.getTrailerLinearizationMTV());

					sb.append(this.getHeaderLinearizationMBV());
					sb.append(this.getCodedEntryPreferredParentMBV());
					sb.append(this.getCodedEntryMBVLegacyCode());
					sb.append(this.getCodedEntryKindMBV());
					sb.append(this.getCodedEntryIncludesMBV());
					sb.append(this.getCodedEntryExcludesMBV());
					sb.append(this.getCodedEntryIndexTermMBV());
					sb.append(this.getTrailerLinearizationMBV());

					sb.append(this.getHeaderLinearizationPCV());
					sb.append(this.getCodedEntryPreferredParentPCV());
					sb.append(this.getCodedEntryPCVLegacyCode());
					sb.append(this.getCodedEntryKindPCV());
					sb.append(this.getCodedEntryIncludesPCV());
					sb.append(this.getCodedEntryExcludesPCV());
					sb.append(this.getCodedEntryIndexTermPCV());
					sb.append(this.getTrailerLinearizationPCV());	
					
					sb.append(this.getHeaderClinical());
	
					sb.append(this.getCodedEntryType(code_));
					
					sb.append(this.getCodedEntryPathophysiology());
					
					sb.append(this.getCodedEntryAnatomicalSite());
					
					sb.append(this.getCodedEntrySymptomAndSign(entry, ns));
					
					sb.append(this.getCodedEntryDiagnosticFinding());
					
					sb.append(this.getCodedEntryFunctionalImpact());
					
					sb.append(this.getCodedEntryCausalAgent());
					
					sb.append(this.getCodedEntryMechanism());
					
					sb.append(this.getCodedEntryGenomicCharacteristic(entry, ns));
					
					sb.append(this.getCodedEntryChronicity());
					
					sb.append(this.getCodedEntryEpisodicity());
					
					sb.append(this.getCodedEntrySeverityAndOrExtent());

					sb.append(getCodedEntryTreatment());
					
					sb.append(this.getTrailerClinical());
					
					sb.append(this.getHeaderCriteria());
	                sb.append(this.getCodedEntryClinicalCriteria());
					sb.append(this.getTrailerCriteria());
					
					sb.append(this.getTrailerHeaderTabs());

					

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	private boolean isResidualCode(String code){
		String theCode = code;
		theCode = theCode.replaceAll("\\.", "");
		return allResidualCodes.contains(theCode);		
	}

	public Map getContentMapForConceptCode(String conceptCode,
			String localName, String ns) {
		propertyNameValues = new HashMap();
		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {

					this.getCodedEntryCodeCollection(entry);

					// sb.append("== Entity Description ==\n");
					this.getCodedEntryDescriptionCollection(entry);

					// sb.append("== Coding Scheme ==\n");
					this.getCodingSchemeCollection(localName, ns);

					// sb.append("== Definition ==\n");
					this.getCodedEntryDefinitionCollection(entry);

					// sb.append("== Presentations ==\n");
					this.getCodedEntryPresentationsCollection(entry, ns);

					this.getCodedEntryURICollection(entry, localName, ns);

					// sb.append("== Concept Property ==\n");
					this.getCodedEntryConceptPropertyCollection(entry, ns);

					// sb.append("== Comment ==\n");
					// sb.append(this.getCodedEntryComment(entry));
					// sb.append("== Associations ==\n");

					this.getCodedEntryAssociationsCollection(ref, localName, ns);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return propertyNameValues;
	}
	
	public Map generateMeaninglessCodeForICDCode(String localName, String ns){
		Map retMap = new HashMap();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			int startingCode = 1000000;
			while (rcrIt.hasNext()) {
				startingCode ++;
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				if(this.isResidualCode(code)){
					System.out.print("Residual Code:" + code);
				}
		        	
		        String meaninglessCode = Integer.toString(startingCode);
				
		        retMap.put(code, meaninglessCode);
		    
				
			}
		
			} catch (Exception e) {
				e.printStackTrace();
			}		
		return retMap;
		
	}
	
	private boolean isAdditionalResidual(String description, String code){
		boolean ret = false;
		//StringBuffer sb = new StringBuffer();
		
		
		if(description.startsWith("Other ") ||
				description.contains("unspecified ") ||
				description.endsWith("unspecified") ||
				description.endsWith("elsewhere") ||
				description.startsWith("Unspecified ") ||
				description.contains("not otherwise ") ||
				description.contains("not elsewhere ")){
			
			if(code.indexOf("-") < 0){
			    ret = true;
			//sb.append(code + "|" + description + "\n");
		    }
		}
		
		return ret;
		
	}
	
	private Collection getAllLoadedPages(){
		Collection ret = new ArrayList();
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader("icd_temp.txt"));
			String line = br.readLine();
			while(line != null){
				ret.add(line);
				line = br.readLine();
			}
			br.close();
			
		}catch(IOException e){
			e.printStackTrace();
		}
		
		
		
		return ret;
		
	}

	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {

		Collection allContents = new ArrayList();
		Collection allLoadedPages = this.getAllLoadedPages();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			BufferedWriter bw = new BufferedWriter(new FileWriter("additionalResidual.txt"));
			
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String mcode = (String)codeMap.get(code);

				String description = entry.getEntityDescription().getContent();
				String conceptLabel = "Category:"
						+ ns + " " + this.mangle(this.filterChapterName(description));
				
				String conceptTalkLabel = "Category talk:"
					+ ns + " " + this.mangle(this.filterChapterName(description));
            
                String pageName = ns + " " + this.mangle(this.filterChapterName(description));
                pageName = pageName.replaceAll(" ", "_");
                
				System.out.println(conceptLabel);
				
				if(!allLoadedPages.contains(pageName)){
				
				if(!this.isResidualCode(code)){
					
					if(!this.isAdditionalResidual(description, code)){
				
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel(conceptLabel);

				StringBuffer sb = new StringBuffer();

				sb.append(this.getHeaderHierarchyView());

				sb.append(this.getHeaderNameTextualDefinition());
				
				sb.append(this.getCodedEntryEntityID(entry));
				
				sb.append(this.getCodedEntryEntityDescription(entry));

				sb.append(this.getCodedEntryPreferredName(entry));
				
				sb.append(this.getCodedEntrySynonym(entry, ns));

				sb.append(this.getCodedEntryDefinition(entry));

				sb.append(this.getTrailerNameTextualDefintion());
				
				sb.append(this.getHeaderOntologicalMapping());
				
				sb.append(this.getCodedEntryOntologyReference());
				
				sb.append(this.getTrailerOntologicalMapping());
				
				sb.append(this.getHeaderParentCategory());
				sb.append(this.getCodedEntryAssociations(ref, localName, ns));
				sb.append(this.getTrailerParentCategory());
						
				sb.append(this.getHeaderLinearizationMTV());
				sb.append(this.getCodedEntryPreviousParentMTV(ref, localName, ns));
				sb.append(this.getCodedEntryPreferredParentMTV());
				sb.append(this.getCodedEntryMTVLegacyCode());
				sb.append(this.getCodedEntryKindMTV());
				sb.append(this.getCodedEntryIncludesMTV());
				sb.append(this.getCodedEntryExcludesMTV(ref, localName, ns));
				sb.append(this.getCodedEntryIndexTermMTV());
				sb.append(this.getTrailerLinearizationMTV());

				sb.append(this.getHeaderLinearizationMBV());
				sb.append(this.getCodedEntryPreferredParentMBV());
				sb.append(this.getCodedEntryMBVLegacyCode());
				sb.append(this.getCodedEntryKindMBV());
				sb.append(this.getCodedEntryIncludesMBV());
				sb.append(this.getCodedEntryExcludesMBV());
				sb.append(this.getCodedEntryIndexTermMBV());
				sb.append(this.getTrailerLinearizationMBV());

				sb.append(this.getHeaderLinearizationPCV());
				sb.append(this.getCodedEntryPreferredParentPCV());
				sb.append(this.getCodedEntryPCVLegacyCode());
				sb.append(this.getCodedEntryKindPCV());
				sb.append(this.getCodedEntryIncludesPCV());
				sb.append(this.getCodedEntryExcludesPCV());
				sb.append(this.getCodedEntryIndexTermPCV());
				sb.append(this.getTrailerLinearizationPCV());
				
				sb.append(this.getHeaderClinical());
				
				sb.append(this.getCodedEntryType(code));
				
				sb.append(this.getCodedEntryPathophysiology());
				
				sb.append(this.getCodedEntryAnatomicalSite());
				
				sb.append(this.getCodedEntrySymptomAndSign(entry, ns));
				
				sb.append(this.getCodedEntryDiagnosticFinding());
				
				sb.append(this.getCodedEntryFunctionalImpact());
				
				sb.append(this.getCodedEntryCausalAgent());
				
				sb.append(this.getCodedEntryMechanism());
				
				sb.append(this.getCodedEntryGenomicCharacteristic(entry, ns));
				
				sb.append(this.getCodedEntryChronicity());
				
				sb.append(this.getCodedEntryEpisodicity());
				
				sb.append(this.getCodedEntrySeverityAndOrExtent());

				sb.append(getCodedEntryTreatment());					
				
				sb.append(this.getTrailerClinical());

				sb.append(this.getHeaderCriteria());
                sb.append(this.getCodedEntryClinicalCriteria());
				sb.append(this.getTrailerCriteria());
				
				sb.append(this.getTrailerHeaderTabs());

				sa.setText(sb.toString());
				allContents.add(sa);
				SimpleArticle satalk = new SimpleArticle();
				satalk.setLabel(conceptTalkLabel);	
				satalk.setText("<Comments />");
				allContents.add(satalk);
				
			  }else{
				  
				 bw.write(code + "|" + description + "\n");
				 
			  }

			}
			}
		  }
				
				bw.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			if (ns.equals("ICD10")) {
				codingScheme = codingScheme + " SECOND EDITION";
			} else if (ns.equals("ICD10AM")) {
				codingScheme = codingScheme + " FIFTH EDITION";
			} else if (ns.equals("ICD10CM")) {
				codingScheme = codingScheme + " JULY2007 RELEASE";
			}

			sb.append("{{LexWiki inScheme|" + codingScheme + "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private void getCodingSchemeCollection(String localName, String ns) {
		Collection codingSchemes = new ArrayList();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			if (ns.equals("ICD10")) {
				codingScheme = codingScheme + " SECOND EDITION";
			} else if (ns.equals("ICD10AM")) {
				codingScheme = codingScheme + " FIFTH EDITION";
			} else if (ns.equals("ICD10CM")) {
				codingScheme = codingScheme + " JULY2007 RELEASE";
			}

			codingSchemes.add(codingScheme);
			
			propertyNameValues.put("Property:LexWiki_inScheme", codingSchemes);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}	
	
	private String getCodingSchemeName(String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			if (ns.equals("ICD10")) {
				codingScheme = codingScheme + " SECOND EDITION";
			} else if (ns.equals("ICD10AM")) {
				codingScheme = codingScheme + " FIFTH EDITION";
			} else if (ns.equals("ICD10CM")) {
				codingScheme = codingScheme + " JULY2007 RELEASE";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codingScheme;
	}

	private String getDefaultForm(String ns) {
		return "<noinclude>[[has default form::Form:LexWiki ICD11 Form]]</noinclude>\n";
	}

	private String getDefaultForm(String ns, String code) {
		if(this.isChapterXXCode(code)){
			return "<noinclude>[[has default form::Form:LexWiki ICD11 ICECI Form]]</noinclude>\n";
		}else{
			return "<noinclude>[[has default form::Form:LexWiki ICD11 Form]]</noinclude>\n";
			
		}
	}	
	
	private String getHeaderHierarchyView() {
		return "{{LexWikiICD Hierarchy View Header}}\n";
	}	
	
	private String getHeaderNameTextualDefinition() {
		return "{{LexWikiICD Name Textual Definition Header}}\n";
	}

	private String getTrailerNameTextualDefintion() {
		return "{{LexWikiICD Name Textual Definition Trailer}}\n";
	}
	

	private String getHeaderClinical() {
		return "{{LexWikiICD Header Clinical}}\n";
	}

	private String getTrailerClinical() {
		return "{{LexWikiICD Trailer Clinical}}\n";
	}
	
	private String getHeaderCriteria() {
		return "{{LexWikiICD Header Criteria}}\n";
	}

	private String getTrailerCriteria() {
		return "{{LexWikiICD Trailer Criteria}}\n";
	}	
	
	private String getHeaderOntologicalMapping() {
		return "{{LexWikiICD Ontological Header}}\n";
	}

	
	
	private String getTrailerOntologicalMapping() {
		return "{{LexWikiICD Ontological Trailer}}\n";
	}	

	private String getHeaderLinearizationMTV() {
		return "{{LexWikiICD Mortality View Header}}\n";
	}

	private String getTrailerLinearizationMTV() {
		return "{{LexWikiICD Mortality View Trailer}}\n";
	}
	
	private String getHeaderLinearizationMBV() {
		return "{{LexWikiICD Morbidity View Header}}\n";
	}

	private String getTrailerLinearizationMBV() {
		return "{{LexWikiICD Morbidity View Trailer}}\n";
	}	

	private String getHeaderLinearizationPCV() {
		return "{{LexWikiICD Primary Care View Header}}\n";
	}

	private String getTrailerLinearizationPCV() {
		return "{{LexWikiICD Primary Care View Trailer}}\n";
	}	
		
	
	private String getHeaderParentCategory() {
		return "{{LexWikiICD Header Parent}}\n";
	}

	private String getTrailerParentCategory() {
		return "{{LexWikiICD Trailer Parent}}\n";
	}	
	
	private String getTrailerHeaderTabs() {
		return "{{LexWikiICD HeaderTabs Trailer}}\n";
	}


	private String getHeaderICECIBridgeModel(String code) {
		if(this.isChapterXXCode(code)){
			return "<noinclude>{{LexWikiICD ICECI Bridge Model Header}}</noinclude>\n";
		}else{
			return "";
		}
	}	
	
	private String getTrailerICECIBridgeModel(String code) {
		if(this.isChapterXXCode(code)){
			return "<noinclude>{{LexWikiICD ICECI Bridge Model Trailer}}</noinclude>\n";
		}else{
			return "";
		}
		}
	
	//for icd11
	private String getCodedEntryICECIMechanism(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){
			sb.append("{{LexWikiICD ICECI Mechanism|" + notspecified + "}}\n");
		}else{
			sb.append("");
		}
		return sb.toString();
	}			

	//for icd11
	private String getCodedEntryICECIIntent(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){
			sb.append("{{LexWikiICD ICECI Intent|" + notspecified + "}}\n");
		}else{
			sb.append("");
		}
		return sb.toString();
	}		

	//for icd11
	private String getCodedEntryICECITransport(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){
		sb.append("{{LexWikiICD ICECI Transport|" + notspecified + "}}\n");
		}else{
			sb.append("");
		}
		return sb.toString();
	}		

	//for icd11
	private String getCodedEntryICECIPlace(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){
		sb.append("{{LexWikiICD ICECI Place|" + notspecified + "}}\n");
	}else{
		sb.append("");
	}
		return sb.toString();
	}
	
	//for icd11
	private String getCodedEntryICECIActivity(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){
		sb.append("{{LexWikiICD ICECI Activity|" + notspecified + "}}\n");
		}else{
			sb.append("");
		}
		return sb.toString();
	}
	
	//for icd11
	private String getFormForICECIBridgeModel(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){	
	       sb.append("<noinclude>[[Special:EditData/LexWiki_ICD11_ICECI_Bridge_Model_Form/{{FULLPAGENAMEE}}|Edit the Bridge Model]]</noinclude>\n");
		}else{
			sb.append("");
		}
		return sb.toString();
	}
	
	private boolean isChapterXXCode(String code){
		boolean ret = false;
		
		if(code.startsWith("V") ||
				code.startsWith("W") ||
				code.startsWith("X") ||
				code.startsWith("Y")){
			
			ret = true;
			
		}
		
		return ret;
	}
		

	private String getCodedEntryCode(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		return sb.toString();
	}

	private void getCodedEntryCodeCollection(CodedEntry entry) {

		Collection codes = new ArrayList();
		String code = entry.getConceptCode();
		codes.add(code);
		propertyNameValues.put("Property:LexWiki_Concept_Code", codes);
		
	}

	private String getCodedEntryEntityID(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		String mcode = (String) codeMap.get(code);
		sb.append("{{LexWikiICD Entity ID|" + mcode + "|source=WHO}}\n");
		return sb.toString();
	}	

	private String getCodedEntryOntologyReference() {

		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Ontology Reference|id=" + notspecified + "|source=" + 
				notspecified + "|comment=" + notspecified + "}}\n");
		return sb.toString();
	}		

	
	//for icd11
	private String getCodedEntryEntityDescription(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		description = this.mangle(this.filterChapterName(description));
		sb.append("{{LexWikiICD Entity Description|" + description + "|source=WHO}}\n");
		return sb.toString();

	}	

	//for icd11
	private String getCodedEntryPreferredName(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		description = this.mangle(this.filterChapterName(description));
		sb.append("{{LexWikiICD Preferred Name|" + description + "|source=WHO}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntrySynonym(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		System.out.println("presentation count:" + pIndex);
		int idxSyn = 0;
		//if(pIndex > 0){
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String nsPropName = ns + "_" + propName;
			if(!propertyNames.contains(nsPropName))
			    propertyNames.add(nsPropName);
			String text = pres.getText().getContent();
			text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			if(!isPref){
			  idxSyn++;
			  String source = pres.getSource(0).getContent();
			  sb.append("{{LexWikiICD Synonym|1=" + text + "|source=" + source + "}}\n");			
			}
		}

		  if(idxSyn < 1)
			  sb.append("{{LexWikiICD Synonym|1=" + notspecified + "|source=" + notspecified + "}}\n");			


		
		
		

		return sb.toString();

	}	

	//for icd11
	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int defIndex = entry.getDefinitionCount();
		//System.out.println("def count1:" + defIndex);		
		Definition[] definitions = entry.getDefinition();
		int dIndex = definitions.length;
		System.out.println("def count2:" + dIndex);		
		if(dIndex > 0){
		for (int i = 0; i < definitions.length; i++) {
			String defText = definitions[i].getText().getContent();
			//String defText = entry.getDefinition(i).getText().getContent();
			String source = definitions[i].getSource(0).getContent();
			//String source = entry.getDefinition(i).getSource(0).getContent();
			//System.out.println(source + ":" + defText);
			sb.append("{{LexWikiICD Definition|1=" + defText + "|source=" + source + "}}\n");
		
		}
		}else{
			sb.append("{{LexWikiICD Definition|1=" + notspecified + "|source=" + notspecified + "}}\n");
		}
		return sb.toString();

	}	
	
	//for icd11
	private String getCodedEntryType() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Type|" + notspecified + "|source=WHO}}\n");
		return sb.toString();

	}	

	//for icd11
	private String getCodedEntryType(String code) {
		StringBuffer sb = new StringBuffer();
		if(this.isChapterXXCode(code)){
			sb.append("{{LexWikiICD Type|" + "Exposure to external causes" + "|source=WHO}}\n");			
		}else{
			sb.append("{{LexWikiICD Type|" + notspecified + "|source=WHO}}\n");
		}
		return sb.toString();

	}		
	
	//for icd11
	private String getCodedEntryPathophysiology() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Pathophysiology|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntryAnatomicalSite() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Anatomical Site|" + notspecified + "}}\n");
		return sb.toString();

	}		
	

	//for icd11
	private String getCodedEntrySymptomAndSign(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
	    int index = 0;		
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
		    String cpName = cp.getProperty();

		    if(cpName.equals("CLINICAL_SIGN")){
		    	index++;
		    	String signText = cp.getText().getContent();
		    	String signName = "Orphanet_" + this.mangle(signText) +
		    	                  "(" + this.getClinicalSignID(cp) + ")";
				sb.append("{{LexWikiICD Symptom And Sign|1=" + signName + "|source=Orphanet}}\n");
		    	
		    }
		    
		}
		if(index < 1){
			sb.append("{{LexWikiICD Symptom And Sign|1=" + notspecified + "|source=" + notspecified + "}}\n");		    	
		}
		
		return sb.toString();

	}
		
	private String getOrphanetID(ConceptProperty cp){
		String ret = "";
		org.LexGrid.commonTypes.PropertyQualifier[] ids = cp.getPropertyQualifier();
		for(int i = 0; i < ids.length; i++){
			String id = ids[i].getPropertyQualifierId();
			if(id.equals("Orphanet_ID")){
				ret = ids[i].getContent();
				break;
			}	
		}
		return ret;
	}
	
	//no qualifier id content returned
	private String getClinicalSignID(ConceptProperty cp){
		String ret = "";
		org.LexGrid.commonTypes.PropertyQualifier[] ids = cp.getPropertyQualifier();

		for(int i = 0; i < ids.length; i++){
			String id = ids[i].getPropertyQualifierId();
			if(id.equals("Clinical_Sign_ID")){
				ret = ids[i].getContent();
				int lenIndex = ret.length();
				ret = ret.substring(0, lenIndex-2);
				break;
			}
		}
		return ret;
	}	
	
	//for icd11
	private String getCodedEntryDiagnosticFinding() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Diagnostic Finding|" + notspecified + "}}\n");
		return sb.toString();

	}
		
	//for icd11
	private String getCodedEntryFunctionalImpact() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Functional Impact|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntryCausalAgent() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Causal Agent|" + notspecified + "}}\n");
		return sb.toString();

	}
			
	//for icd11
	private String getCodedEntryMechanism() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Mechanism|" + notspecified + "}}\n");
		return sb.toString();

	}

	
	//for icd11
	private String getCodedEntryGenomicCharacteristic(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		int index = 0;
		Collection colHgncNames = new ArrayList();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
		    String cpName = cp.getProperty();
		    if(cpName.equals("HGNC_ID")){
		    	index++;
		    	String hugoID = cp.getText().getContent();
		    	String hugoName = this.getHugoGeneName(hugoID);
		    	//System.out.println("hugoName:" + hugoName);
		    	if(!colHgncNames.contains(hugoName)){
		    		sb.append("{{LexWikiICD Genomic Characteristic|1=" + hugoName + "|source=Orphanet}}\n");
		    		colHgncNames.add(hugoName);
		    	}
		    }
		    	
		    
		}
		if(index < 1)
			sb.append("{{LexWikiICD Genomic Characteristic|1=" + notspecified + "}}\n");


		
		return sb.toString();

	}
	
	private Collection getAllHugoGenes(){
		
		Collection ret = new ArrayList();
		try{
			BufferedReader br = new BufferedReader(new FileReader("hgnc.txt"));
			String line = br.readLine();
			line = br.readLine();
			
			while(line != null){
				String[] items = line.split("\t");
				ret.add(items);
				line = br.readLine();
				System.out.println(line);
			}
			
			br.close();
			
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		System.out.println("hugo file size:" + ret.size());
	
		return ret;
	}
	
	private Collection getAllResidualCodes(){
		
		Collection ret = new ArrayList();
		try{
			BufferedReader br = new BufferedReader(new FileReader("residual.txt"));
			String line = br.readLine();
			line = br.readLine();
			
			while(line != null){
				//String[] items = line.split("\t");
				ret.add(line.trim());
				line = br.readLine();
				System.out.println(line);
			}
			
			br.close();
			
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		System.out.println("hugo file size:" + ret.size());
	
		return ret;
	}	

	private String getHugoGeneName(String hugoID){
		//Collection entries = this.getAllHugoGenes();
		String ret = "";
		int index = 0;
		for(Iterator it = allHugoNames.iterator(); it.hasNext();){
			index++;
			
			String[] items = (String[]) it.next();
			StringBuffer sb = new StringBuffer();
           
			if(items[0].equals(hugoID)){
			
			String label = "HUGO_" + items[2] + "(" + items[1] + ")";			
			ret = this.mangle(label);
			break;
			
			}
			
		}
		
		return ret;
	}
	
	//for icd11
	private String getCodedEntryChronicity() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Chronicity|" + notspecified + "}}\n");
		return sb.toString();

	}
		
	//for icd11
	private String getCodedEntryEpisodicity() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Episodicity|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntrySeverityAndOrExtent() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Severity AndOr Extent|" + notspecified + "}}\n");
		return sb.toString();

	}

	//for icd11
	private String getCodedEntryTreatment() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Treatment|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntryClinicalCriteria() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Clinical Criteria|" + notspecified + "}}\n");
		return sb.toString();

	}	

	//for icd11
	private String getCodedEntryMTVLegacyCode() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD MTV Legacy Code|" + notspecified + "}}\n");
		return sb.toString();

	}

	//for icd11
	private String getCodedEntryMBVLegacyCode() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD MBV Legacy Code|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntryPCVLegacyCode() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD PCV Legacy Code|" + notspecified + "}}\n");
		return sb.toString();

	}	

	//for icd11
	private String getCodedEntryPreferredParentMTV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Preferred Parent MTV|" + notspecified + "}}\n");
		return sb.toString();

	}		
	
	//for icd11
	private String getCodedEntryPreferredParentMBV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Preferred Parent MBV|" + notspecified + "}}\n");
		return sb.toString();

	}		
	
	//for icd11
	private String getCodedEntryPreferredParentPCV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Preferred Parent PCV|" + notspecified + "}}\n");
		return sb.toString();

	}	
	
	//for icd11
	private String getCodedEntryKindMTV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Kind MTV|" + notspecified + "}}\n");
		return sb.toString();

	}		
	
	//for icd11
	private String getCodedEntryKindMBV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Kind MBV|" + notspecified + "}}\n");
		return sb.toString();

	}		
	
	//for icd11
	private String getCodedEntryKindPCV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Kind PCV|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntryIncludesMTV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Includes MTV|" + notspecified + "}}\n");
		return sb.toString();

	}
	
	//for icd11
	private String getCodedEntryIncludesMBV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Includes MBV|" + notspecified + "}}\n");
		return sb.toString();

	}

	//for icd11
	private String getCodedEntryIncludesPCV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Includes PCV|" + notspecified + "}}\n");
		return sb.toString();

	}
	//for icd11
	private String getCodedEntryExcludesMTVBlank() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Excludes MTV|" + notspecified + "}}\n");
		return sb.toString();

	}

	//for icd11
	private String getCodedEntryExcludesMBV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Excludes MBV|" + notspecified + "}}\n");
		return sb.toString();

	}

	//for icd11
	private String getCodedEntryExcludesPCV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Excludes PCV|" + notspecified + "}}\n");
		return sb.toString();

	}	
	
	//for icd11
	private String getCodedEntryIndexTermMTV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Index Term MTV|" + notspecified + "}}\n");
		return sb.toString();

	}
		
	//for icd11
	private String getCodedEntryIndexTermMBV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Index Term MBV|" + notspecified + "}}\n");
		return sb.toString();

	}		

	//for icd11
	private String getCodedEntryIndexTermPCV() {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWikiICD Index Term PCV|" + notspecified + "}}\n");
		return sb.toString();

	}		
	
	private void getCodedEntryDescriptionCollection(CodedEntry entry) {
		Collection descriptions = new ArrayList();
		String description = entry.getEntityDescription().getContent();
		description = this.mangle(description);
		descriptions.add(description);
		propertyNameValues
				.put("Property:LexWiki_Preferred_Name", descriptions);

	}

	private String getCodedEntryURI(CodedEntry entry, String localName,
			String ns) {
		StringBuffer sb = new StringBuffer();
		String scheme = this.getCodingSchemeName(localName, ns);
		String code = entry.getConceptCode();
		sb.append("{{LexWiki URI|" + scheme + ":" + code + "}}\n");
		return sb.toString();

	}

	private void getCodedEntryURICollection(CodedEntry entry, String localName,
			String ns) {
		Collection uris = new ArrayList();
		String scheme = this.getCodingSchemeName(localName, ns);
		String code = entry.getConceptCode();
		uris.add(scheme + ":" + code);
		propertyNameValues.put("Property:LexWiki_URI", uris);

	}
/*
	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			if (ii == 0) {
				sb.append("{{LexWiki Definition|"
						+ entry.getDefinition(ii).getText().getContent()
						+ "}}\n");
			} else {
				sb.append("{{LexWiki AltDefinition|"
						+ entry.getDefinition(ii).getText().getContent()
						+ "}}\n");

			}
		}

		return sb.toString();

	}
*/
	private void getCodedEntryDefinitionCollection(CodedEntry entry) {
		Collection defs = new ArrayList();
		Collection altdefs = new ArrayList();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			if (ii == 0) {
				defs.add(entry.getDefinition(ii).getText().getContent());
			} else {
				altdefs.add(entry.getDefinition(ii).getText().getContent());

			}
		}
		if (defs.size() >= 0)
			propertyNameValues.put("Property:LexWiki_Definition", defs);

		if (altdefs.size() >= 0)
			propertyNameValues.put("Property:LexWiki_AltDefinition", altdefs);
	}

	private String getCodedEntryPresentations(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String nsPropName = ns + "_" + propName;
			if (!propertyNames.contains(nsPropName))
				propertyNames.add(nsPropName);
			String text = pres.getText().getContent();
			text = this.mangle(text);
			boolean isPref = pres.getIsPreferred();

			// if (isPref) {
			// String attrName = "Has Preferred " + propName;
			// sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
			// + "}}\n");
			// } else {
			// String fidelity = pres.getDegreeOfFidelity();
			// String attrName = "Has " + fidelity + " "
			// + propName;
			sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
					+ text + "}}\n");
			// }
		}

		return sb.toString();

	}

	private void getCodedEntryPresentationsCollection(CodedEntry entry,
			String ns) {
		StringBuffer sb = new StringBuffer();

		Collection propNames = this.getPropNames(entry, ns);
		for (Iterator it = propNames.iterator(); it.hasNext();) {
			String pName = (String) it.next();
			Collection pValues = new ArrayList();
			int pIndex = entry.getPresentationCount();
			for (int ip = 0; ip < pIndex; ip++) {
				Presentation pres = entry.getPresentation(ip);
				String propName = pres.getProperty();
				String nsPropName = ns + "_" + propName;
				if (nsPropName.equals(pName)) {
					String text = pres.getText().getContent();
					text = this.mangle(text);
					pValues.add(text);
				}

			}
			propertyNameValues.put("Property:" + pName, pValues);
		}

	}

	private Collection getPropNames(CodedEntry entry, String ns) {
		Collection props = new ArrayList();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String nsPropName = ns + "_" + propName;
			if (!props.contains(nsPropName))
				props.add(nsPropName);
		}

		return props;
	}

	 
	//icd11
	private String getCodedEntryConceptProperty(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			cpName = cpName.replaceAll("Includes", "Inclusion");
			cpName = cpName.replaceAll("Excludes", "Exclusion");
			cpName = cpName.replaceAll("Inclusion/Synonym Terms", "Inclusion");

			if (!propertyNames.contains(cpName))
				propertyNames.add(cpName);

			String cpText = cp.getText().getContent();
			cpText = this.mangleProperty(cpText);
			
			if(cpName.indexOf("Inclusion") >= 0){
				sb.append("<noinclude>{{LexWikiICD Inclusion|" + cpText
						+ "}}</noinclude>\n");				
			}else if(cpName.indexOf("Exclusion") >= 0){
				sb.append("<noinclude>{{LexWikiICD Exclusion|" + cpText
						+ "}}</noinclude>\n");								
			}
			
			//sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText + "}}\n");
		}

		return sb.toString();
	}
	
	
	//icd11
	private Collection getHugoIDsFromConceptProperty(CodedEntry entry, String ns) {
		Collection ret = new ArrayList();
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();

			String cpText = cp.getText().getContent();
			cpText = this.mangleProperty(cpText);
			

			
			//sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText + "}}\n");
		}

		return ret;
	}	

	private void getCodedEntryConceptPropertyCollection(CodedEntry entry,
			String ns) {
		StringBuffer sb = new StringBuffer();
		Collection propNames = this.getConceptProperyNames(entry, ns);
		for (Iterator it = propNames.iterator(); it.hasNext();) {
			String propName = (String) it.next();
			Collection pValues = new ArrayList();
			int cpIndex = entry.getConceptPropertyCount();
			for (int cpi = 0; cpi < cpIndex; cpi++) {
				ConceptProperty cp = entry.getConceptProperty(cpi);
				String cpName = ns + "_" + cp.getProperty();

				if (cpName.equals(propName)) {
					String cpText = cp.getText().getContent();
					cpText = this.mangleProperty(cpText);
					pValues.add(cpText);
				}
			}
			propertyNameValues.put("Property:" + propName, pValues);
		}
	}

	private Collection getConceptProperyNames(CodedEntry entry, String ns) {
		Collection propNames = new ArrayList();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			cpName = cpName.replaceAll("Includes", "Inclusion");
			cpName = cpName.replaceAll("Excludes", "Exclusion");
			cpName = cpName.replaceAll("Inclusion/Synonym Terms", "Inclusion");
			if (!propNames.contains(cpName))
				propNames.add(cpName);
		}

		return propNames;
	}

	private String getCodedEntryComment(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|"
					+ entry.getComment(j).getText().getContent() + "}}\n");
		}

		return sb.toString();
	}

	private boolean isLeafNode(ResolvedConceptReference ref, String localName,
			String ns) {
		boolean ret = false;

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			
			// to detect if there is a super concept for this code.
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("isleafnode:" + assName);
						if (assName.equals("CHD")) {
							ret = true;
						}
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	private void getCodedEntryAssociationsCollection(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();
			
			Collection associationNames = this.getAssociationNames(ref, localName, ns);
			for(Iterator it = associationNames.iterator(); it.hasNext();){
				String associationName = (String) it.next();
				Collection associationValues = new ArrayList();
		

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();
								
								if(associationName.equals(ns + "_" + assDirectionalName)){
									associationValues.add(
											ns
											+ "_("
											+ assConcept.getConceptCode()
											+ ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}\n");									}



							}
						}

					}
				}
			}
			
			propertyNameValues.put("Property:" + associationName, associationValues);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}


	}	

	private Collection getAssociationNames(ResolvedConceptReference ref,
			String localName, String ns) {
		Collection associationNames = new ArrayList();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept
										.getConceptCode();
                                
								if(!associationNames.contains(ns + "_" + assDirectionalName))
								    associationNames.add(ns + "_" + assDirectionalName);



							}
						}

					}
				}
			}



		} catch (Exception e) {
			e.printStackTrace();
		}
        return associationNames;

	}	

	
	//icd11
	private String getCodedEntryExcludesMTV(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer("");

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			
			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}
							System.out.println("sourceOf-assDirecName:"
									+ assDirectionalName);

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept.getConceptCode();
                           /*     
								if(assDirectionalName.indexOf("Include")>=0){
									sb
									.append("<noinclude>{{LexWikiICD Includes|"
											+ ns
											+ "_("
											+ assConcept.getConceptCode()
											+ ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}</noinclude>\n");									
									
								}else 
							*/
								if(assDirectionalName.indexOf("Exclude")>=0){
									sb
									.append("{{LexWikiICD Excludes MTV|"
											+ ns
											+ " "
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}\n");										
								}
								


							}
						}

					}
				}


			}
	


		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(sb.toString().length() < 1){
			sb.append(this.getCodedEntryExcludesMTVBlank());
		}

		return sb.toString();
	}


	
	//icd11
	private String getCodedEntryPreviousParentMTV(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			
			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						//if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}
							System.out.println("sourceOf-assDirecName:"
									+ assDirectionalName);

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept.getConceptCode();
                           /*     
								if(assDirectionalName.indexOf("Include")>=0){
									sb
									.append("<noinclude>{{LexWikiICD Includes|"
											+ ns
											+ "_("
											+ assConcept.getConceptCode()
											+ ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}</noinclude>\n");									
									
								}else if(assDirectionalName.indexOf("Exclude")>=0){
									sb
									.append("<noinclude>{{LexWikiICD Excludes|"
											+ ns
											+ "_("
											+ assConcept.getConceptCode()
											+ ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}</noinclude>\n");										
								}
								*/

								/*
								sb
										.append("{{LexWiki Association|"
												+ ns
												+ "_"
												+ assDirectionalName
												+ "|"
												+ ns
												+ " "
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent()) + "("
												+ assConcept.getConceptCode()
												+ ")}}\n");
                                 */
								/*
								 * if (assDirectionalName.equals("PAR")) {
								 * isaIndex++;
								 * 
								 * sb.append("<noinclude>{{LexWiki Parent|" +
								 * ns + " " +
								 * this.mangle(assConcept.getEntityDescription()
								 * .getContent()) + "(" +
								 * assConcept.getConceptCode() + ")}}</noinclude>\n");
								 */
								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							}
						}

					}
				//}

				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);

						// if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:"
								+ assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();

							if (assDirectionalName.equals("PAR")) {
								isaIndex++;

								if (assConcept.getEntityDescription() != null) {
                                    String mcode = (String)codeMap.get(assConcept.getConceptCode());
									sb.append("{{LexWikiICD Previous Parent MTV|"
											+ ns
											+ " "
											//+ assConcept.getConceptCode()
											
											+ this.mangle(this.filterChapterName(assConcept
													.getEntityDescription()
													.getContent())) 
											+ "}}\n");	
								} else {
									nullConceptCodes.add(ref.getConceptCode());
								}

								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							} 
							
							/*
							else {
								sb
										.append("{{LexWiki Inverse Association|"
												+ ns
												+ "_"
												+ assDirectionalName
												+ "|"
												+ ns
												+ " "
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent())
												+ "("
												+ assConcept.getConceptCode()
												+ ")}}\n");

							}
							*/
						}
					}
				}
			}
			// }

			if (isaIndex == 0) {
				sb.append("{{LexWikiICD Previous Parent MTV|" + "ICD"//localName
						+ "}}\n");

				/*
				 * sb.append("<noinclude>[[Category:" + localName + "]]</noinclude>\n");
				 */
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	

	
	//icd11
	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			
			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						//if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}
							System.out.println("sourceOf-assDirecName:"
									+ assDirectionalName);

							// do not need hasSubtype
							// if (!assName.equals("hasSubtype")) {
							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];
								String assConceptCode = assConcept.getConceptCode();
                           /*     
								if(assDirectionalName.indexOf("Include")>=0){
									sb
									.append("<noinclude>{{LexWikiICD Includes|"
											+ ns
											+ "_("
											+ assConcept.getConceptCode()
											+ ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}</noinclude>\n");									
									
								}else if(assDirectionalName.indexOf("Exclude")>=0){
									sb
									.append("<noinclude>{{LexWikiICD Excludes|"
											+ ns
											+ "_("
											+ assConcept.getConceptCode()
											+ ")_"
											+ this.mangle(assConcept
													.getEntityDescription()
													.getContent()) + "}}</noinclude>\n");										
								}
								*/

								/*
								sb
										.append("{{LexWiki Association|"
												+ ns
												+ "_"
												+ assDirectionalName
												+ "|"
												+ ns
												+ " "
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent()) + "("
												+ assConcept.getConceptCode()
												+ ")}}\n");
                                 */
								/*
								 * if (assDirectionalName.equals("PAR")) {
								 * isaIndex++;
								 * 
								 * sb.append("<noinclude>{{LexWiki Parent|" +
								 * ns + " " +
								 * this.mangle(assConcept.getEntityDescription()
								 * .getContent()) + "(" +
								 * assConcept.getConceptCode() + ")}}</noinclude>\n");
								 */
								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							}
						}

					}
				//}

				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);

						// if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:"
								+ assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();

							if (assDirectionalName.equals("PAR")) {
								isaIndex++;

								if (assConcept.getEntityDescription() != null) {
                                    String mcode = (String)codeMap.get(assConcept.getConceptCode());
									sb.append("{{LexWikiICD Parent|"
											+ ns
											+ " "
											//+ assConcept.getConceptCode()
											
											+ this.mangle(this.filterChapterName(assConcept
													.getEntityDescription()
													.getContent())) 
											+ "}}\n");	
								} else {
									nullConceptCodes.add(ref.getConceptCode());
								}

								/*
								 * sb.append("<noinclude>[[Category:" + ns + " " +
								 * assConcept.getEntityDescription()
								 * .getContent() + "(" +
								 * assConcept.getConceptCode() + ")]]</noinclude>\n");
								 */
							} 
							
							/*
							else {
								sb
										.append("{{LexWiki Inverse Association|"
												+ ns
												+ "_"
												+ assDirectionalName
												+ "|"
												+ ns
												+ " "
												+ this.mangle(assConcept
														.getEntityDescription()
														.getContent())
												+ "("
												+ assConcept.getConceptCode()
												+ ")}}\n");

							}
							*/
						}
					}
				}
			}
			// }

			if (isaIndex == 0) {
				sb.append("{{LexWikiICD Parent|" + "ICD"//localName
						+ "}}\n");

				/*
				 * sb.append("<noinclude>[[Category:" + localName + "]]</noinclude>\n");
				 */
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	private String filterChapterName(String name){
		
		String ret = "";
		if(name.indexOf("(CHAPTER ") >=0){
			int index = name.indexOf("(CHAPTER ");
			ret = name.substring(0, index-1);
			
		}else{
			
			ret = name;
		}
		
		
		return ret;
		
	}


	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + "_" + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		thisConcept = this.mangle(thisConcept);

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("CHD")) {
							String assDirectionalName = assName;
							if (ass.getDirectionalName() != null) {
								assDirectionalName = ass.getDirectionalName();
							}

							AssociatedConceptList acList = ass
									.getAssociatedConcepts();
							AssociatedConcept[] assConcepts = acList
									.getAssociatedConcept();
							for (int ac = 0; ac < assConcepts.length; ac++) {
								AssociatedConcept assConcept = assConcepts[ac];

								String thisAssEntityDescription = ns
										+ "_"
										+ assConcept.getEntityDescription()
												.getContent().replaceAll(" ",
														"_");
								thisAssEntityDescription = this
										.mangle(thisAssEntityDescription);

								sb.append("[ " + thisConcept + "] "
										+ "{ fill: 5; link:" + thisConcept
										+ "; } " + "-- " + assDirectionalName
										+ " --> {link:Relation:" + ns + "_"
										+ assDirectionalName
										+ "; start: front, 0; } "
										+ " [ Category:"
										+ thisAssEntityDescription + "("
										+ assConcept.getConceptCode() + ") ] "
										+ "{ fill:3; link: Category:"
										+ thisAssEntityDescription + "("
										+ assConcept.getConceptCode() + "); }"
										+ "\n");

							}

						}
					}
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");
							thisAssEntityDescription = this
									.mangle(thisAssEntityDescription);
							if (!assDirectionalName.equals("CHD")) {

								sb.append("[ " + thisConcept + "] "
										+ "{ fill: 5; link:"
										+ thisConcept
										+ "; } "
										+ "-- "
										+ assDirectionalName
										+ "(inverse) --> {link:Relation:"
										+ ns
										+ "_"
										+ assDirectionalName
										+ "; start: front, 0; } "
										+ " [ Category:"
										+ thisAssEntityDescription
										// + "(" + assConcept.getConceptCode()
										// + ") ] "

										+ " ] { fill: 4 ; link: Category:"
										+ thisAssEntityDescription + "("
										+ assConcept.getConceptCode() + "); }"
										+ "\n");

							}
						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = this.mangle(ref.getEntityDescription()
				.getContent());
		
		String code = ref.getConceptCode();
		String mcode = (String)codeMap.get(code);

		String thisConcept = "Category:" + ns  + " " + thisConceptName + "(" + mcode
        + ")";

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		lwn = lwn.replaceAll("[- ,]", "_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		lwn = lwn.trim().replaceAll("^_+", "").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		lwn = lwn.replaceAll("__+", "_");
		
		return lwn.replaceAll("_", " ");
	}

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangleProperty(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		// lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		// lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		lwn = lwn.replaceAll("\\[", "\\(");
		lwn = lwn.replaceAll("\\]", "\\)");

		// 3) Remove leading and trailing "_"
		// lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");

		// 4) Adjacent underscores map to a single underscore
		lwn = lwn.replaceAll("__+", "_");
		
		return lwn.replaceAll("_", " ");		
	}

}
