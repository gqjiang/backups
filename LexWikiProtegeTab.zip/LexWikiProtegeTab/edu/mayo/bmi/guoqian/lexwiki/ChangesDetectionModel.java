package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;
import java.sql.*;

public class ChangesDetectionModel {

	private Connection con = null;

	private StringBuffer result = new StringBuffer();

	public ChangesDetectionModel(String catName, Collection articles,
			String prefix, String url, String user, String password) {
		this.detectChangesForAttributes(catName, articles, prefix, url, user, password);
		this.detectChangesForRelations(catName, articles, prefix, url, user, password);

	}

	public String getChangeSets() {
		return result.toString();
	}

	private void detectChangesForAttributes(String catName, Collection articles,
			String prefix, String url, String user, String password) {

		// for attributes
		Collection attributes = this.getAttributeSet(catName, 14, prefix, url,
				user, password);
		//for each attribute defined in the category
		for (Iterator it = attributes.iterator(); it.hasNext();) {
			String attrName = (String) it.next();
			Collection attrValues = this.getAttributeValueSet(catName, 14,
					prefix, url, user, password, attrName);
			
			//for each attribute value
			for (Iterator it0 = attrValues.iterator(); it0.hasNext();) {
				String attrValue = (String) it0.next();
				result.append(attrName + "-->" + attrValue + "\n");
                
				//for each article
				for (Iterator it1 = articles.iterator(); it1.hasNext();) {
					String article = (String) it1.next();
					Collection artiAttrValues = this.getAttributeValueSet(
							article, 0, prefix, url, user, password, attrName);

					this.getComparisonResult(attrValue, article, attrValues,
							artiAttrValues);
				}
			}
			
			//for newly defined attribute value in each article
			for (Iterator it2 = articles.iterator(); it2.hasNext();) {
				String article = (String) it2.next();
				Collection artiAttrValues = this.getAttributeValueSet(article,
						0, prefix, url, user, password, attrName);

				this.getNewlyDefinedResult(article, attrValues, artiAttrValues);
			}
			
			//for newly defined attribute name in each article
			for (Iterator it3 = articles.iterator(); it3.hasNext();) {
				String article = (String) it3.next();
				Collection artiAttributes = this.getAttributeSet(article,
						0,prefix, url, user, password);
				for(Iterator it4 = artiAttributes.iterator(); it4.hasNext();){
					String artiAttr = (String)it4.next();
					if(!attributes.contains(artiAttr)){
						Collection newAttrValues = this.getAttributeValueSet(article, 
								0, prefix, url, user, password, artiAttr);
						for(Iterator it5 = newAttrValues.iterator(); it5.hasNext();){
							String newAttrValue = (String)it5.next();
							result.append(artiAttr + "==>" + newAttrValue + "\n");
							result.append("\tNewly defined attribute (in " + article + ")\n");
						}
					}
				}
			}

		}


	}
	
	
	private void detectChangesForRelations(String catName, Collection articles,
			String prefix, String url, String user, String password) {


		// for relations
		Collection relations = this.getRelationSet(catName, 14, prefix, url,
				user, password);
		for (Iterator it = relations.iterator(); it.hasNext();) {
			String relName = (String) it.next();
			Collection relValues = this.getRelationValueSet(catName, 14,
					prefix, url, user, password, relName);
			for (Iterator it0 = relValues.iterator(); it0.hasNext();) {
				String objValue = (String) it0.next();
				result.append(relName + "-->" + objValue + "\n");

				for (Iterator it1 = articles.iterator(); it1.hasNext();) {
					String article = (String) it1.next();
					Collection artiRelValues = this.getRelationValueSet(
							article, 0, prefix, url, user, password, relName);

					this.getComparisonResult(objValue, article, relValues,
							artiRelValues);
				}
			}
			for (Iterator it2 = articles.iterator(); it2.hasNext();) {
				String article = (String) it2.next();
				Collection artiRelValues = this.getRelationValueSet(
						article, 0, prefix, url, user, password, relName);
			
			    this.getNewlyDefinedResult(article, relValues, artiRelValues);
			}
		}
		
		//for newly defined relation name in each article
		for (Iterator it3 = articles.iterator(); it3.hasNext();) {
			String article = (String) it3.next();
			Collection artiRelations = this.getRelationSet(article,
					0,prefix, url, user, password);
			for(Iterator it4 = artiRelations.iterator(); it4.hasNext();){
				String artiRel = (String)it4.next();
				if(!relations.contains(artiRel)){
					Collection newRelValues = this.getRelationValueSet(article, 
							0, prefix, url, user, password, artiRel);
					for(Iterator it5 = newRelValues.iterator(); it5.hasNext();){
						String newRelValue = (String)it5.next();
						result.append(artiRel + "==>" + newRelValue + "\n");
						result.append("\tNewly defined relation (in " + article + ")\n");
					}
				}
			}
		}		

	}
	private void getComparisonResult(String attrValue, String article,
			Collection catValues, Collection artiValues) {
		if (artiValues.contains(attrValue)) {
			result.append("\tNo Change" + "(from " + article + ")\n");
		} else {
			result.append("\tNot defined (in " + article + ")\n");
		}

	}

	
	private void getNewlyDefinedResult(String article, Collection catValues,
			Collection artiValues) {
		for (Iterator it = artiValues.iterator(); it.hasNext();) {
			String artiValue = (String) it.next();
			
			if (!catValues.contains(artiValue)) {
				result.append("\t==>" + artiValue);
				result.append(" Newly defined (in " + article + ")\n");
			}
		}
	}
	
	private Collection getAttributeSet(String catName, int nsIndex,
			String prefix, String url, String user, String password) {
		Collection attributes = new ArrayList();

		String sqlCatAttr = this.getSQLAttributes(catName, prefix, nsIndex);

		try {
			this.establishConnection(url, user, password);

			// for attributes
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlCatAttr);
			while (rs.next()) {
				String attrName = rs.getString("attribute_title");
				if (!attributes.contains(attrName)) {
					attributes.add(attrName);
				}
			}

			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
		return attributes;
	}

	private Collection getAttributeValueSet(String catName, int nsIndex,
			String prefix, String url, String user, String password,
			String attrName) {
		Collection attributes = new ArrayList();

		String sqlCatAttr = this.getSQLAttributesForName(catName, prefix,
				nsIndex, attrName);

		try {
			this.establishConnection(url, user, password);

			// for attributes
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlCatAttr);
			while (rs.next()) {
				String attrValue = rs.getString("value_xsd");
				if (!attributes.contains(attrValue)) {
					attributes.add(attrValue);
				}
			}

			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
		return attributes;
	}

	private Collection getRelationSet(String catName, int nsIndex,
			String prefix, String url, String user, String password) {
		Collection relations = new ArrayList();
		String sqlCatRel = this.getSQLRelations(catName, prefix, nsIndex);

		try {
			this.establishConnection(url, user, password);
			// for attributes
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlCatRel);
			while (rs.next()) {
				String relName = rs.getString("relation_title");
				if (!relations.contains(relName)) {
					relations.add(relName);
				}
			}
			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
		return relations;
	}

	private Collection getRelationValueSet(String catName, int nsIndex,
			String prefix, String url, String user, String password,
			String relName) {
		Collection relations = new ArrayList();
		String sqlCatRel = this.getSQLRelationsForName(catName, prefix,
				nsIndex, relName);

		try {
			this.establishConnection(url, user, password);
			// for attributes
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlCatRel);
			while (rs.next()) {
				int objNsIndex = rs.getInt("object_namespace");
				String objName = rs.getString("object_title");
				String objNsName = "";
				if (objNsIndex == 14) {
					objNsName = "Category:";
				}
				if (!relations.contains(objNsName + objName)) {
					relations.add(objNsName + objName);
				}
			}
			this.closeConnection();

		} catch (Exception e) {
			e.printStackTrace();

		}
		return relations;
	}

	private String getSQLAttributes(String sbjTitle, String prefix, int nsIndex) {
		String attrTable = prefix + "smw_attributes";
		String sqlAttributes = "SELECT * FROM " + attrTable
				+ " WHERE subject_namespace = '" + nsIndex + "' AND "
				+ "subject_title LIKE '" + sbjTitle + "'";

		return sqlAttributes;
	}

	private String getSQLAttributesForName(String sbjTitle, String prefix,
			int nsIndex, String attrName) {
		String attrTable = prefix + "smw_attributes";
		String sqlAttributes = "SELECT * FROM " + attrTable
				+ " WHERE subject_namespace = '" + nsIndex + "' AND "
				+ "subject_title LIKE '" + sbjTitle + "' AND "
				+ "attribute_title LIKE '" + attrName + "'";

		return sqlAttributes;
	}

	private String getSQLRelations(String sbjTitle, String prefix, int nsIndex) {
		String relTable = prefix + "smw_relations";
		String sqlRelations = "SELECT * FROM " + relTable
				+ " WHERE subject_namespace = '" + nsIndex + "' AND "
				+ "subject_title LIKE '" + sbjTitle + "'";

		return sqlRelations;
	}

	private String getSQLRelationsForName(String sbjTitle, String prefix,
			int nsIndex, String relName) {
		String relTable = prefix + "smw_relations";
		String sqlRelations = "SELECT * FROM " + relTable
				+ " WHERE subject_namespace = '" + nsIndex + "' AND "
				+ "subject_title LIKE '" + sbjTitle + "' AND "
				+ "relation_title LIKE '" + relName + "'";

		return sqlRelations;
	}

	private void establishConnection(String url, String user, String password) {
		try {
			Class.forName("org.gjt.mm.mysql.Driver").newInstance();

			con = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void closeConnection() {
		try {
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
