package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import edu.stanford.smi.protege.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;


//first implementation of new lexwiki templates
public class GenerateTemplateContentForICECI {
	
	//private String icd10amInclusion = "C:\\whoproject\\ICD10AM_full\\icd10am-includenotag.txt";
	//private String icd10amIncludes = "C:\\whoproject\\ICD10AM_full\\icd10am-includes.txt";
	//private String icd10amExcludes = "C:\\whoproject\\ICD10AM_full\\icd10am-excludes1.txt";
	
	//private String icd10Inclusion = "C:\\whoproject\\ICD10who_full\\icd10-includenotag.txt";
	//private String icd10Includes = "C:\\whoproject\\ICD10who_full\\icd10-includes.txt";
	//private String icd10Excludes = "C:\\whoproject\\ICD10who_full\\icd10-excludes1.txt";
	

	private Map superClasses = new HashMap();
	private Collection propertyNames = new ArrayList();
	private KnowledgeBase kb = null;
	
	public GenerateTemplateContentForICECI() {

	}

	public Map getSuperClasses() {
		return superClasses;
	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				vecCodeSystems.add(localName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}
	
	
	//this should be called before any loading
	public Collection getPropertyNames(){
		Collection ret = new ArrayList();
		for(Iterator it = propertyNames.iterator(); it.hasNext();){
			String propertyName = (String)it.next();
			String label = "Property:" + propertyName;
			String text = "[[has type::Type:String]]";
			SimpleArticle sa = new SimpleArticle();
			sa.setLabel(label);
			sa.setText(text);
			ret.add(sa);
		}
		
		return ret;
	}



	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
										

					sb.append(this.getHeaderBasicData());
					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getCodedEntryURI(entry, localName));
					
					sb.append(this.getTrailerBasicData());

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));
/*
					if(ns.equals("ICD10AM")){
						sb.append(this.getLexWikiInclusionTemplate(icd10amInclusion, code, ns));
						sb.append(this.getLexWikiIncludesTemplate(icd10amIncludes, code, ns));
						sb.append(this.getLexWikiExcludesTemplate(icd10amExcludes, code, ns));

					}
					
					if(ns.equals("ICD10")){
						sb.append(this.getLexWikiInclusionTemplate(icd10Inclusion, code, ns));
						sb.append(this.getLexWikiIncludesTemplate(icd10Includes, code, ns));
						sb.append(this.getLexWikiExcludesTemplate(icd10Excludes, code, ns));
						
					}
					
*/					
					sb.append(this.getTrailerProperties());

					
					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
/*
					if(ns.equals("ICD10AM")){
					    sb.append(this.getLexWikiExcludesAssociationTemplate(icd10amExcludes, code, localName, ns));
					}
					if(ns.equals("ICD10")){
						sb.append(this.getLexWikiExcludesAssociationTemplate(icd10Excludes, code, localName, ns));
					}
*/					
					sb.append(this.getTrailerAssoications());

					sb.append(this.getHeaderAssociationsGraph());

					//sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

                  sb.append(this.getTrailerAssociationsGraph());
					
					sb.append(this.getDefaultForm(ns));

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public Collection getContentForCodeSet(Collection codeSet,
			String localName, String ns) {
		
		Collection codeSetContents = new ArrayList();

		
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();

				if (codeSet.contains(code)) {
					StringBuffer sb = new StringBuffer();
					SimpleArticle sa = new SimpleArticle();
					sa.setLabel("Category:" + ns + " " + description +
							"(" + code + ")");
					

					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm(ns));

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));
					
					sa.setText(sb.toString());
					codeSetContents.add(sa);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codeSetContents;
	}	
	
	public String getContentForDebug(String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				sb.append(this.getCodedEntryAssociations(ref, localName, ns));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();

	}



	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {


		Collection allContents = new ArrayList();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
              String conceptLabel = "Category:" + this.mangle(ns + " " + description) + "(" + code
				+ ")";
              
				
				System.out.println(conceptLabel);
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel(conceptLabel);

				
				StringBuffer sb = new StringBuffer();

				// if (ns.equals("NCI") && code.startsWith("R")){
				sb.append(this.getHeaderBasicData());
				// sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(entry));

				// sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(entry));

				// sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName));

				// sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(entry));

				// sb.append("== Presentations ==\n");
				sb.append(this.getCodedEntryPresentations(entry, ns));

				sb.append(this.getCodedEntryURI(entry, localName));
				
				sb.append(this.getTrailerBasicData());

				sb.append(this.getHeaderProperties());

				// sb.append("== Concept Property ==\n");
				sb.append(this.getCodedEntryConceptProperty(entry, ns));

				// sb.append("== Comment ==\n");
				sb.append(this.getCodedEntryComment(entry));
/*
				if(ns.equals("ICD10AM")){
					sb.append(this.getLexWikiInclusionTemplate(icd10amInclusion, code, ns));
					sb.append(this.getLexWikiIncludesTemplate(icd10amIncludes, code, ns));
					sb.append(this.getLexWikiExcludesTemplate(icd10amExcludes, code, ns));

				}
				
				if(ns.equals("ICD10")){
					sb.append(this.getLexWikiInclusionTemplate(icd10Inclusion, code, ns));
					sb.append(this.getLexWikiIncludesTemplate(icd10Includes, code, ns));
					sb.append(this.getLexWikiExcludesTemplate(icd10Excludes, code, ns));
					
				}
*/				
				sb.append(this.getTrailerProperties());

				
				sb.append(this.getHeaderAssoications());

				// sb.append("== Associations ==\n");

				sb.append(this.getCodedEntryAssociations(ref,
							localName, ns));
/*
				if(ns.equals("ICD10AM")){
				    sb.append(this.getLexWikiExcludesAssociationTemplate(icd10amExcludes, code, localName, ns));
				}
				if(ns.equals("ICD10")){
					sb.append(this.getLexWikiExcludesAssociationTemplate(icd10Excludes, code, localName, ns));
				}
*/			
				sb.append(this.getTrailerAssoications());

				sb.append(this.getHeaderAssociationsGraph());

				// sb.append("== Associations Graph ==\n");
				sb.append(this.getCodedEntryAssociationsGraph(ref,
						localName, ns));

              sb.append(this.getTrailerAssociationsGraph());

				sb.append(this.getDefaultForm(ns));

				sb.append(this.getCodedEntryIncludeOnly(ref,
								localName, ns));

				sa.setText(sb.toString());
				allContents.add(sa);



			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			sb.append("{{LexWiki inScheme|" + codingScheme
					+ "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	
	private String getCodingSchemeName(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codingScheme;
	}
	private String getDefaultForm(String ns) {
		return "<noinclude>[[has default form::Form:LexWiki ICD10 Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "<noinclude>{{LexWiki Basic Data Header}}</noinclude>\n";
	}

	private String getTrailerBasicData() {
		return "<noinclude>{{LexWiki Basic Data Trailer}}</noinclude>\n";
	}

	private String getHeaderProperties() {
		return "<noinclude>{{LexWiki Concept Property Header}}</noinclude>\n";
	}

	private String getTrailerProperties() {
		return "<noinclude>{{LexWiki Concept Property Trailer}}</noinclude>\n";
	}

	private String getHeaderAssoications() {
		return "<noinclude>{{LexWiki Association Header}}</noinclude>\n";
	}

	private String getTrailerAssoications() {
		return "<noinclude>{{LexWiki Association Trailer}}</noinclude>\n";
	}

	private String getHeaderReferences() {
		return "<noinclude>{{LexWiki Reference Header}}</noinclude>\n";
	}

	private String getTrailerReferences() {
		return "<noinclude>{{LexWiki Reference Trailer}}</noinclude>\n";
	}

	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}

	private String getTrailerAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Trailer}}</noinclude>\n";
	}

	private String getCodedEntryCode(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryDescription(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		sb.append("{{LexWiki Preferred Name|"
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryURI(CodedEntry entry, String localName) {
		StringBuffer sb = new StringBuffer();
		String scheme = this.getCodingSchemeName(localName);
		String code = entry.getConceptCode();
		sb.append("{{LexWiki URI|"
				+ scheme + ":" + code + "}}\n");
		return sb.toString();

	}	
	
	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			if(ii==0){
			sb.append("{{LexWiki Definition|"
					+ entry.getDefinition(ii).getText().getContent() + "}}\n");
			}else{
				sb.append("{{LexWiki AltDefinition|"
						+ entry.getDefinition(ii).getText().getContent() + "}}\n");
				
			}
		}

		return sb.toString();

	}

	private String getCodedEntryPresentations(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String nsPropName = ns + "_" + propName;
			if(!propertyNames.contains(nsPropName))
			    propertyNames.add(nsPropName);
			String text = pres.getText().getContent();
			text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			
			
			//if (isPref) {
				// String attrName = "Has Preferred " + propName;
				//sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
						//+ "}}\n");
			//} else {
				// String fidelity = pres.getDegreeOfFidelity();
				// String attrName = "Has " + fidelity + " "
				// + propName;
				sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
						+ text + "}}\n");
			//}
		}

		return sb.toString();

	}

	private String getCodedEntryConceptProperty(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();

			if(!propertyNames.contains(cpName))
			    propertyNames.add(cpName);
			
			String cpText = cp.getText().getContent();
			if(cpName.indexOf("Relevant data elements") >= 0){
				String qualifier = cp.getPropertyQualifier(0).getContent();
				sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
						+ "|" + qualifier + "}}\n");
				
			}else{
			    sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
					+ "| }}\n");
			}
		}

		return sb.toString();
	}

	private String getCodedEntryComment(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|"
					+ entry.getComment(j).getText().getContent() + "}}\n");
		}

		return sb.toString();
	}



	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						System.out.println("sourceOf-assName:" + assName);
						if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if(ass.getDirectionalName() != null){
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("sourceOf-assDirecName:" + assDirectionalName);

						// do not need hasSubtype
						//if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
				
							 sb .append("{{LexWiki Association|" + ns + "_" +
							     assDirectionalName + "|" + ns + " " + this.mangle(assConcept
							     .getEntityDescription() .getContent()) + "(" +
							     assConcept.getConceptCode() + ")}}\n");

								if (assDirectionalName.equals("isA")) {
									isaIndex++;
									
									sb.append("<noinclude>{{LexWiki Parent|"
											+ ns
											+ " "
											+ this.mangle(assConcept.getEntityDescription()
													.getContent()) + "("
											+ assConcept.getConceptCode()
											+ ")}}</noinclude>\n");
	/*								
									sb.append("<noinclude>[[Category:"
											+ ns
											+ " "
											+ assConcept.getEntityDescription()
													.getContent() + "("
											+ assConcept.getConceptCode()
											+ ")]]</noinclude>\n");
	*/
								}
						}
														 
							
					}
				}
				 }
				//}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						System.out.println("targetof-assName:" + assName);
						
						//if(!assName.equals("RO")){
						String assDirectionalName = assName;
						if (ass.getDirectionalName() != null) {
							assDirectionalName = ass.getDirectionalName();
						}
						System.out.println("targetof-assDirectionalName:" + assDirectionalName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
/*
							sb.append("{{LexWiki Inverse Association|"
									+ ns
									+ "_"
									+ assDirectionalName
									+ "|"
									+ ns
									+ " "
									+ this.mangle(assConcept.getEntityDescription().getContent()) + "("
									+ assConcept.getConceptCode() + ")}}\n");
*/
							

							if (assDirectionalName.equals("isA")) {
								isaIndex++;
								
								sb.append("<noinclude>{{LexWiki Parent|"
										+ ns
										+ " "
										+ this.mangle(assConcept.getEntityDescription()
												.getContent()) + "("
										+ assConcept.getConceptCode()
										+ ")}}</noinclude>\n");

/*								
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
*/
							}
						}
						}
					}
				}
			//}



				if (isaIndex == 0) {
					sb.append("<noinclude>{{LexWiki Parent|" + localName
							+ "}}</noinclude>\n");

/*					
					sb.append("<noinclude>[[Category:" + localName
							+ "]]</noinclude>\n");
*/
				}

			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");
		

		String thisConcept = "Category:" + ns + "_" + this.mangle(thisConceptName) + "("
				+ ref.getConceptCode() + ")";
		
		//thisConcept = this.mangle(thisConcept);

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						//if (!assName.equals("hasSubtype")) {
						String assDirectionalName = assName;
						if(ass.getDirectionalName() != null){
							assDirectionalName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");
							thisAssEntityDescription = this.mangle(thisAssEntityDescription);
							
							sb.append("[ " + thisConcept + "] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
							   assDirectionalName + " --> {link:Relation:" +
							   ns + "_" + assDirectionalName + "; start: front, 0; } " + " [ Category:" + thisAssEntityDescription + "(" +
							   assConcept.getConceptCode() + ") ] " + "{ fill:3; link: Category:" + thisAssEntityDescription +
							   "(" + assConcept.getConceptCode() + "); }" +
							   "\n");
							 
						}

					}
				//}
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDirectionalName = assName;
						if(ass.getDirectionalName() != null){
							assDirectionalName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription().getContent().replaceAll(" ", "_");
							thisAssEntityDescription = this.mangle(thisAssEntityDescription);

							
/*						
							sb.append("[ " + thisConcept + "] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assDirectionalName
									+ " --> {link:Relation:" + ns + "_"
									+ assDirectionalName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");
*/
						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + " " + this.mangle(thisConceptName) + "("
				+ ref.getConceptCode() + ")";

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}
	
	private String getLexWikiInclusionTemplate(String fileName, String code, String ns){
		StringBuffer sb = new StringBuffer();
		BufferedReader br;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while(line != null){
				String[] items = line.split("\\|");
				if(items.length >= 2 && items[0].equals(code)){
					System.out.println("enter2:" + code);
				    sb.append("{{LexWiki Concept Property|" + ns + "_Has_Inclusion" + "|" + this.mangle(items[1]) + "}}\n");
				}
				line = br.readLine();				
			}
			br.close();
		}catch(IOException ie){
			
		}
		
		return sb.toString();
	}
	
	private String getLexWikiIncludesTemplate(String fileName, String code, String ns){
		StringBuffer sb = new StringBuffer();
		BufferedReader br;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while(line != null){
				String[] items = line.split("\\|");
				if(items.length >= 2 && items[0].equals(code)){
				    sb.append("{{LexWiki Concept Property|" + ns + "_Includes" + "|" + this.mangle(items[1]) + "}}\n");
				}
				line = br.readLine();				
			}
			br.close();
		}catch(IOException ie){
			
		}
		
		return sb.toString();
	}	
	
	private String getLexWikiExcludesTemplate(String fileName, String code, String ns){
		StringBuffer sb = new StringBuffer();
		BufferedReader br;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while(line != null){
				String[] items = line.split("\\|");
				if(items.length >= 2 && items[0].equals(code)){
				    sb.append("{{LexWiki Concept Property|" + ns + "_Excludes" + "|" + this.mangle(items[1]) + "}}\n");
				}
				
				line = br.readLine();
				
			}
			br.close();
		}catch(IOException ie){
			
		}
		
		return sb.toString();
	}		

	private String getLexWikiExcludesAssociationTemplate(String fileName, String code, String localName, String ns){
		StringBuffer sb = new StringBuffer();
		BufferedReader br;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while(line != null){
				String[] items = line.split("\\|");
				if(items.length >= 2 && items[0].equals(code)){
					Collection colExcludes = this.getCodesFromExcludes(items[1]);
					for(Iterator it = colExcludes.iterator(); it.hasNext();){
						String codeExclude = (String) it.next();
						String lwName = this.getLexWikiNameForConceptCode(codeExclude, localName, ns);
						if(lwName != null){
						    sb.append("{{LexWiki Association|" + ns + "_Excludes" + "|" + lwName + "}}\n");
						}else{
						    sb.append("{{LexWiki Association|" + ns + "_Excludes" + "|" + this.mangle(items[1]) + "}}\n");
							
						}
					}
				}
				line = br.readLine();				
			}
			br.close();
		}catch(IOException ie){
			
		}
		
		return sb.toString();
	}

	private String getLexWikiNameForConceptCode(String conceptCode,
			String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { conceptCode },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(conceptCode)) {
					String description = entry.getEntityDescription().getContent();
	                String conceptLabel = this.mangle(ns + " " + description) + "(" + code
					+ ")";
	                sb.append(conceptLabel);
	                break;
					
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return sb.toString();
 }

	
	private Collection getCodesFromExcludes(String content){
		Collection colCodes = new ArrayList();
		int index1 = content.indexOf("(");
		int index2 = content.indexOf(")");
		String strContent = content.substring(index1+1, index2);
		String [] strCodes = strContent.split(",");
		for(int i = 0; i < strCodes.length; i++){
			String strCode = strCodes[i];
			if(strCode.endsWith(".-")){
				strCode = strCode.substring(0, strCode.length()-2);
				colCodes.add(strCode);
			}else if(strCode.endsWith("-") || strCode.endsWith("_")){
				strCode = strCode.substring(0, strCode.length()-1);
				colCodes.add(strCode);			    
			}else{
				//This needs further parsing
				colCodes.add(strCode);
			}
		}
		
		return colCodes;
	}
		
	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		//lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		// 3) Remove leading and trailing "_"
		lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");
		
		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}



}

