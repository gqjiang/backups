package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;

public class GenerateTemplateContentForNCITOwl {

	private Map superClasses = new HashMap();
	private Collection allContents;
	private Collection anonymousNodes = new ArrayList();
	private Collection nestedAnonNodes = new ArrayList();
	public GenerateTemplateContentForNCITOwl() {

	}

	public Map getSuperClasses() {
		return superClasses;
	}
	
	public int getAnonymousNodesNumber(){
		return anonymousNodes.size();
	}
	
	public Collection getNestedAnonNodes(){
		return nestedAnonNodes;
	}

	public Object[] getAvailableCodeSystems() {

		Vector vecCodeSystems = new Vector();

		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String localName = csrs[i].getCodingSchemeSummary()
						.getLocalName();
				vecCodeSystems.add(localName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Object[]) vecCodeSystems.toArray();
	}

	public CodedNodeSet getCodedNodeSet(String localName) {
		CodedNodeSet cns = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cns = lbs
							.getCodingSchemeConcepts(
									csr.getCodingSchemeSummary()
											.getCodingSchemeURN(),
									Constructors
											.createCodingSchemeVersionOrTagFromVersion(csr
													.getCodingSchemeSummary()
													.getRepresentsVersion()));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cns;
	}

	public CodedNodeGraph getCodedNodeGraph(String localName) {
		CodedNodeGraph cng = null;
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();
			for (int i = 0; i < csrs.length; i++) {
				CodingSchemeRendering csr = csrs[i];
				if (csr.getCodingSchemeSummary().getLocalName().equals(
						localName)) {

					cng = lbs.getNodeGraph(csr.getCodingSchemeSummary()
							.getCodingSchemeURN(), Constructors
							.createCodingSchemeVersionOrTagFromVersion(csr
									.getCodingSchemeSummary()
									.getRepresentsVersion()), null);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cng;
	}

	public Object[] getAllConceptCodes(String localName) {

		Vector ret = new Vector();
		try {

			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();
				ret.add(code + "|" + description);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Object[] result = ret.toArray();
		Arrays.sort(result);

		return result;
	}



	public String getContentForConceptCode(String conceptCode,
			String localName, String ns) {

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
										

					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm());

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	public Collection getContentForCodeSet(Collection codeSet,
			String localName, String ns) {
		
		Collection codeSetContents = new ArrayList();

		
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();

				if (codeSet.contains(code)) {
					StringBuffer sb = new StringBuffer();
					SimpleArticle sa = new SimpleArticle();
					sa.setLabel("Category:" + ns + " " + description +
							"(" + code + ")");
					
                    //System.out.println("Category:" + ns + " " + description +
					//		"(" + code + ")");
					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm());

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));
					
					sa.setText(sb.toString());
					codeSetContents.add(sa);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codeSetContents;
	}		
	
	public Map getAssociationContentForCodeSet(Collection codeSet,
			String localName, String ns) {
		
		Map codeSetContents = new HashMap();

		
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
				String description = entry.getEntityDescription().getContent();

				if (codeSet.contains(code)) {
                    Collection sourceAsses = this.getCodedEntrySourceAssociations(ref, localName, ns);
				    codeSetContents.put(code, sourceAsses);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return codeSetContents;
	}		
	
	public Collection getContentArticleForConceptCode(String conceptCode,
			String localName, String ns) {
		
		allContents = new ArrayList();

		String[] pairs = conceptCode.split("\\|");
		String code_ = pairs[0];
		String description_ = pairs[1];

		System.out.println(code_ + "|" + description_);
		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);

			ConceptReferenceList crefs = ConvenienceMethods
					.createConceptReferenceList(new String[] { code_ },
							localName);

			cns.restrictToCodes(crefs);

			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();

				CodedEntry entry = ref.getReferencedEntry();

				String code = entry.getConceptCode();

				if (code.equals(code_)) {
					String descrip = entry.getEntityDescription().getContent();
										
                    SimpleArticle sa = new SimpleArticle();
                    sa.setLabel("Category:" + ns + " " + description_ + "(" + code_ + ")");
                    
					sb.append(this.getHeaderBasicData());

					// sb.append("== Coding Scheme ==\n");
					sb.append(this.getCodingScheme(localName));

					// sb.append("== Concept Code ==\n");
					sb.append(this.getCodedEntryCode(entry));

					// sb.append("== Entity Description ==\n");
					sb.append(this.getCodedEntryDescription(entry));

					// sb.append("== Definition ==\n");
					sb.append(this.getCodedEntryDefinition(entry));

					// sb.append("== Presentations ==\n");
					sb.append(this.getCodedEntryPresentations(entry, ns));

					sb.append(this.getHeaderProperties());

					// sb.append("== Concept Property ==\n");
					sb.append(this.getCodedEntryConceptProperty(entry, ns));

					// sb.append("== Comment ==\n");
					sb.append(this.getCodedEntryComment(entry));

					sb.append(this.getHeaderAssoications());

					// sb.append("== Associations ==\n");

					sb.append(this.getCodedEntryAssociations(ref,
								localName, ns));
					

					sb.append(this.getHeaderAssociationsGraph());

					// sb.append("== Associations Graph ==\n");
					sb.append(this.getCodedEntryAssociationsGraph(ref,
							localName, ns));

					sb.append(this.getDefaultForm());

					sb.append(this.getCodedEntryIncludeOnly(ref,
									localName, ns));
					
					sa.setText(sb.toString());
					allContents.add(sa);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}
	

	public String getContentForAnonymousConceptCode(ResolvedConceptReference ref,
			String localName, String ns, ResolvedConceptReference origRef) {

            StringBuffer sb = new StringBuffer();

			CodedEntry entry = ref.getReferencedEntry();

			String code = entry.getConceptCode();
										

			sb.append(this.getHeaderBasicData());

			// sb.append("== Coding Scheme ==\n");
			sb.append(this.getCodingScheme(localName));

			// sb.append("== Concept Code ==\n");
			sb.append(this.getCodedEntryCode(entry));

			// sb.append("== Entity Description ==\n");
			sb.append(this.getCodedEntryDescription(entry));

			// sb.append("== Definition ==\n");
			sb.append(this.getCodedEntryDefinition(entry));

			// sb.append("== Presentations ==\n");
			sb.append(this.getCodedEntryPresentations(entry, ns));

			sb.append(this.getHeaderProperties());

			// sb.append("== Concept Property ==\n");
			sb.append(this.getCodedEntryConceptProperty(entry, ns));

			// sb.append("== Comment ==\n");
			sb.append(this.getCodedEntryComment(entry));

			sb.append(this.getHeaderAssoications());

			// sb.append("== Associations ==\n");

			sb.append(this.getCodedEntryAssociationsForAnonymousNode(ref, localName, ns, origRef));
					

			sb.append(this.getHeaderAssociationsGraph());

			// sb.append("== Associations Graph ==\n");
			sb.append(this.getCodedEntryAssociationsGraphForAnonymousNode(ref, localName, ns, origRef));

			sb.append(this.getDefaultFormForAnonymousNode());

			sb.append(this.getCodedEntryIncludeOnlyForAnonymousNode(ref, localName, ns));


		return sb.toString();
	}
	
	
	public String getContentForDebug(String localName, String ns) {

		StringBuffer sb = new StringBuffer();
		try {
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();

				String description = entry.getEntityDescription().getContent();
				sb.append(this.getCodedEntryAssociations(ref, localName, ns));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();

	}



	public Collection getContentForConceptCodeForBatchExport(String localName,
			String ns) {
        allContents = new ArrayList();

    
		try {
			int index = 1;
			CodedNodeSet cns = this.getCodedNodeSet(localName);
			ResolvedConceptReferencesIterator rcrIt = cns.resolve(null, null,
					null);
			while (rcrIt.hasNext()) {
				ResolvedConceptReference ref = (ResolvedConceptReference) rcrIt
						.next();
				CodedEntry entry = ref.getReferencedEntry();
				String code = entry.getConceptCode();
                System.out.println("code:" + code + " | loop at: " + index++);
				String description = entry.getEntityDescription().getContent();
              String conceptLabel = "Category:" + ns + " " + description + "(" + code
				+ ")";
            
				
                //we do not need concept code for attributes and relations
				//if(ns.equals("NCI1")){
				if(code.startsWith("P") ||
							code.startsWith("R")){
						conceptLabel = "Category:" + ns + " " + description;
		                //System.out.println("code:" + code + " | loop at: " + index++);
					
				}
				
				//normalization
				conceptLabel = conceptLabel.replaceAll("\\[", "(");
				conceptLabel = conceptLabel.replaceAll("\\]", ")");
				//System.out.println("Category:" + ns + " " + description + "("
				//		+ code + ")");
					
				//if(code.startsWith("C")){	
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel(conceptLabel);

				
				StringBuffer sb = new StringBuffer();

				// if (ns.equals("NCI") && code.startsWith("R")){
				sb.append(this.getHeaderBasicData());

				// sb.append("== Coding Scheme ==\n");
				sb.append(this.getCodingScheme(localName));

				// sb.append("== Concept Code ==\n");
				sb.append(this.getCodedEntryCode(entry));

				// sb.append("== Entity Description ==\n");
				sb.append(this.getCodedEntryDescription(entry));

				// sb.append("== Definition ==\n");
				sb.append(this.getCodedEntryDefinition(entry));

				// sb.append("== Presentations ==\n");
				sb.append(this.getCodedEntryPresentations(entry, ns));

				sb.append(this.getHeaderProperties());

				// sb.append("== Concept Property ==\n");
				sb.append(this.getCodedEntryConceptProperty(entry, ns));

				// sb.append("== Comment ==\n");
				sb.append(this.getCodedEntryComment(entry));

				sb.append(this.getHeaderAssoications());

				// sb.append("== Associations ==\n");


				sb.append(this
							.getCodedEntryAssociations(ref, localName, ns));
				
				sb.append(this.getHeaderAssociationsGraph());

				// sb.append("== Associations Graph ==\n");
				sb.append(this.getCodedEntryAssociationsGraph(ref, localName,
						ns));

				sb.append(this.getDefaultForm());

				sb.append(this.getCodedEntryIncludeOnly(ref, localName, ns));

				sa.setText(sb.toString());
				allContents.add(sa);

				// special for NCI attributes and relations
				//if (ns.equals("NCI1")) {
					if (code.startsWith("P")) {
						SimpleArticle saAttr = new SimpleArticle();
						saAttr.setLabel("Attribute:" + ns + "_" + description);
						StringBuffer sbAttr = new StringBuffer();
						sbAttr.append("#REDIRECT [[:Category:" + ns + "_"
								+ description + "]]\n");
						sbAttr.append("[[has type::Type:String]]");
						saAttr.setText(sbAttr.toString());
						allContents.add(saAttr);
					}

					if (code.startsWith("R")) {
						SimpleArticle saRel = new SimpleArticle();
						saRel.setLabel("Relation:" + ns + "_" + description);
						StringBuffer sbRel = new StringBuffer();
						sbRel.append("#REDIRECT [[:Category:" + ns + "_"
								+ description + "]]\n");
						saRel.setText(sbRel.toString());
						allContents.add(saRel);

					}
				}
			

			//}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allContents;
	}

	private String getCodingScheme(String localName) {
		StringBuffer sb = new StringBuffer();
		String codingScheme = "";
		try {

			LexBIGService lbs = new LexBIGServiceImpl();

			CodingSchemeRenderingList schemes = lbs.getSupportedCodingSchemes();
			CodingSchemeRendering[] csrs = schemes.getCodingSchemeRendering();

			for (int i = 0; i < csrs.length; i++) {
				String name = csrs[i].getCodingSchemeSummary().getLocalName();
				if (name.equals(localName)) {
					codingScheme = // localName
					// + " - "
					// +
					csrs[i].getCodingSchemeSummary().getCodingSchemeURN();
					break;
				}
			}

			sb.append("{{LexWiki Coding Scheme|Coding Scheme=" + codingScheme
					+ "}}\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getDefaultForm() {
		return "<noinclude>[[has default form::Form:LexWiki Form]]</noinclude>\n";
	}
	
	
	private String getDefaultFormForAnonymousNode() {
		return "<noinclude>[[has default form::Form:LexWiki AnonymousNode Form]]</noinclude>\n";
	}
	
	
	private String getHeaderBasicData() {
		return "{{LexWiki Basic Data Header}}\n";
	}

	private String getHeaderProperties() {
		return "{{LexWiki Concept Property Header}}\n";
	}

	private String getHeaderAssoications() {
		return "{{LexWiki Association Header}}\n";
	}

	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}

	private String getCodedEntryCode(CodedEntry entry) {

		StringBuffer sb = new StringBuffer();
		String code = entry.getConceptCode();
		sb.append("{{LexWiki Concept Code|Concept Code=" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryDescription(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		String description = entry.getEntityDescription().getContent();
		sb.append("{{LexWiki Entity Description|Entity Description="
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryDefinition(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int dIndex = entry.getDefinitionCount();
		for (int ii = 0; ii < dIndex; ii++) {
			sb.append("{{LexWiki Definition|Definition="
					+ entry.getDefinition(ii).getText().getContent() + "}}\n");
		}

		return sb.toString();

	}

	private String getCodedEntryPresentations(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int pIndex = entry.getPresentationCount();
		for (int ip = 0; ip < pIndex; ip++) {
			Presentation pres = entry.getPresentation(ip);
			String propName = pres.getProperty();
			String text = pres.getText().getContent();
			text = text.replaceAll("\"", "");
			boolean isPref = pres.getIsPreferred();
			if (isPref) {
				// String attrName = "Has Preferred " + propName;
				sb.append("{{LexWiki Preferred Name|Preferred Name=" + text
						+ "}}\n");
			} else {
				// String fidelity = pres.getDegreeOfFidelity();
				// String attrName = "Has " + fidelity + " "
				// + propName;
				sb.append("{{LexWiki Presentation|" + ns + "_" + propName + "|"
						+ text + "}}\n");
			}
		}

		return sb.toString();

	}

	private String getCodedEntryConceptProperty(CodedEntry entry, String ns) {
		StringBuffer sb = new StringBuffer();
		int cpIndex = entry.getConceptPropertyCount();
		for (int cpi = 0; cpi < cpIndex; cpi++) {
			ConceptProperty cp = entry.getConceptProperty(cpi);
			String cpName = ns + "_" + cp.getProperty();
			String cpText = cp.getText().getContent();
			sb.append("{{LexWiki Concept Property|" + cpName + "|" + cpText
					+ "}}\n");
		}

		return sb.toString();
	}

	private String getCodedEntryComment(CodedEntry entry) {
		StringBuffer sb = new StringBuffer();
		int cIndex = entry.getCommentCount();
		for (int j = 0; j < cIndex; j++) {
			sb.append("{{LexWiki Comment|Comment="
					+ entry.getComment(j).getText().getContent() + "}}\n");
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsForAnonymousNode(ResolvedConceptReference ref,
			String localName, String ns, ResolvedConceptReference origRef) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			String origCode = origRef.getConceptCode();
			String origDesp = origRef.getEntityDescription().getContent();
			
			
			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						//System.out.println(assName);
						//System.out.println(ass.getDirectionalName());

						// do not need hasSubtype

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							
							if(assConcept.getEntityDescription() != null){
							String assConceptCode = assConcept.getConceptCode();
							if(assConceptCode.startsWith("A")){

								//SimpleArticle sa = new SimpleArticle();
								//sa.setLabel("Category:" + ns + " " + assConcept.getConceptCode());
								//sa.setText(this.getContentForAnonymousConceptCode((ResolvedConceptReference)assConcept, localName, ns, ref));
		                        //allContents.add(sa);
		                        //if(!anonymousNodes.contains(sa))
		                        //    anonymousNodes.add(sa);
								
								
								sb .append("{{LexWiki Association|" + ns + "_" +
									     assName + "|" + ns + " " +
									     assConcept.getConceptCode() + "}}\n");	
								if(!anonymousNodes.contains(assConcept.getConceptCode())){
									anonymousNodes.add(assConcept.getConceptCode());
								}
								if(!nestedAnonNodes.contains(assConcept.getConceptCode())){
									nestedAnonNodes.add(origCode + "|" + assConcept.getConceptCode());
								}
								 
								
							}else{
							 sb .append("{{LexWiki Association|" + ns + "_" +
							     assName + "|" + ns + " " + assConcept
							     .getEntityDescription() .getContent() + "(" +
							     assConcept.getConceptCode() + ")}}\n");							 
							}
							}
					}
				}
				 }
				
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();


						//System.out.println("targetof:" + assName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							
							if(assConcept.getEntityDescription() != null){
							
							String assConceptCode = assConcept.getConceptCode();
							if(assConceptCode.startsWith("A")){

								//SimpleArticle sa = new SimpleArticle();
								//sa.setLabel("Category:" + ns + " " + assConcept.getConceptCode());
								//sa.setText(this.getContentForAnonymousConceptCode((ResolvedConceptReference)assConcept, localName, ns, ref));
		                        //allContents.add(sa);
		                        //if(!anonymousNodes.contains(sa))
		                        //    anonymousNodes.add(sa);
								
								
								sb .append("{{LexWiki Association|" + ns + "_" +
									     assName + "|" + ns + " " +
									     assConcept.getConceptCode() + "}}\n");	
								 
								if(!anonymousNodes.contains(assConcept.getConceptCode())){
									anonymousNodes.add(assConcept.getConceptCode());
								}
								
								if(!nestedAnonNodes.contains(assConcept.getConceptCode())){
									nestedAnonNodes.add(origCode + "|" + assConcept.getConceptCode());
								}	
							}else{                             
							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assName
									+ "|"
									+ ns
									+ " "
									+ assConcept.getEntityDescription()
											.getContent() + "("
									+ assConcept.getConceptCode() + ")}}\n");
							}
							}
						}
					}
				}
			}

			sb.append("<noinclude>{{LexWiki Association|"
					+ ns
					+ "_"
					+ "anonymousNodeOf"
					+ "|"
					+ ns
					+ " "
					+ origDesp + "("
					+ origCode + ")}}</noinclude>\n");
     
			sb.append("<noinclude>[[Category:" + ns + " " + "Anonymous Nodes"
							+ "]]</noinclude>\n");
			

			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociations_bakforanon(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						//System.out.println(assName);
						//System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
					    	if(assConcept.getEntityDescription() != null){							
							
						    if(!assConceptCode.startsWith("A")){
//							if(!((ResolvedConceptReference)assConcept).getReferencedEntry().getIsAnonymous()){				

						    	sb .append("{{LexWiki Association|" + ns + "_" +
							     assName + "|" + ns + " " + assConcept
							     .getEntityDescription() .getContent() + "(" +
							     assConcept.getConceptCode() + ")}}\n");
						    	
							 
							}else{
//								//add the anonymous node to an article container
								SimpleArticle sa = new SimpleArticle();
								sa.setLabel("Category:" + ns + " " + assConcept.getConceptCode());
								sa.setText(this.getContentForAnonymousConceptCode((ResolvedConceptReference)assConcept, localName, ns, ref));
		                        //allContents.add(sa);
		                        if(!anonymousNodes.contains(assConcept.getConceptCode()))
		                            anonymousNodes.add(assConcept.getConceptCode());

		                        
		                        sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assName
									+ "|"
									+ ns
									+ " " + assConceptCode+ "}}\n");
							}
					    	}
							
					}
				}
				 }
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						//System.out.println("targetof:" + assName);
						//System.out.println("targetof:"
								//+ ass.getDirectionalName());
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}
						//System.out.println("targetof:" + assName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
							
							if(assConcept.getEntityDescription() != null){
						    if(!assConceptCode.startsWith("A")){
//						    if(!((ResolvedConceptReference)assConcept).getReferencedEntry().getIsAnonymous()){				
							
							sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assDisplayName
									+ "|"
									+ ns
									+ " "
									+ assConcept.getEntityDescription()
											.getContent() + "("
									+ assConcept.getConceptCode() + ")}}\n");
							}else{
								//add the anonymous node to an article container
								SimpleArticle sa = new SimpleArticle();
								sa.setLabel("Category:" + ns + " " + assConcept.getConceptCode());
								sa.setText(this.getContentForAnonymousConceptCode((ResolvedConceptReference)assConcept, localName, ns, ref));
		                        //allContents.add(sa);
		                        if(!anonymousNodes.contains(assConcept.getConceptCode()))
		                            anonymousNodes.add(assConcept.getConceptCode());
		                        
		                        sb.append("{{LexWiki Association|"
									+ ns
									+ "_"
									+ assDisplayName
									+ "|"
									+ ns
									+ " " + assConceptCode+ "}}\n");
							}
							

							if (assDisplayName.equals("isA")) {
								isaIndex++;
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
							}
							}
						}
					}
				}
			}

			String code = ref.getConceptCode();

			// different groups of NCI concepts
			//if (ns.equals("NCI1")) {
				if (code.startsWith("K")) {
					sb.append("<noinclude>[[Category:" + "NCI1 Kind"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("A")) {
					sb.append("<noinclude>[[Category:" + "NCI1 MetaA"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("P")) {
					sb.append("<noinclude>[[Category:" + "NCI1 Property"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("R")) {
					sb.append("<noinclude>[[Category:" + "NCI1 Relation"
							+ "]]</noinclude>\n");

				} else if (isaIndex == 0) {
					sb.append("<noinclude>[[Category:" + ns + " " + localName
							+ "]]</noinclude>\n");
				}
			//} //else {
				//if (isaIndex == 0) {
					//sb.append("<noinclude>[[Category:" + localName
							//+ "]]</noinclude>\n");
				//}

			//}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	private Collection getCodedEntrySourceAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		Collection ret = new ArrayList();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						
						String directionalName = assName;
						if(ass.getDirectionalName() != null){
							directionalName = ass.getDirectionalName();
						}
						ret.add(assName + "|" + directionalName);
						

				 }
				}
			}
					
	
			} catch (Exception e) {
				e.printStackTrace();
			}

			return ret;
		}
	
	private String getCodedEntryAssociations(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						//System.out.println(assName);
						//System.out.println(ass.getDirectionalName());

						// do not need hasSubtype
						if (!assName.equals("hasSubtype")) {
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
					    	if(assConcept.getEntityDescription() != null){							
							
						    if(!assConceptCode.startsWith("A")){
						    	sb .append("{{LexWiki Association|" + ns + "_" +
							     assName + "|" + ns + " " + assConcept
							     .getEntityDescription() .getContent() + "(" +
							     assConcept.getConceptCode() + ")}}\n");
						    	
							 
							}
						    

					    	}
							
					}
				}
				 }
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];

						String assName = ass.getAssociationName();
						//System.out.println("targetof:" + assName);
						//System.out.println("targetof:"
								//+ ass.getDirectionalName());
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}
						//System.out.println("targetof:" + assName);
						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
							String assConceptCode = assConcept.getConceptCode();
							
							if(assConcept.getEntityDescription() != null){
							

							if (assDisplayName.equals("isA")) {
								isaIndex++;

						    	sb .append("{{LexWiki Association|" + ns + "_" +
									     assDisplayName + "|" + ns + " " + assConcept
									     .getEntityDescription() .getContent() + "(" +
									     assConcept.getConceptCode() + ")}}\n");
			
								
								sb.append("<noinclude>[[Category:"
										+ ns
										+ " "
										+ assConcept.getEntityDescription()
												.getContent() + "("
										+ assConcept.getConceptCode()
										+ ")]]</noinclude>\n");
							}
							}
						}
					}
				}
			}

			String code = ref.getConceptCode();

				if (code.startsWith("K")) {
					sb.append("<noinclude>[[Category:" + "NCI1 Kind"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("A")) {
					sb.append("<noinclude>[[Category:" + "NCI1 MetaA"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("P")) {
					sb.append("<noinclude>[[Category:" + "NCI1 Property"
							+ "]]</noinclude>\n");
				} else if (code.startsWith("R")) {
					sb.append("<noinclude>[[Category:" + "NCI1 Disease Model"
							+ "]]</noinclude>\n");

				} else if (isaIndex == 0) {
					sb.append("<noinclude>[[Category:" + ns + " " + localName
							+ "]]</noinclude>\n");
				}


		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryAssociationsGraphForAnonymousNode(ResolvedConceptReference ref,
			String localName, String ns, ResolvedConceptReference origRef) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");


		String thisConcept = "Category:" + ns + "_" + ref.getConceptCode();

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
                            if(assConcept.getEntityDescription() != null){
    							if(assConcept.getConceptCode().startsWith("A")){
    								sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
    										   assName + " --> {link:Relation:" +
    										   ns + "_" + assName + "; start: front, 0; } " + " [ Category:" + ns + "_" +
    										   assConcept.getConceptCode() + " ] " + "{ fill:3; link: Category:" + ns + "_"
    										   + assConcept.getConceptCode() + "; }" +
    										   "\n");    								
    							}else{
    								String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");

							
							sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
							   assName + " --> {link:Relation:" +
							   ns + "_" + assName + "; start: front, 0; } " + " [ Category:" + thisAssEntityDescription + "(" +
							   assConcept.getConceptCode() + ") ] " + "{ fill:3; link: Category:" + thisAssEntityDescription +
							   "(" + assConcept.getConceptCode() + "); }" +
							   "\n");
                            }
                            }
						}

					}
				}
				
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
                            if(assConcept.getEntityDescription() != null){
    							if(assConcept.getConceptCode().startsWith("A")){
    								sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
    										   assName + " --> {link:Relation:" +
    										   ns + "_" + assName + "; start: front, 0; } " + " [ Category:" + ns + "_" +
    										   assConcept.getConceptCode() + " ] " + "{ fill:3; link: Category:" + ns + "_"
    										   + assConcept.getConceptCode() + "; }" +
    										   "\n");    								
    							}else{
                            	String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");

							sb.append("[ " + thisConcept + " ] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assName
									+ " --> {link:Relation:" + ns + "_"
									+ assName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");

						    }
                            }
						}

					}
				}
			}

			String origCode = origRef.getConceptCode();
			String origDesp = origRef.getEntityDescription().getContent();

			sb.append("[ " + thisConcept + " ] "
					+ "{ fill: 5; link:" + thisConcept + "; } "
					+ "-- " + "anonymousNodeOf"
					+ " --> {link:Relation:" + ns + "_"
					+ "anonymousNodeOf" + "; start: front, 0; } "
					+ " [ Category:" + origDesp
					+ "(" + origCode
					+ ") ] " + "{ fill: 4 ; link: Category:"
					+ origDesp + "("
					+ origCode + "); }"
					+ "\n");			
			
			
			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	private String getCodedEntryAssociationsGraph_bakforannon(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + "_" + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("hasSubtype")) {

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
                            if(assConcept.getEntityDescription() != null){
							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");
							if(assConcept.getConceptCode().startsWith("A")){
								sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
										   ass.getDirectionalName() + " --> {link:Relation:" +
										   ns + "_" + assName + "; start: front, 0; } " + " [ Category:" + ns + " " +
										   assConcept.getConceptCode() + " ] " + "{ fill:3; link: Category:" + ns +
										   "_" + assConcept.getConceptCode() + "; }" +
										   "\n");					
							}else{
							
							sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
							   ass.getDirectionalName() + " --> {link:Relation:" +
							   ns + "_" + assName + "; start: front, 0; } " + " [ Category:" + thisAssEntityDescription + "(" +
							   assConcept.getConceptCode() + ") ] " + "{ fill:3; link: Category:" + thisAssEntityDescription +
							   "(" + assConcept.getConceptCode() + "); }" +
							   "\n");
							}
                            }
							 
						}

					}
				}
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							//String thisAssEntityDescription = "";
							if(assConcept.getEntityDescription() != null){
							  String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
									.getContent().replaceAll(" ", "_");
						
							if(assConcept.getConceptCode().startsWith("A")){
								sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
										   assDisplayName + " --> {link:Relation:" +
										   ns + "_" + assDisplayName + "; start: front, 0; } " + " [ Category:" + ns + " " +
										   assConcept.getConceptCode() + " ] " + "{ fill:4; link: Category:" + ns +
										   "_" + assConcept.getConceptCode() + "; }" +
										   "\n");					
							}else{											

							sb.append("[ " + thisConcept + " ] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assDisplayName
									+ " --> {link:Relation:" + ns + "_"
									+ assDisplayName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");
							}
							}

						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}
	
	private String getCodedEntryAssociationsGraph(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();
		sb.append("<noinclude><graph>\n");

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + "_" + thisConceptName + "("
				+ ref.getConceptCode() + ")";
		
		//normalization
		thisConcept = thisConcept.replaceAll("\\[", "(");
		thisConcept = thisConcept.replaceAll("\\]", ")");

		try {
			CodedNodeGraph cng = this.getCodedNodeGraph(localName);

			ResolvedConceptReferenceList refList = cng.resolveAsList(
					Constructors.createConceptReference(ref.getConceptCode(),
							ref.getCodingSchemeURN()), true, true, 1, 1, null,
					null, null, 0);
			ResolvedConceptReference[] refGraphes = refList
					.getResolvedConceptReference();

			// to detect if there is a super concept for this code.
			int isaIndex = 0;
			for (int h = 0; h < refGraphes.length; h++) {

				ResolvedConceptReference refGraph = refGraphes[h];

				AssociationList aListSource = refGraph.getSourceOf();
				if (aListSource != null) {
					Association[] asses = aListSource.getAssociation();
					for (int js = 0; js < asses.length; js++) {
						// while(aListSource != null &&
						// aListSource.enumerateAssociation().hasMoreElements()){
						Association ass = asses[js];
						String assName = ass.getAssociationName();
						if (!assName.equals("hasSubtype")) {

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];
                            if(assConcept.getEntityDescription() != null){
							String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
											.getContent().replaceAll(" ", "_");
							
							thisAssEntityDescription = thisAssEntityDescription.replaceAll("\\[", "(");
							thisAssEntityDescription = thisAssEntityDescription.replaceAll("\\]", ")");
							
							if(!assConcept.getConceptCode().startsWith("A")){
							
							sb.append("[ " + thisConcept + " ] " + "{ fill: 5; link:" + thisConcept + "; } " + "-- " +
							   ass.getDirectionalName() + " --> {link:Relation:" +
							   ns + "_" + assName + "; start: front, 0; } " + " [ Category:" + thisAssEntityDescription + "(" +
							   assConcept.getConceptCode() + ") ] " + "{ fill:3; link: Category:" + thisAssEntityDescription +
							   "(" + assConcept.getConceptCode() + "); }" +
							   "\n");
							}
                            }
							 
						}

					}
				}
				}
				AssociationList aListTarget = refGraph.getTargetOf();
				if (aListTarget != null) {
					Association[] altes = aListTarget.getAssociation();
					for (int jt = 0; jt < altes.length; jt++) {
						Association ass = altes[jt];
						String assName = ass.getAssociationName();
						String assDisplayName = assName;
						if (assName.equals("hasSubtype")) {
							assDisplayName = ass.getDirectionalName();
						}

						AssociatedConceptList acList = ass
								.getAssociatedConcepts();
						AssociatedConcept[] assConcepts = acList
								.getAssociatedConcept();
						for (int ac = 0; ac < assConcepts.length; ac++) {
							AssociatedConcept assConcept = assConcepts[ac];

							//String thisAssEntityDescription = "";
							if(assConcept.getEntityDescription() != null){
							  String thisAssEntityDescription = ns
									+ "_"
									+ assConcept.getEntityDescription()
									.getContent().replaceAll(" ", "_");
								
							  
							thisAssEntityDescription = thisAssEntityDescription.replaceAll("\\[", "(");
							thisAssEntityDescription = thisAssEntityDescription.replaceAll("\\]", ")");
							
							if(!assConcept.getConceptCode().startsWith("A")){
												

							sb.append("[ " + thisConcept + " ] "
									+ "{ fill: 5; link:" + thisConcept + "; } "
									+ "-- " + assDisplayName
									+ " --> {link:Relation:" + ns + "_"
									+ assDisplayName + "; start: front, 0; } "
									+ " [ Category:" + thisAssEntityDescription
									+ "(" + assConcept.getConceptCode()
									+ ") ] " + "{ fill: 4 ; link: Category:"
									+ thisAssEntityDescription + "("
									+ assConcept.getConceptCode() + "); }"
									+ "\n");
							}
							}

						}

					}
				}
			}

			sb.append("</graph></noinclude>\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sb.toString();
	}

	private String getCodedEntryIncludeOnlyForAnonymousNode(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();


		String thisConcept = "Category:" + ns + " "
				+ ref.getConceptCode();

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}
	
	private String getCodedEntryIncludeOnly(ResolvedConceptReference ref,
			String localName, String ns) {
		StringBuffer sb = new StringBuffer();

		String thisConceptName = ref.getEntityDescription().getContent()
				.replaceAll(" ", "_");

		String thisConcept = "Category:" + ns + " " + thisConceptName + "("
				+ ref.getConceptCode() + ")";

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}

}

