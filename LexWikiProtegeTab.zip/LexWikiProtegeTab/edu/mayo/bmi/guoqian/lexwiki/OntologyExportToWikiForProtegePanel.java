package edu.mayo.bmi.guoqian.lexwiki;


import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;
import edu.stanford.smi.protegex.owl.model.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import conexp.core.*;
import conexp.frontend.*;
import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;


public class OntologyExportToWikiForProtegePanel extends JPanel 
                            implements ActionListener{
	
	private KnowledgeBase kb;
	
	private JPanel leftPanel;
	private JPanel rightPanel;
	
	private JSplitPane mainPane;
	
	private JLabel urlLabel;
	private JTextField jtfURL;
	
	private JLabel unLabel;
	private JTextField jtfUserName;
	
	private JLabel pwLabel;
	private JPasswordField jtfPassWord;
	
	private JButton btnGenerateLattice;
	private JButton btnTransformToSwrl;
	
	private JButton btnCreateContent;
	private JButton btnReadFromWiki;
	

	private JLabel labelNameSpaces;
	private JComboBox jcbNameSpaces;
	
	private JButton btnGenerateTemplateContent;
	
	private JRadioButton jrbFrameModel;
	private JRadioButton jrbOWLModel;
	
	
	private ClsesPanel clsesPanel;
	
	private JTextArea textArea;
	private JScrollPane scrollPane;
	
	private JLabel contentLabel;
	private JButton btnExport;
	private JButton btnBatchExport;
	
	private JButton btnBatchTemplateExport;
	
	private JButton btnGetCodeSet;
	private JButton btnSave;
	private GenerateTemplateContentForProtegeICD10Model icdModel;
	private GenerateLatticeForIndexAnalysisInOWL latticeModel;

	
	final String[] namespaces = {"NONE", "Proposal", "ProposalArchive", "ICD10", "ICD10AM", "ICD10CM", 
			"ICF", "NCI", "SN", "SCT", "ICD9CM"};	

	public OntologyExportToWikiForProtegePanel(KnowledgeBase kb){
		this.kb = kb;
		this.initUI();
	}
	
	private void initUI(){
		leftPanel = new JPanel(new BorderLayout());
		rightPanel = new JPanel(new BorderLayout());
		
		clsesPanel = new ClsesPanel(kb.getProject());		
		leftPanel.add(clsesPanel, BorderLayout.CENTER);
		
		JPanel urlPanel = new JPanel();
		urlLabel = new JLabel("Wiki URL: ");
		jtfURL = new JTextField(40);
		jtfURL.setText("http://bmidev.mayo.edu/lexwiki/index.php");
		urlPanel.add(urlLabel);
		urlPanel.add(jtfURL);
		
		JPanel unPanel = new JPanel();
		unLabel = new JLabel("Login name: ");
		jtfUserName = new JTextField(10);
		jtfUserName.setText("LexWikiAdmin");
		unPanel.add(unLabel);
		unPanel.add(jtfUserName);
		
		JPanel pwPanel = new JPanel();
		pwLabel = new JLabel("Password: ");
		jtfPassWord = new JPasswordField(10);
		jtfPassWord.setText("lexlex");
		pwPanel.add(pwLabel);
		pwPanel.add(jtfPassWord);
		
		JLabel projLabel = new JLabel("Ontology Type: ");

		JPanel jrbPanel = new JPanel();
		jrbFrameModel = new JRadioButton("Frame Model");
		jrbFrameModel.setSelected(true);
		jrbOWLModel = new JRadioButton("OWL Model");
		ButtonGroup bg = new ButtonGroup();
		bg.add(jrbFrameModel);
		bg.add(jrbOWLModel);
		jrbPanel.add(projLabel);
		jrbPanel.add(jrbFrameModel);
		jrbPanel.add(jrbOWLModel);
		

		
		JPanel unpwPanel = new JPanel(new GridLayout(1,2));
		unpwPanel.add(unPanel);
		unpwPanel.add(pwPanel);
		
		JPanel upperPanel = new JPanel(new GridLayout(3,1));
		upperPanel.add(urlPanel);
		upperPanel.add(unpwPanel);
		upperPanel.add(jrbPanel);

		
		leftPanel.add(upperPanel, BorderLayout.NORTH);
		
		JPanel nsPanel = new JPanel();
		labelNameSpaces = new JLabel("Namespace: ");
		jcbNameSpaces = new JComboBox(this.namespaces);
		jcbNameSpaces.addActionListener(this);
		nsPanel.add(labelNameSpaces);
		nsPanel.add(jcbNameSpaces);
		
		JPanel btnPanel = new JPanel(new GridLayout(3,1));
		
		JPanel btnGenerateLatticePanel = new JPanel();		
		btnGenerateLattice = new JButton("Generate Lattice...");
		btnGenerateLattice.addActionListener(this);
		btnGenerateLatticePanel.add(btnGenerateLattice);
		
		
		JPanel btnTransformPanel = new JPanel();
		btnTransformToSwrl = new JButton("Transform To SWRL...");
		btnTransformToSwrl.addActionListener(this);
		btnTransformPanel.add(btnTransformToSwrl);
		
		JPanel btnCreatePanel = new JPanel();	
		btnCreateContent = new JButton("Generate Content...");
		btnCreateContent.addActionListener(this);
		btnCreatePanel.add(btnCreateContent);
		
		JPanel btnGenerateTemplatePanel = new JPanel();
		btnGenerateTemplateContent = new JButton("Generate Template Content...");
		btnGenerateTemplateContent.addActionListener(this);
		btnGenerateTemplatePanel.add(nsPanel);
		btnGenerateTemplatePanel.add(btnGenerateTemplateContent);
		
		JPanel btnReadPanel = new JPanel();
		btnReadFromWiki = new JButton("Read Wiki Content...");
		btnReadFromWiki.addActionListener(this);
		btnCreatePanel.add(btnReadFromWiki);
		
		
		btnPanel.add(btnGenerateTemplatePanel);
		btnPanel.add(btnGenerateLatticePanel);
		btnPanel.add(btnTransformPanel);
		//btnPanel.add(btnCreatePanel);
		//btnPanel.add(btnReadPanel);
		//btnPanel.add(btnExportPanel);
		
		leftPanel.add(btnPanel, BorderLayout.SOUTH);
		
		contentLabel = new JLabel("    Contents: ");
		rightPanel.add(contentLabel, BorderLayout.NORTH);
		
		scrollPane = new JScrollPane();
		textArea = new JTextArea();
		scrollPane.getViewport().add(textArea);
		rightPanel.add(scrollPane, BorderLayout.CENTER);
		
		JPanel btnsPanel = new JPanel();
		btnGetCodeSet = new JButton("Get CodeSet...");
		btnGetCodeSet.addActionListener(this);
		btnsPanel.add(btnGetCodeSet);
		
		//JPanel btnExportPanel1 = new JPanel();
		btnExport = new JButton("Export to Wiki...");
		btnExport.addActionListener(this);
		btnsPanel.add(btnExport);
		
		//JPanel btnExportPanel2 = new JPanel();
		btnBatchExport = new JButton("Batch Export...");
		btnBatchExport.addActionListener(this);
		btnsPanel.add(btnBatchExport);
		
		btnBatchTemplateExport = new JButton("Batch Template Export...");
		btnBatchTemplateExport.addActionListener(this);
		btnsPanel.add(btnBatchTemplateExport);
		
		//JPanel btnSavePanel = new JPanel();
		btnSave = new JButton("Save...");
		btnSave.addActionListener(this);
		btnsPanel.add(btnSave);
				
		
		rightPanel.add(btnsPanel, BorderLayout.SOUTH);
		
		mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				                  true,
				                  leftPanel,
				                  rightPanel);
		mainPane.setOneTouchExpandable(true);
		
		this.setLayout(new BorderLayout());
		this.add(mainPane, BorderLayout.CENTER);
		
	}
	
	public void actionPerformed(ActionEvent e){
		
		Object s = e.getSource();
		
		if(s == btnCreateContent){
			this.generateContent();		
		}
		
		if(s == btnGenerateTemplateContent){
			this.generateTemplateContent();
		}
		
		if(s == btnGenerateLattice){
			this.generateLattice();
		}
		
		if(s == btnTransformToSwrl){
			this.transformToSwrl();
		}
		
		if(s == btnReadFromWiki){
			//this.readContentFromWiki();
			this.getLexWikiRDFOutputParsed();
		}
		
		if(s == btnExport){
			this.exportContentToWiki();
		}
		
		if(s == btnBatchExport){
			this.batchExportContentToWiki();
		}
		
		if(s == btnBatchTemplateExport){
			this.batchExportTemplateContentToWiki();
		}
		
		if(s == btnGetCodeSet ){
			this.getCodeSetForClass();
		}
		
		if(s == btnSave){
			this.saveContentToFile();
		}
		
		
	}
	
	private void saveContentToFile(){
		try{
		     BufferedWriter bw = new BufferedWriter(new FileWriter("content.txt"));
	         bw.write(textArea.getText());
	         bw.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	private void getCodeSetForClass(){
		Cls selectedCls = this.getSelectedClass();
		StringBuffer sb = new StringBuffer();
        Collection subclses = selectedCls.getSubclasses();
        //if(!subclses.contains(selectedCls)){
        //	subclses.add(selectedCls);
        //}
        sb.append("Number of Concepts: " + subclses.size() + "\n");
        for(Iterator it = subclses.iterator(); it.hasNext();){
        	Cls subcls = (Cls) it.next();
        	sb.append(subcls.getBrowserText() + "\n");
        }
        textArea.setText(sb.toString());
		
	}
	
	private void generateContent(){
		Cls selectedCls = this.getSelectedClass();
        int projIndex = this.getProjectIndex();
        switch(projIndex){
        case 1:
            GenerateContentForFrameModel frameModel = 
            	                new GenerateContentForFrameModel(projIndex,
        		                                           selectedCls,
        		                                           kb);

            textArea.setText(frameModel.getContent());
            break;
        case 2:
        	GenerateContentForOWLModel owlModel =
        		new GenerateContentForOWLModel((OWLModel)kb, (OWLNamedClass)selectedCls);
        	textArea.setText(owlModel.getContent());
        	break;
        }

        
        
        //Collection subclses = selectedCls.getSubclasses();
        //textArea.append("The class contains: " + subclses.size() + " subclasses.");
		
	}
	
	private void generateLattice(){
		OWLNamedClass selectedCls = (OWLNamedClass)this.getSelectedClass();
		
		latticeModel = new GenerateLatticeForIndexAnalysisInOWL((OWLModel)kb);
		
		Context formalcontext = latticeModel.getFormalContextAdapter(selectedCls).getContext();
	    FormalLatticeComponentPanel latticePanel = 
	    	new FormalLatticeComponentPanel(formalcontext);
	    scrollPane.getViewport().add(latticePanel, null);
	    latticePanel.setVisible(true);
	    
	    //latticeModel.tranformLatticeToSWRL(selectedCls, this);
		
	}
	
	private void transformToSwrl(){
		OWLNamedClass selectedCls = (OWLNamedClass)this.getSelectedClass();
		
		latticeModel = new GenerateLatticeForIndexAnalysisInOWL((OWLModel)kb);
		//latticeModel.tranformLatticeToSWRL(selectedCls, this);
		textArea.setText(latticeModel.getAuditingResults(selectedCls));
		
		
		
		
	}
	
	private void generateTemplateContent(){
		String ns = (String)jcbNameSpaces.getSelectedItem();

		Cls selectedCls = this.getSelectedClass();
		icdModel = new GenerateTemplateContentForProtegeICD10Model(kb);		

		//String content = icdModel.generateContentForSelectedCls(selectedCls, ns);
		
		//for proposal loading
		String content = icdModel.ContentGenerationForICDProposal(selectedCls, ns);
		
		textArea.setText(content);
		
	}	
	
	private void readContentFromWiki(){
		Cls selectedCls = this.getSelectedClass();
        int projIndex = this.getProjectIndex();
		try{
		    URL url = new URL(jtfURL.getText());
		    String userName = jtfUserName.getText();
		    String password = new String(jtfPassWord.getPassword());
		    MediaWikiBot wikiBot = new MediaWikiBot(url);
		    wikiBot.login(userName, password);
		    textArea.setText(wikiBot.readContentOf("Category: " 
		    		+ this.getCategoryAbbr(projIndex)
		    		+ selectedCls.getBrowserText()).getText());
		}catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(this,
					                      "Login Error!",
					                      "Error",
					                      JOptionPane.ERROR_MESSAGE);
		}
		
		
	}

	private void getLexWikiRDFOutputParsed() {
        
		Cls selectedCls = this.getSelectedClass();

		ChangeSetDetectionModelByRDFParser rdfModel = new ChangeSetDetectionModelByRDFParser(
				null, kb);

		//StringBuffer sb = new StringBuffer();

		//sb.append(rdfModel.getOriginalContents(selectedCode, originalContents));
		//sb.append(rdfModel.getParsedContents());
        
		rdfModel.createChangeSetUsingAnnotationOntology(selectedCls, null);
		
		textArea.setText("process finished");

	}	
	
	private void exportContentToWiki(){
		Cls selectedCls = this.getSelectedClass();
	    int projIndex = this.getProjectIndex();
		try{
		    URL url = new URL(jtfURL.getText());
		    String userName = jtfUserName.getText();
		    String password = new String(jtfPassWord.getPassword());
		    
		    MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "lexwiki", "lexlex");
		    //MediaWikiBot wikiBot = new MediaWikiBot(url);
		    wikiBot.login(userName, password);
		    
		    //wikiBot.deleteArticle(this.getCategoryAbbr(projIndex) +
            		//selectedCls.getBrowserText());

		    SimpleArticle sa = new SimpleArticle();
		    
            sa.setLabel(//"Category: " + 
            		//this.getCategoryAbbr(projIndex) +
            		selectedCls.getBrowserText());
            sa.setText(textArea.getText());
            wikiBot.writeContent(sa);

		}catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(this,
					                      "Login Error!",
					                      "Error",
					                      JOptionPane.ERROR_MESSAGE);
		}
				
	}
	
	private void batchExportContentToWiki(){
		Cls selectedCls = this.getSelectedClass();
		
		Collection allContents = new ArrayList();
		try{
		    URL url = new URL(jtfURL.getText());
		    String userName = jtfUserName.getText();
		    String password = new String(jtfPassWord.getPassword());
		    
		    
		    MediaWikiBot wikiBot = new MediaWikiBot(url);
		    wikiBot.login(userName, password);
		    
		    textArea.setText("Login...OK\n");
                
            //get content for selectedCls
            allContents.add(this.getContentForEachClass(selectedCls));
            
            Collection subclses = selectedCls.getSubclasses();
            Iterator it = subclses.iterator();
            while(it.hasNext()){
            	Cls subcls = (Cls)it.next();
            	//wikiBot.deleteArticle(this.getLabelForEachClass(subcls));
            	//get content for each subcls
    	        allContents.add(this.getContentForEachClass(subcls));          	
            }
            
            textArea.append("Content preparation...OK\n");
            
           	            	
            //export all to wiki	
            wikiBot.writeMultContent(allContents.iterator());
      
            textArea.append(allContents.size() + " Terms Exported to wiki...OK\n");

		}catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(this,
					                      "Login Error!",
					                      "Error",
					                      JOptionPane.ERROR_MESSAGE);
		}
				
	}
	private void batchExportTemplateContentToWiki(){
		Cls selectedCls = this.getSelectedClass();
		icdModel = new GenerateTemplateContentForProtegeICD10Model(kb);		
		
		String ns = (String)jcbNameSpaces.getSelectedItem();
		
		Collection allContents = new ArrayList();
		try{
		    URL url = new URL(jtfURL.getText());
		    String userName = jtfUserName.getText();
		    String password = new String(jtfPassWord.getPassword());

		    MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "lexwiki", "lexlex");
		    
		    //MediaWikiBot wikiBot = new MediaWikiBot(url);
		    wikiBot.login(userName, password);
		    
		    textArea.setText("Login...OK\n");
                
            //get content for selectedCls
            allContents.add(this.getTemplateContentForEachClass(selectedCls, ns));
            
            Collection subclses = selectedCls.getSubclasses();
            Iterator it = subclses.iterator();
            while(it.hasNext()){
            	Cls subcls = (Cls)it.next();
            	//wikiBot.deleteArticle(this.getLabelForEachClass(subcls));
            	//get content for each subcls
    	        allContents.add(this.getTemplateContentForEachClass(subcls, ns));          	
            }
            
            textArea.append("Content preparation...OK\n");
            
           	            	
            //export all to wiki	
            wikiBot.writeMultContent(allContents.iterator());
      
            textArea.append(allContents.size() + " Terms Exported to wiki...OK\n");

		}catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(this,
					                      "Login Error!",
					                      "Error",
					                      JOptionPane.ERROR_MESSAGE);
		}
				
		
	}
	
	private String getLabelForEachClass(Cls cls){
        int projIndex = this.getProjectIndex();
        return this.getCategoryAbbr(projIndex) + cls.getBrowserText();

	}	
	private SimpleArticle getContentForEachClass(Cls cls){
        int projIndex = this.getProjectIndex();
        GenerateContentForFrameModel gModel = new GenerateContentForFrameModel(projIndex,
        		                                                   cls,
        		                                                   kb);
        
        SimpleArticle sa = new SimpleArticle();
        sa.setLabel("Category:" + 
        		this.getCategoryAbbr(projIndex) +
        		cls.getBrowserText());
        sa.setText(gModel.getContent());
		
        return sa;
	}

	private SimpleArticle getTemplateContentForEachClass(Cls cls, String ns){
        SimpleArticle sa = new SimpleArticle();
        sa.setLabel(//"Category:" +
        		icdModel.mangle(cls.getBrowserText()));
        //sa.setText(icdModel.generateContentForSelectedCls(cls, ns));
		
        //proposal
        sa.setText(icdModel.ContentGenerationForICDProposal(cls, ns));
        return sa;
	}	
	
	private Cls getSelectedClass(){
		Cls selectedClass = null;
		Collection selections = clsesPanel.getSelection();
		Iterator it = selections.iterator();
		while(it.hasNext()){
			selectedClass = (Cls) it.next();
			break;
		}
		
		return selectedClass;
	}
	
	//todo: indicating by user
	private String getCategoryAbbr(int index){
		switch(index){
		    case 1:
		    	return "";
		    case 2:
		    	return "";
		    default:
		    	return "";
			
		}
	}
	
	private int getProjectIndex(){
		if(jrbFrameModel.isSelected()){
			return 1;
		}else if(jrbOWLModel.isSelected()){
			return 2;
		}else{
			return 1;
		}
  }
}

