package edu.mayo.bmi.guoqian.lexwiki;


import java.util.*;
import java.io.*;
import java.net.URI;

import com.hp.hpl.jena.util.FileUtils;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.URIUtilities;
import conexp.core.*;
import conexp.frontend.*;

import edu.stanford.smi.protegex.owl.ProtegeOWL;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.util.ImportHelper;
import edu.stanford.smi.protegex.owl.swrl.*;
import edu.stanford.smi.protegex.owl.swrl.model.*;
import edu.stanford.smi.protegex.owl.swrl.parser.SWRLParser;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.FormalContextAdapter;

public class GenerateLatticeForIndexAnalysis {

	private KnowledgeBase kb;

	private FormalContextAdapter adapter;

	public GenerateLatticeForIndexAnalysis(KnowledgeBase kb) {
		this.kb = kb;
		//allCodeNames = this.getAllRecords();
		//this.generateContent();

	}
	
	public FormalContextAdapter getFormalContextAdapter(Cls selectedCls){
		String indexAtom = "Index Atom";
		Slot slotIndexAtom = kb.getSlot(indexAtom);
		adapter = new FormalContextAdapter();
		
/*		
		String topClsName = selectedCls.getBrowserText();		
		adapter.addFormalObject(topClsName);
		Collection topIdxAtoms = new ArrayList();
		topIdxAtoms = selectedCls.getOwnSlotValues(slotIndexAtom);
        int index1 = topClsName.lastIndexOf("(");
        topClsName = topClsName.substring(0, index1);
        String [] topWords = topClsName.split(" ");
        for(int i = 1; i < topWords.length; i++){
        	String topWord = topWords[i].toLowerCase();
        	if(topWord.endsWith(",")){
        		topWord = topWord.substring(0, topWord.length()-1);
        	}
        	adapter.addFormalAttribute(topWord);
        	adapter.setRelation(selectedCls.getBrowserText(), topWord);
        }
		for(Iterator it0 = topIdxAtoms.iterator(); it0.hasNext();){
			String atom = (String)it0.next();
			adapter.addFormalAttribute(atom);
			adapter.setRelation(selectedCls.getBrowserText(), atom);
		}
*/		
		Collection subclasses = selectedCls.getSubclasses();

		for(Iterator it = subclasses.iterator(); it.hasNext();){
			Cls subclass = (Cls) it.next();
			String clsName = subclass.getBrowserText();
			adapter.addFormalObject(clsName);
			Collection idxAtoms = subclass.getOwnSlotValues(slotIndexAtom);
			for(Iterator it1 = idxAtoms.iterator(); it1.hasNext();){
				String atom = (String)it1.next();
				adapter.addFormalAttribute(atom);
				adapter.setRelation(clsName, atom);
				
				if(clsName.indexOf(", unspecified") >= 0){
					adapter.addFormalAttribute("unspecified");
					adapter.setRelation(clsName, "unspecified");
				}
				//adapter.setRelation(selectedCls.getBrowserText(), atom);
			}
/*			
			//add top node attributes
			for(Iterator it2 = topIdxAtoms.iterator(); it2.hasNext();){
				String atom = (String)it2.next();
				adapter.addFormalAttribute(atom);
				adapter.setRelation(clsName, atom);
			}	
	        for(int i1 = 1; i1 < topWords.length; i1++){
	        	String topWord = topWords[i1].toLowerCase();
	        	if(topWord.endsWith(",")){
	        		topWord = topWord.substring(0, topWord.length()-1);
	        	}
	        	adapter.addFormalAttribute(topWord);
	        	adapter.setRelation(clsName, topWord);
	        }			
*/			
		}
		
		
		return adapter;
		
	}
	
	public void tranformLatticeToSWRL(Cls selectedCls){
		Lattice lattice = this.getFormalContextAdapter(selectedCls).getLattice();
		
		try{
			
			String fileName = "c:\\whoproject\\lattice2owl1.pprj";	
			
			// Load project
			Collection errors = new ArrayList();
			Project project = new Project(fileName, errors);

			if (!errors.isEmpty()) {
				Iterator iterator = errors.iterator();
				while (iterator.hasNext()) {
					System.out.println(iterator.next());
				}
				return;
			}

			// Get KnowledgeBase
			OWLModel owlModel = (OWLModel) project.getKnowledgeBase();
			
			owlModel.getNamespaceManager().setDefaultNamespace("http://informatics.mayo.edu#");

		    RDFSClass rootClass = owlModel.getOWLNamedClass("owl:Thing");
		    RDFSClass icd10CategoryClass = owlModel.getOWLNamedClass("ICD10Category");
		    
		    OWLNamedClass clsSelectedCls = owlModel.getOWLNamedClass(selectedCls.getBrowserText());
		    clsSelectedCls.addSuperclass(icd10CategoryClass);
		    
		    
			SWRLFactory factory = new SWRLFactory(owlModel);
			
			
			SWRLAtomList body = factory.createAtomList();
			SWRLAtomList head = factory.createAtomList();
			
			OWLNamedClass clsDiseaseType = owlModel.getOWLNamedClass("DiseaseType");

			
			
			OWLNamedClass clsAnatomicalSite = owlModel.getOWLNamedClass("AnatomicalSite");
			OWLNamedClass clsSpecifiedSite = owlModel.getOWLNamedClass("SpecifiedSite");
			OWLNamedClass clsSpecifiedNEC = owlModel.getOWLNamedClass("SpecifiedNEC");
			OWLNamedClass clsUnspecifiedSite = owlModel.getOWLNamedClass("UnspecifiedSite");
			
			OWLNamedClass clsTemporalRelation = owlModel.getOWLNamedClass("TemporalRelation");
			
			for(Iterator it=lattice.elements(); it.hasNext();){
				LatticeElement element = (LatticeElement) it.next();
				for(Iterator it1 = element.ownObjectsIterator(); it1.hasNext();){
					ContextEntity ownObj = (ContextEntity) it1.next();
					String ownObjName = ownObj.getName();
					OWLNamedClass clsOwnObj = owlModel.createOWLNamedClass(ownObjName);
					clsOwnObj.addSuperclass(clsSelectedCls);
					
                    for(Iterator it2 = element.ownAttribsIterator(); it2.hasNext();){
                    	
                    }
					
				}
			}
			
			
			
			
			//SWRLVariable x = factory.createVariable("x");
			OWLNamedClass i22Class = owlModel.createOWLNamedClass("I222");
			//SWRLClassAtom classAtom1 = factory.createClassAtom(i22Class, x);
			
			OWLNamedClass i220Class = owlModel.createOWLNamedClass("I2220");
			//SWRLClassAtom classAtom2 = factory.createClassAtom(i220Class, x);
			
			OWLObjectProperty hasDiseaseType = owlModel.getOWLObjectProperty("hasDiseaseType");
			OWLObjectProperty hasAnatomicalSite = owlModel.getOWLObjectProperty("hasAnatomicalSite");
			OWLObjectProperty hasTemporalRelation = owlModel.getOWLObjectProperty("hasTemporalRelation");
			OWLObjectProperty subCategoryOf = owlModel.getOWLObjectProperty("subCategoryOf");
			OWLObjectProperty synonyms = owlModel.getOWLObjectProperty("synonyms");

            body.append(i22Class);
            body.append(i220Class);
            head.append(i22Class);
			
			SWRLImp imp = factory.createImp(body, head);
			


			Collection errors1 = new ArrayList();
			project.save(errors1);

			System.out.println("File saved with " + errors1.size() + " errors.");	
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	
	
}
