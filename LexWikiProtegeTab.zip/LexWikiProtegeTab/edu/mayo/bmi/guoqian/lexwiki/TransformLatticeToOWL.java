package edu.mayo.bmi.guoqian.lexwiki;

import java.util.ArrayList;
import java.util.Collection;
import java.util.*;
import java.util.Iterator;
import java.util.Map;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protegex.owl.model.*;

import conexp.core.*;
import conexp.frontend.*;
import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class TransformLatticeToOWL {
	
	private OWLModel owlModel;
	private Lattice lattice;

	// an existing blank protege project
	private String fileName1 = "C:\\whoproject\\icd10who.pprj";

	// root class name
	private String root = "ICD10_Terms";

	// meta class name
	private String meta1 = "ICD10META";

	// private String meta2 = "MetaInfo";

	// meta slot name
	private String conceptCode = "Concept Code";

	private String inclusion = "Has Inclusion";

	private String exclusion = "Has Exclusion";

	private String excludes1 = "Excludes1";

	private String excludes2 = "Excludes2";

	private String codefirst = "Code First";

	private String codealso = "Code Also";

	private String includes = "Includes";

	private String sctcodes1 = "snomedct_codes1";

	private String sctcodes2 = "snomedct_codes2";

	private KnowledgeBase kb;

	private Slot slotConceptCode = null;

	private Slot slotInclusion = null;

	private Slot slotExclusion = null;

	private Slot slotIncludes = null;

	private Slot slotExcludes1 = null;

	private Slot slotExcludes2 = null;

	private Slot slotCodeFirst = null;

	private Slot slotCodeAlso = null;

	private Slot slotSctCodes1 = null;

	private Slot slotSctCodes2 = null;
	
	private Map allRecords;
	
	private String icd10category = "ICD10_Categories";
	private String icd10descriptor = "ICD10_Descriptors";
	
	public TransformLatticeToOWL(OWLModel owlModel, Lattice lattice){
		this.owlModel = owlModel;
		this.lattice = lattice;	
		this.getAllRecords();
		this.createOWLNamedClasses(lattice);
		
		//save changes
		owlModel.getProject().save(new ArrayList());
	}
	

	
	private void createOWLNamedClasses(Lattice lattice){
		OWLNamedClass catCls = this.createOWLNamedClass(icd10category);
		OWLNamedClass desCls = this.createOWLNamedClass(icd10descriptor);
		
		String strTopNode = this.getLeadTermFromTopNode(lattice);
		if(strTopNode == null){
			strTopNode = icd10category;
		}
		OWLNamedClass topCls = this.createOWLNamedClass(strTopNode);
		topCls.addSuperclass(catCls);
		
        for(int i = 0; i < lattice.conceptsCount(); i++){
        	Concept concept = (Concept) lattice.conceptAt(i);
        	Collection objects = this.getOwnObjects(concept);
        	for(Iterator it = objects.iterator(); it.hasNext();){
        		String object = (String) it.next();
        		if(object.indexOf("\\+") >= 0){
        			object = object.substring(0, object.length()-1);
        			String objName = (String) allRecords.get(object);
        			if(objName != null){
        				System.out.println(objName);
        			    OWLNamedClass objCls = this.createOWLNamedClass(objName);
        			    objCls.addSuperclass(catCls);
        			    objCls.removeSuperclass(owlModel.getOWLNamedClass("owl:Thing"));
        			}
        			
        			
        			

        		}else if(object.indexOf("\\*") >= 0){
        			//this is a manifestation code
        			object = object.substring(0, object.length()-1);
        			String objName = (String) allRecords.get(object);
           			if(objName != null){
        				System.out.println(objName);
        			    OWLNamedClass objCls = this.createOWLNamedClass(objName);
        			    objCls.addSuperclass(topCls);
        			    objCls.removeSuperclass(owlModel.getOWLNamedClass("owl:Thing"));
           			}
        			
        		}else{
        			String objName = (String) allRecords.get(object);
           			if(objName != null){
        				System.out.println(objName);
        			    OWLNamedClass objCls = this.createOWLNamedClass(objName);
        			    objCls.addSuperclass(topCls);
        			    objCls.removeSuperclass(owlModel.getOWLNamedClass("owl:Thing"));
           			}
        		}
        	}
        	
        }
		
	}
	
	private OWLNamedClass createOWLNamedClass(String clsName){
		
		if(owlModel.getOWLNamedClass(clsName) != null){
			return owlModel.getOWLNamedClass(clsName);

		}else{

			return owlModel.createOWLNamedClass(clsName);			
		}
	}
	
	
	
	
	private String getLeadTermFromTopNode(Lattice lattice){
		String ret = "ICD10_Categories";
		LatticeElement top = lattice.getTop();
		Collection ownAttr = this.getOwnAttributes((Concept)top);
		for(Iterator it = ownAttr.iterator(); it.hasNext();){
			ret = (String) it.next();
			//break;
			
		}	
		
		System.out.println("top node:" + ret);
		return ret;
	}

	
	private Collection getOwnAttributes(Concept concept){
		Collection ret = new ArrayList();
		
        for(Iterator it1 = concept.ownAttribsIterator(); it1.hasNext();){
    		ContextEntity ownattr = (ContextEntity)it1.next();
    		ret.add(ownattr.getName());    	
    }		
		return ret;
	}
	
	private Collection getOwnObjects(Concept concept){
		Collection ret = new ArrayList();
		
        for(Iterator it1 = concept.ownObjectsIterator(); it1.hasNext();){
    		ContextEntity ownobj = (ContextEntity)it1.next();
    		ret.add(ownobj.getName());    	
    }		
		return ret;
	}
	
	// main method for importing
	private void getAllRecords() {

		// Load project
		Collection errors = new ArrayList();
		Project project = new Project(fileName1, errors);

		if (!errors.isEmpty()) {
			Iterator iterator = errors.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
			//return;
		}

		// Get KnowledgeBase
		kb = project.getKnowledgeBase();

		slotConceptCode = kb.getSlot(conceptCode);
		slotInclusion = kb.getSlot(inclusion);
		slotExclusion = kb.getSlot(exclusion);
		slotIncludes = kb.getSlot(includes);
		slotExcludes1 = kb.getSlot(excludes1);
		slotExcludes2 = kb.getSlot(excludes2);
		slotCodeFirst = kb.getSlot(codefirst);
		slotCodeAlso = kb.getSlot(codealso);
		slotSctCodes1 = kb.getSlot(sctcodes1);
		slotSctCodes2 = kb.getSlot(sctcodes2);
		
		
		// Get all records from database
		allRecords  = new HashMap();
		Cls rootCls = kb.getCls(root);
		Cls metaCls = kb.getCls(meta1);
		Collection clses = kb.getSubclasses(rootCls);
		for(Iterator it = clses.iterator(); it.hasNext();){
			Cls cls = (Cls)it.next();
			String code = (String) cls.getOwnSlotValue(slotConceptCode);
		    allRecords.put(code, cls.getBrowserText());
		}	
	}
	
	
}
