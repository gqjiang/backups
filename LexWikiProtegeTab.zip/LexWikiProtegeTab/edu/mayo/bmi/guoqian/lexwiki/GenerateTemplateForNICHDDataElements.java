package edu.mayo.bmi.guoqian.lexwiki;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;
import java.net.URL;


public class GenerateTemplateForNICHDDataElements {
	
	private final String fileNameSupers = "C:\\Temp\\bridg\\bridg_supers.txt"; 
	private final String fileNameClasses = "C:\\Temp\\bridg\\bridg_classes.txt"; 
	
	//private final String fileName = "C:\\Temp\\cshare\\de_wiki_lilly02.txt"; 
	private final String fileName = "C:\\nichd\\de_nichd.txt"; 
	//private String urlstr = "http://bmidev3/cshare/index.php";
	private String urlstr = "http://informatics.mayo.edu/cshareDemo/index.php";
	private String userName = "Guoqian";
	private String password = "guoqian0331";
	
	private Collection colDataSetPages = new ArrayList(); 
	
	public void publishDataElementsToWiki(){
		Collection des = this.processingDataElements();
		//Collection des = this.processingSuperDataElements();
		//Collection des = this.processingBRIDGClassesRedirect();
		//System.out.println(des.size());

		try{
			URL url = new URL(urlstr);
			//MediaWikiBot wikiBot = new MediaWikiBot(url);
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "cshare", "share");
			wikiBot.login(userName, password);
			wikiBot.writeMultContent(des.iterator());
			//wikiBot.writeMultContent(this.colDataSetPages.iterator());
			System.out.println("publishing done: " + des.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
        
	}
	
	public void publishDataElementFiltersToWiki(){
		Collection des = this.getAllConceptPages();
		try{
			URL url = new URL(urlstr);
			//MediaWikiBot wikiBot = new MediaWikiBot(url);
			MediaWikiBotExtension wikiBot = new MediaWikiBotExtension(url, "cshare", "xTu$$9");
			wikiBot.login(userName, password);
			wikiBot.writeMultContent(des.iterator());
			//wikiBot.writeMultContent(this.colDataSetPages.iterator());
			System.out.println("publishing done: " + des.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
        
	}
		
	
	private Collection getAllConceptPages(){
		Collection colConceptPages = new ArrayList();
		String[] sources = {"Genzyme", "GSK", "EliLilly", "Mayo", "MDAnderson"};
		String[] datasets = {"Adverse Events", "Lesion Measurement", "Blood Products", "Chest X-Ray", 
				"Disease Characteristics", "ECHO", "Follow Up", "Karnofsky Performance Scale", 
				"Prior Hormon/Biologics/Chemotherapy/Other", "Prior Surgery for this Cancer", "Radiotherapy"};
		for(int i = 0; i < sources.length; i ++){
			for(int j = 0; j < datasets.length; j++){
				String source = sources[i];
				String dataset = datasets[j];
				dataset = dataset.replaceAll(" ", "_");
				SimpleArticle sa = new SimpleArticle();
				sa.setLabel("Concept:" + source + "_" + dataset );
				sa.setText(this.getDataElementFilterSourceDataset(source, dataset));
				colConceptPages.add(sa);
				//if(j > 1) break;
			}
			    //if(i > 1) break;
		}
		
		return colConceptPages;
	}
	
	public Collection processingDataElements(){
		
		Collection ret = new ArrayList();
		BufferedReader br = null;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			int index = 0;
			while(line != null){
				StringBuffer sb = new StringBuffer();
				String[] items = line.split("\\t");
				if(items.length == 9){
				String source = items[0];
				String domain = items[1];
				String dataset = items[2];
				String shortname = items[3];
				String longname = items[4];
				String defintion = items[5];
				String datatype = items[6];
				if(datatype.equals("UNSPECIFIED")){
					datatype= "ANY";
				}
				//String datatype = "ANY";
				String unit = items[7];
				if(unit.equals("UNSPECIFIED")){
					unit = "NO_UNITS_SPECIFIED";
				}
				
				String codelist = items[8];
				
				sb.append(this.getDEDetailsHeader());
				sb.append(this.getLongName(longname, ""));
				sb.append(this.getShortName(shortname));
				sb.append(this.getDefinition(defintion));
				sb.append(this.getSourceName(source));
				sb.append(this.getDataType(datatype));
				sb.append(this.getUnit(unit));
				sb.append(this.getDatasetName(dataset, domain));
				//sb.append(this.getDomainName(domain));
				sb.append(this.getDEDetailsTrailer());
				sb.append(this.getDEValuesetHeader());
				if(!codelist.equals("UNSPECIFIED")){
					sb.append(this.getDEValueset(codelist, source));
				}
				sb.append(this.getDEValuesetTrailer());
				sb.append(this.getDEConceptReferenceHeader());
				sb.append(this.getDEConceptReference());
				sb.append(this.getDEConceptReferenceTrailer());
				
				//this.addDataSetPage(source, dataset);
				SimpleArticle sa = new SimpleArticle();
				
				//dataset added in page name
				sa.setLabel(source + "_" + dataset + "_" + longname);
				sa.setText(sb.toString());
				ret.add(sa);
				}
			
				//if(index > 1) break;
				line = br.readLine();
				index++;
			}
			br.close();
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}
	
	public Collection processingSuperDataElements(){
		
		Collection ret = new ArrayList();
		BufferedReader br = null;
		BufferedReader br1 = null;
		Map Supers = new HashMap();
		
		try{
			
			br1 = new BufferedReader(new FileReader(fileNameSupers));
			String line1 = br1.readLine();
			while(line1 != null){
				String[] pairs = line1.split("\\t");

				if(Supers.containsKey(pairs[1])){
					Collection values = (Collection) Supers.get(pairs[1]);
					values.add(pairs[0]);
					Supers.put(pairs[1], values);
				}else{
					Collection values = new ArrayList();
					values.add(pairs[0]);
					Supers.put(pairs[1], values);					
					//System.out.println(pairs[1]);
					}

				line1 = br1.readLine();
			}

			
			
			br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			int index = 0;
			while(line != null){
				String[] items = line.split("\\t");
				if(items.length == 9){
				String source = items[0];
				String domain = items[1];
				String dataset = items[2];
				String shortname = items[3];
				String longname = items[4];
				String defintion = items[5];
				String datatype = items[6];
				if(datatype.equals("UNSPECIFIED")){
					datatype= "ANY";
				}
				//String datatype = "ANY";
				String unit = items[7];
				if(unit.equals("UNSPECIFIED")){
					unit = "NO_UNITS_SPECIFIED";
				}
				
				String codelist = items[8];
				System.out.println(dataset);
				
				Collection subdatasets = (Collection) Supers.get(dataset);
				if(subdatasets != null){
				for(Iterator it = subdatasets.iterator(); it.hasNext();){
					String subdataset = (String) it.next();
					StringBuffer sb = new StringBuffer();
				
				sb.append(this.getDEDetailsHeader());
				sb.append(this.getLongName(longname, dataset));
				sb.append(this.getShortName(shortname));
				sb.append(this.getDefinition(defintion));
				sb.append(this.getSourceName(source));
				sb.append(this.getDataType(datatype));
				sb.append(this.getUnit(unit));
				sb.append(this.getDatasetName(subdataset, domain));
				//sb.append(this.getDomainName(domain));
				sb.append(this.getDEDetailsTrailer());
				sb.append(this.getDEValuesetHeader());
				if(!codelist.equals("UNSPECIFIED")){
					sb.append(this.getDEValueset(codelist, source));
				}
				sb.append(this.getDEValuesetTrailer());
				sb.append(this.getDEConceptReferenceHeader());
				sb.append(this.getDEConceptReference());
				sb.append(this.getDEConceptReferenceTrailer());
				
				//this.addDataSetPage(source, dataset);
				SimpleArticle sa = new SimpleArticle();
				
				//dataset added in page name
				sa.setLabel(source + "_" + subdataset + "_" + longname);
				sa.setText(sb.toString());
				ret.add(sa);
				}
				}
				}
			
				//if(index > 0) break;
				line = br.readLine();
				index++;
			}
			br.close();
			br1.close();			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}	
	
	
	public Collection processingBRIDGClassesRedirect(){
		
		Collection ret = new ArrayList();
		BufferedReader br = null;
		//BufferedReader br1 = null;
		//Map Supers = new HashMap();
		
		try{
						
			br = new BufferedReader(new FileReader(fileNameClasses));
			String line = br.readLine();
			int index = 0;
			while(line != null){
				
				String clsName = line.trim();

				SimpleArticle sa = new SimpleArticle();
				
				//dataset added in page name
				sa.setLabel( "BRIDG_" + clsName);
				sa.setText("#REDIRECT [[:Category:BRIDG_" + clsName + "]]");
				ret.add(sa);				
			
				//if(index > 0) break;
				line = br.readLine();
				index++;
			}
			br.close();			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		return ret;
	}	
	
	private void addDataSetPage(String source, String dataset){
		SimpleArticle sa = new SimpleArticle();
		sa.setLabel("Category:" + source + "_" + dataset);
		sa.setText("[[Category:CSHARE_" + dataset + "]]\n");
		if(!this.colDataSetPages.contains(sa)){
			this.colDataSetPages.add(sa);
		}
		SimpleArticle sa_de = new SimpleArticle();
		sa_de.setLabel("Category:" + source + "_Data_Element");
		sa_de.setText("[[Category:CSHARE_Data_Element]]\n");
		if(!this.colDataSetPages.contains(sa_de)){
			this.colDataSetPages.add(sa_de);
		}		
	}
	
	private String getDataElementFilterSourceDataset(String source, String dataset){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementFilterForSourceAndDataset|1=" +  source + 
				"|2=Oncology_" +  dataset + "}}\n");
		
		return sb.toString();
	}
	
	private String getLongName(String text, String supertext){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementLongName|1=" + text + "|2=" + supertext + "}}\n");
		return sb.toString();
	}
	
	private String getShortName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementShortName|1=" + text + "}}\n");
		return sb.toString();
	}

	private String getDataType(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDataType|1=DT_" + text + "}}\n");
		return sb.toString();
	}
	
	private String getUnit(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementUnit|1=" + text + "}}\n");
		return sb.toString();
	}	
	
	private String getDefinition(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDefinition|1=" + text + "}}\n");
		return sb.toString();
	}	

	private String getSourceName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementSourceName|1=" + text + "}}\n");
		return sb.toString();
	}		

	private String getDatasetName(String text, String domain){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDatasetName|1=" + text + 
				"|2=" + domain +
		     "}}\n");
		return sb.toString();
	}		
/*	
	private String getDomainName(String text){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDomainName|1=" + text + "}}\n");
		return sb.toString();
	}
*/
	private String getDEDetailsHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDetailsHeader}}\n");
		return sb.toString();
	}	
	
	private String getDEDetailsTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementDetailsTrailer}}\n");
		return sb.toString();
	}			
	
	private String getDEValuesetHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetHeader}}\n");
		return sb.toString();
	}			

	private String getDEValueset(String text, String source){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetBody|1=" + source + " " + text + " Value Set}}\n");
		return sb.toString();
	}			
	
	private String getDEValuesetTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementValuesetTrailer}}\n");
		return sb.toString();
	}			

	private String getDEConceptReferenceHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceHeader}}\n");
		return sb.toString();
	}		

	private String getDEConceptReference(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceBody|MISSING}}\n");
		return sb.toString();
	}		
	
	private String getDEConceptReferenceTrailer(){
		StringBuffer sb = new StringBuffer();
		sb.append("{{CSHARE_DataElementConceptReferenceTrailer}}\n");
		return sb.toString();
	}			
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenerateTemplateForNICHDDataElements model =
			new GenerateTemplateForNICHDDataElements();
		model.publishDataElementsToWiki();
		//model.publishDataElementFiltersToWiki();

	}

}
