package edu.mayo.bmi.guoqian.lexwiki;

import org.LexGrid.concepts.*;
//import org.LexGrid.relations.Association;
import org.LexGrid.LexBIG.DataModel.Collections.*;
import org.LexGrid.LexBIG.DataModel.InterfaceElements.*;
import org.LexGrid.LexBIG.DataModel.Core.*;
import org.LexGrid.LexBIG.Utility.Iterators.ResolvedConceptReferencesIterator;
import org.LexGrid.LexBIG.Impl.*;
import org.LexGrid.LexBIG.LexBIGService.*;
import org.LexGrid.LexBIG.Utility.*;

import org.LexGrid.LexBIG.DataModel.InterfaceElements.CodingSchemeRendering;
import org.LexGrid.LexBIG.Exceptions.LBException;
import org.LexGrid.LexBIG.Exceptions.LBInvocationException;
import org.LexGrid.LexBIG.Exceptions.LBParameterException;
import org.LexGrid.LexBIG.LexBIGService.LexBIGService;
import org.LexGrid.LexBIG.LexBIGService.CodedNodeSet.PropertyType;
import org.LexGrid.LexBIG.Utility.Constructors;
import org.LexGrid.LexBIG.gui.restrictions.HavingProperties;
import org.LexGrid.LexBIG.gui.restrictions.MatchingCode;
import org.LexGrid.LexBIG.gui.restrictions.MatchingDesignation;
import org.LexGrid.LexBIG.gui.restrictions.MatchingProperties;
import org.LexGrid.LexBIG.gui.restrictions.Status;
import org.apache.log4j.Logger;

import edu.stanford.smi.protege.model.*;

import net.sourceforge.jwbf.bots.*;
import net.sourceforge.jwbf.contentRep.mw.*;

import net.sourceforge.jwbf.actions.http.mw.*;

import java.util.*;
import java.io.*;
import java.net.URL;


//first implementation of new lexwiki templates
public class GenerateTemplateContentForHugo {
	
	//private String icd10amInclusion = "C:\\whoproject\\ICD10AM_full\\icd10am-includenotag.txt";
	//private String icd10amIncludes = "C:\\whoproject\\ICD10AM_full\\icd10am-includes.txt";
	//private String icd10amExcludes = "C:\\whoproject\\ICD10AM_full\\icd10am-excludes1.txt";
	
	//private String icd10Inclusion = "C:\\whoproject\\ICD10who_full\\icd10-includenotag.txt";
	//private String icd10Includes = "C:\\whoproject\\ICD10who_full\\icd10-includes.txt";
	//private String icd10Excludes = "C:\\whoproject\\ICD10who_full\\icd10-excludes1.txt";
	
	private String hugoFileName = "C:\\whoproject\\hugo\\hgnc.txt";

	private Map superClasses = new HashMap();
	private Collection propertyNames = new ArrayList();
	private KnowledgeBase kb = null;
	
	public GenerateTemplateContentForHugo() {

	}
	
	public Collection getAllHugoGenes(){
		
		Collection ret = new ArrayList();
		try{
			BufferedReader br = new BufferedReader(new FileReader(hugoFileName));
			String line = br.readLine();
			line = br.readLine();
			
			while(line != null){
				String[] items = line.split("\t");
				ret.add(items);
				line = br.readLine();
			}
			
			br.close();
			
			
		}catch(IOException ie){
			ie.printStackTrace();
		}
		
		
		return ret;
	}
	
	public Collection renderContentsIntoTemplates(){
		Collection entries = this.getAllHugoGenes();
		Collection ret = new ArrayList();
		int index = 0;
		for(Iterator it = entries.iterator(); it.hasNext();){
			index++;
			
			String[] items = (String[]) it.next();
			StringBuffer sb = new StringBuffer();

			SimpleArticle sa = new SimpleArticle();
			
			String label = "HUGO_" + items[2] + "(" + items[1] + ")";			
			sa.setLabel("Category:" + this.mangle(label));
			
			

			sb.append(this.getHeaderBasicData());
			// sb.append("== Concept Code ==\n");
			sb.append(this.getCodedEntryCode(items[0]));

			// sb.append("== Entity Description ==\n");
			sb.append(this.getCodedEntryDescription(items[2]));

			// sb.append("== Coding Scheme ==\n");
			sb.append(this.getCodingScheme("HUGO Human Gene Nomenclature"));

			// sb.append("== Presentations ==\n");
			sb.append(this.getCodedEntryPresentations("HUGO_HGNC_ID", items[0]));
			sb.append(this.getCodedEntryPresentations("HUGO_Approved_Symbol", items[1]));
			sb.append(this.getCodedEntryPresentations("HUGO_Approved_Name", items[2]));

			if(items.length > 4 && !items[4].equals(""))
				sb.append(this.getCodedEntryPresentations("HUGO_Previous_Symbol", items[4]));
			if(items.length > 5 &&!items[5].equals(""))
				sb.append(this.getCodedEntryPresentations("HUGO_Aliases", items[5]));
			sb.append(this.getCodedEntryURI(items[0]));
			
			sb.append(this.getTrailerBasicData());

			sb.append(this.getHeaderProperties());

			// sb.append("== Concept Property ==\n");
			if(items.length > 3 && !items[3].equals(""))
				sb.append(this.getCodedEntryConceptProperty("HUGO_Status", items[3]));
			if(items.length > 6 && !items[6].equals(""))
				sb.append(this.getCodedEntryConceptProperty("HUGO_Chromosome", items[6]));
			if(items.length > 7 && !items[7].equals(""))
				sb.append(this.getCodedEntryConceptProperty("HUGO_Accession_Numbers", items[7]));
			if(items.length > 8 && !items[8].equals(""))
				sb.append(this.getCodedEntryConceptProperty("HUGO_RefSeq_IDs", items[8]));
           
			sb.append(this.getTrailerProperties());

			
			sb.append(this.getHeaderAssoications());

			// sb.append("== Associations ==\n");

			sb.append(this.getCodedEntryParent("HUGO"));

			sb.append(this.getTrailerAssoications());
			
			sb.append(this.getDefaultForm());
			
			sb.append(this.getCodedEntryIncludeOnly(items[2] + "(" + items[1] + ")" ));
			
			//System.out.println(sb.toString());
			
			sa.setText(sb.toString());
			ret.add(sa);
			
			//if(index++ > 2) break;
		
		}
		
		
		System.out.println("loading is done: " + ret.size());
		
		return ret;
	}

    public void exportToLexWiki(){
    	Collection contents = this.renderContentsIntoTemplates();
		try {   	
			URL url = new URL("http://bmidev.mayo.edu/lexwiki1/index.php");
			String userName = "LexWikiAdmin";
			String password = "lexlex";
			MediaWikiBot wikiBot = new MediaWikiBot(url);

			// MediaWikiBot wikiBot = new MediaWikiBot(url);
			wikiBot.login(userName, password); 

			wikiBot.writeMultContent(contents.iterator());
			
			System.out.println("loading is done: " + contents.size());			
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

	private String getCodingScheme(String name) {
		StringBuffer sb = new StringBuffer();

			sb.append("{{LexWiki inScheme|" + name
					+ "}}\n");



		return sb.toString();
	}
	
	
	private String getDefaultForm() {
		return "<noinclude>[[has default form::Form:LexWiki HUGO Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "<noinclude>{{LexWiki Basic Data Header}}</noinclude>\n";
	}

	private String getTrailerBasicData() {
		return "<noinclude>{{LexWiki Basic Data Trailer}}</noinclude>\n";
	}

	private String getHeaderProperties() {
		return "<noinclude>{{LexWiki Concept Property Header}}</noinclude>\n";
	}

	private String getTrailerProperties() {
		return "<noinclude>{{LexWiki Concept Property Trailer}}</noinclude>\n";
	}

	private String getHeaderAssoications() {
		return "<noinclude>{{LexWiki Association Header}}</noinclude>\n";
	}

	private String getTrailerAssoications() {
		return "<noinclude>{{LexWiki Association Trailer}}</noinclude>\n";
	}



	private String getCodedEntryCode(String code) {

		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		return sb.toString();
	}

	private String getCodedEntryDescription(String description) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Preferred Name|"
				+ description + "}}\n");
		return sb.toString();

	}

	private String getCodedEntryURI(String code) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki URI|"
				+ "HUGO Human Gene Nomenclature" + ":" + code + "}}\n");
		return sb.toString();

	}	
	

	private String getCodedEntryPresentations(String name, String value) {
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Presentation|" + name + "|"
						+ value + "}}\n");


		return sb.toString();

	}

	private String getCodedEntryConceptProperty(String name, String value) {
		StringBuffer sb = new StringBuffer();
	
		sb.append("{{LexWiki Concept Property|" + name + "|" + value
					+ "}}\n");


		return sb.toString();
	}

	private String getCodedEntryParent(String parent) {
		StringBuffer sb = new StringBuffer();
			sb.append("{{LexWiki Parent|"
					+ parent + "}}\n");


		return sb.toString();
	}




	private String getCodedEntryIncludeOnly(String name) {
		StringBuffer sb = new StringBuffer();
		String thisConcept = "Category:HUGO_" + this.mangle(name);

		sb.append("<includeonly>[[" + thisConcept + "]]</includeonly>\n");

		return sb.toString();
	}
	

	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		//lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		// 3) Remove leading and trailing "_"
		lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");
		
		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}
	
	public static void main(String[] args){
		GenerateTemplateContentForHugo model = 
			new GenerateTemplateContentForHugo();
		
		//model.renderContentsIntoTemplates();
		model.exportToLexWiki();
	}



}

