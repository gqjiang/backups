package edu.mayo.bmi.guoqian.lexwiki;

import java.util.*;

import org.LexGrid.concepts.CodedEntry;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;

public class GenerateTemplateContentForProtegeICD10Model {
    //meta class name
    private String meta1 = "ICD10META";
    private String meta2 = "MetaInfo";
    
    private String root = "ICD10_Terms";

    //meta slot name
    private String conceptCode = "Concept Code";
    private String inclusion = "Has Inclusion";
    private String exclusion = "Has Exclusion";
    private String excludes1 = "Excludes1";
    private String excludes2 = "Excludes2";
    private String codefirst = "Code First";
    private String codealso = "Code Also";
    private String includes = "Includes";

	
	private KnowledgeBase kb;

	
	private Map allCodeNames;

	public GenerateTemplateContentForProtegeICD10Model(KnowledgeBase kb) {
		this.kb = kb;
		//allCodeNames = this.getAllRecords();
		//this.generateContent();

	}
	
	public String generateContentForSelectedCls(Cls selectedCls, String ns){
		StringBuffer sb = new StringBuffer();
		//allCodeNames = this.getAllRecords();
		Slot slotConceptCode = kb.getSlot(conceptCode);
		Slot slotInclusion = kb.getSlot(inclusion);
		Slot slotIncludes = kb.getSlot(includes);
		Slot slotExcludes1 = kb.getSlot(excludes1);
		Slot slotExcludes2 = kb.getSlot(excludes2);
		Slot slotCodeFirst = kb.getSlot(codefirst);
		Slot slotCodeAlso = kb.getSlot(codealso);
		
		String clsName = selectedCls.getBrowserText();
		String clsMangledName = this.mangle(clsName);
		//String description = this.getStringFromDocumentation();
		String conCode = (String) selectedCls.getOwnSlotValue(slotConceptCode);
        
		Collection colInclusion = selectedCls.getOwnSlotValues(slotInclusion);
        
        Collection colIncludes = selectedCls.getOwnSlotValues(slotIncludes);
        
        Collection colExcludes1 = selectedCls.getOwnSlotValues(slotExcludes1);
        
        Collection colExcludes2 = selectedCls.getOwnSlotValues(slotExcludes2);
        
        Collection colCodeFirst = selectedCls.getOwnSlotValues(slotCodeFirst);
        
        Collection colCodeAlso = selectedCls.getOwnSlotValues(slotCodeAlso);
        
		//basic data header
		sb.append(this.getHeaderBasicData());
		//concept code
		sb.append(this.getConceptCodeTemplate(conCode));
		//preferred name
		sb.append(this.getPreferredNameTemplate(conCode, clsName, ns));
		//coding scheme
		sb.append(this.getCodingSchemeTemplate(this.getCodingSchemeByNs(ns)));
		//URI
		sb.append(this.getURITemplate(this.getCodingSchemeByNs(ns), conCode));
		//basic data trailer
		sb.append(this.getTrailerBasicData());
		
		//concept property header
		sb.append(this.getHeaderProperties());
		
		//concept properties
		if(ns.equals("ICD10CM")){

			if(colInclusion != null && colInclusion.size() > 0)
			    sb.append(this.getConceptPropertyInclusionTemplate(colInclusion, ns));
		    if(colIncludes != null && colIncludes.size() > 0)
			    sb.append(this.getConceptPropertyIncludesTemplate(colIncludes, ns));
		    if(colExcludes1 != null && colExcludes1.size() > 0)
			    sb.append(this.getConceptPropertyExcludes1Template(colExcludes1, ns));
		    if(colExcludes2 != null && colExcludes2.size() > 0)
			    sb.append(this.getConceptPropertyExcludes2Template(colExcludes2, ns));
		    if(colCodeFirst != null && colCodeFirst.size() > 0)
			    sb.append(this.getConceptPropertyCodeFirstTemplate(colCodeFirst, ns));
		    if(colCodeAlso != null && colCodeAlso.size() > 0)
			    sb.append(this.getConceptPropertyCodeAlsoTemplate(colCodeAlso, ns));
			
		}else{
			if(colInclusion != null && colInclusion.size() > 0)
			    sb.append(this.getConceptPropertyInclusionTemplate(colInclusion, ns));
		    if(colIncludes != null && colIncludes.size() > 0)
			    sb.append(this.getConceptPropertyIncludesTemplate(colIncludes, ns));
		    if(colExcludes1 != null && colExcludes1.size() > 0)
			    sb.append(this.getConceptPropertyExcludesTemplate(colExcludes1, ns));
		    
		    if(ns.equals("ICD10"))
		        sb.append(this.getDPLQuery1ForICD10(conCode));
		}
		
		//concept property trailer
		sb.append(this.getTrailerProperties());
		
		//association header
		sb.append(this.getHeaderAssoications());
		
		//associations
		sb.append(this.getParentTemplate(selectedCls));	
		
		if(ns.equals("ICD10CM")){
		    if(colExcludes1 != null && colExcludes1.size() > 0)			
			    sb.append(this.getAssociationExcludes1Template(colExcludes1, ns));
		    if(colExcludes2 != null && colExcludes2.size() > 0)
      			sb.append(this.getAssociationExcludes2Template(colExcludes2, ns));
		}else{
		    if(colExcludes1 != null && colExcludes1.size() > 0)			
			    sb.append(this.getAssociationExcludesTemplate(colExcludes1, ns));			
		    if(ns.equals("ICD10"))
		        sb.append(this.getDPLQuery2ForICD10(conCode));
		}
		
		//association trailer
		sb.append(this.getTrailerAssoications());
		
		if(ns.equals("ICD10") && selectedCls.getSubclasses().size() < 1){
		    //reference header
		    sb.append(this.getHeaderReferences());
		
		    //references
		    sb.append(this.getReferenceTemplate(conCode));
		    //reference trailer
		    sb.append(this.getTrailerReferences());
		    }

		
		//default form
		sb.append(this.getDefaultForm());
		
		//class itself
		sb.append("<includeonly>[[Category:" + clsMangledName + "]]</includeonly>\n");
		
		return sb.toString();
	}
	
	private String getCodingSchemeByNs(String ns){
		String codingScheme = "";
		if(ns.equals("ICD10")){
			codingScheme = "ICD10 Second Edition";
		}else if(ns.equals("ICD10AM")){
			codingScheme = "ICD10AM Fifth Edition";
		}else if(ns.equals("ICD10CM")){
			codingScheme = "ICD10CM July 2007 Release";			
		}
		
		return codingScheme;
	}
	
	private Map getAllRecords(){
		Map map = new HashMap();
		Cls clsRoot = kb.getCls(root);
		Collection subclasses = clsRoot.getSubclasses();
		for(Iterator it = subclasses.iterator(); it.hasNext();){
			Cls subcls = (Cls)it.next();
			Slot slotConceptCode = kb.getSlot(conceptCode);
            String conCode = (String) subcls.getOwnSlotValue(slotConceptCode);
            String clsName = this.mangle(subcls.getBrowserText());
            map.put(conCode, clsName);
		}
		
		
		return map;
	}

	public String ContentGenerationForICDProposal(Cls selectedCls, String ns){
		StringBuffer result = new StringBuffer();
		
		Slot slotTitle = kb.getSlot("Title");
		Slot slotOriginator = kb.getSlot("Originator");
		Slot slotPcf = kb.getSlot("PrimaryCodeEffect");
		Slot slotScf = kb.getSlot("SecondaryCodesEffect");
		Slot slotDescription = kb.getSlot("Description");
		Slot slotRationale = kb.getSlot("Rationale");
		
		
		String clsName = selectedCls.getName();
		//result.append(clsName + "\n");
		
		if(ns.equals("Proposal")){
			result.append("{{WorkFlow_CurationStatus|Submitted}}\n\n");
		}else if(ns.equals("ProposalArchive")){
			result.append("{{WorkFlow_CurationStatus|Completed}}\n\n");
		}

		String title = (String)selectedCls.getOwnSlotValue(slotTitle);
		String originator = (String)selectedCls.getOwnSlotValue(slotOriginator);
		String pcf = (String)selectedCls.getOwnSlotValue(slotPcf);
		String scf = (String)selectedCls.getOwnSlotValue(slotScf);
		String description = (String)selectedCls.getOwnSlotValue(slotDescription);
		String rationale = (String)selectedCls.getOwnSlotValue(slotRationale);
		
		//result.append("<noinclude>== Title ==</noinclude>\n");
		result.append("{{LexWiki Proposal Title|" + title + "}}\n\n");
		//result.append("<noinclude>== Originator ==</noinclude>\n");
		result.append("{{LexWiki Proposal Originator|" + originator + "}}\n\n");
		//result.append("<noinclude>== Primary Code Effected ==</noinclude>\n");
		result.append("{{LexWiki Proposal Primary Code Effected|" + pcf + "}}\n\n");
		//result.append("<noinclude>== Secondary Codes Effected ==<noinclude>\n");
		if(scf != null){
		  String[] items = scf.split("\\|");
		  for(int i = 0; i < items.length; i++){
			  String item = items[i];
		      if(item != null){
		          result.append("{{LexWiki Proposal Secondary Code Effected|" + item + "}}\n\n");
		      }
		  }
		}
		//result.append("<noinclude>== Description ==</noinclude>\n");
		result.append("{{LexWiki Proposal Description|" + description + "}}\n\n");
		//result.append("<noinclude>== Rationale ==</noinclude>\n");
		result.append("{{LexWiki Proposal Rationale|" + rationale + "}}\n\n");
		
		//result.append("[[Category: ICD Proposal]]");
		//result.append("[[Category: ICD Proposal Archive]]");
		
		return result.toString();
		
	}
	
	
	private String getDPLQuery1ForICD10(String code){
		//String code = entry.getConceptCode();
		return "<noinclude>{{LexWiki DPL Query1|ICD10xx Properties|ICD10CM %(" + 
		        code + "){{!}}ICD10AM %(" + code + ")" + "}}</noinclude>\n";
	}

	private String getDPLQuery2ForICD10(String code){
		//String code = entry.getConceptCode();
		return "<noinclude>{{LexWiki DPL Query2|ICD10xx Associations|ICD10CM %(" + 
		        code + "){{!}}ICD10AM %(" + code + ")" + "}}</noinclude>\n";
	}
	
	private String getLexWikiCategoryTree(String code){
		//String code = entry.getConceptCode();
		return "<noinclude>{{LexWiki CategoryTree|{{LexWiki DPL Query3|ICD10CM %(" +
		code + ")}}|{{LexWiki DPL Query3|ICD10AM %(" + code + ")}}}}</noinclude>";
	}
	
	
	private String getReferenceTemplate(String code){
		StringBuffer sb = new StringBuffer();
        sb.append(this.getLexWikiCategoryTree(code));		
		return sb.toString();
	}
	
	private String getParentTemplate(Cls selectedCls){
		StringBuffer sb = new StringBuffer();
		Collection superClses = selectedCls.getDirectSuperclasses();
		Iterator it = superClses.iterator();
		while(it.hasNext()){
			Cls superCls = (Cls)it.next();
			String superClsName = this.mangle(superCls.getBrowserText());
			sb.append("<noinclude>{{LexWiki Parent|" + superClsName + "}}</noinclude>\n");
		}
		return sb.toString();
	}
		
	private String getPreferredNameTemplate(String code, String clsName, String ns){
		StringBuffer sb = new StringBuffer();
		int nameLen = clsName.length();
		int codeLen = code.length();
		int index = nameLen-codeLen-2;
		int nsLen = ns.length()+1;
		String name = clsName.substring(nsLen, index);
		String mangledName = this.mangle(name);
		sb.append("{{LexWiki Preferred Name|" + mangledName + "}}\n");
		
		return sb.toString();
	}
	
	private String getConceptCodeTemplate(String code){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki Concept Code|" + code + "}}\n");
		
		return sb.toString();		
	}
	
	private String getCodingSchemeTemplate(String codingScheme){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki inScheme|" + codingScheme + "}}\n");
		
		return sb.toString();		
	}
	
	private String getURITemplate(String codingScheme, String code){
		StringBuffer sb = new StringBuffer();
		sb.append("{{LexWiki URI|" + codingScheme + ":" + code + "}}\n");
		
		return sb.toString();				
	}

	private String getConceptPropertyInclusionTemplate(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Has_Inclusion" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
	}
	
	private String getConceptPropertyCodeFirstTemplate(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Code_First" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
	}	

	private String getConceptPropertyCodeAlsoTemplate(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Code_Also" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
	}		
	private String getConceptPropertyIncludesTemplate(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Includes" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
			
	}
	
	private String getConceptPropertyExcludesTemplate(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Excludes" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
			
	}
	
	private String getConceptPropertyExcludes1Template(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Excludes1" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
			
	}
	
	private String getConceptPropertyExcludes2Template(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
		    sb.append("{{LexWiki Concept Property|" + ns + "_Excludes2" + "|" + this.mangle(content) + "}}\n");
		}
		
		return sb.toString();				
			
	}
	
	private String getAssociationExcludesTemplate(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
			Collection codes = this.getCodesFromExcludes(content);
			for(Iterator it1 = codes.iterator(); it1.hasNext();){
				String code = (String) it1.next();
				String name = "";
				if(allCodeNames.containsKey(code)){
					name = (String)allCodeNames.get(code);
				}else{
					//take original content
					name = content;
				}
			    sb.append("{{LexWiki Association|" + ns + "_Excludes" + "|" + this.mangle(name) + "}}\n");
			}
			
		}
		
		return sb.toString();				
			
	}
	
	private String getAssociationExcludes1Template(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
			Collection codes = this.getCodesFromExcludes(content);
			for(Iterator it1 = codes.iterator(); it1.hasNext();){
				String code = (String) it1.next();
				String name = "";
				if(allCodeNames.containsKey(code)){
					name = (String)allCodeNames.get(code);
				}else{
					//take original content
					name = content;
				}
			    sb.append("{{LexWiki Association|" + ns + "_Excludes1" + "|" + this.mangle(name) + "}}\n");
			}
			
		}
		
		return sb.toString();				
			
	}
	
	private String getAssociationExcludes2Template(Collection contents, String ns){
		StringBuffer sb = new StringBuffer();
		for(Iterator it = contents.iterator(); it.hasNext();){
			String content = (String)it.next();
			Collection codes = this.getCodesFromExcludes(content);
			for(Iterator it1 = codes.iterator(); it1.hasNext();){
				String code = (String) it1.next();
				String name = "";
				if(allCodeNames.containsKey(code)){
					name = (String)allCodeNames.get(code);
				}else{
					//take original content
					name = content;
				}
			    sb.append("{{LexWiki Association|" + ns + "_Excludes2" + "|" + this.mangle(name) + "}}\n");
			}
			
		}
		
		return sb.toString();				
			
	}	
	private Collection getCodesFromExcludes(String content){
		Collection colCodes = new ArrayList();
		int index1 = content.indexOf("(");
		int index2 = content.indexOf(")");
		String strContent = content.substring(index1+1, index2);
		String [] strCodes = strContent.split(",");
		for(int i = 0; i < strCodes.length; i++){
			String strCode = strCodes[i];
			if(strCode.endsWith(".-")){
				strCode = strCode.substring(0, strCode.length()-2);
				colCodes.add(strCode);
			}else if(strCode.endsWith("-") || strCode.endsWith("_")){
				strCode = strCode.substring(0, strCode.length()-1);
				colCodes.add(strCode);			    
			}else{
				//This needs further parsing
				colCodes.add(strCode);
			}
		}
		
		return colCodes;
	}
	
	/**
	 * Mangle a name according to the LexWiki mangling rules
	 */
	public String mangle(String lwn) {
		// 1) Dashes, spaces and commas map to underscores
		lwn = lwn.replaceAll("[- ,]","_");

		// 2) Special characters map to nothing
		//lwn = lwn.replaceAll("[^a-zA-Z0-9_]", "");

		// 3) Remove leading and trailing "_"
		lwn = lwn.trim().replaceAll("^_+","").replaceAll("_+$", "");
		
		// 4) Adjacent underscores map to a single underscore
		return lwn.replaceAll("__+", "_");
	}

	
	
	private String getDefaultForm() {
		return "<noinclude>[[has default form::Form:LexWiki ICD10 Form]]</noinclude>\n";
	}

	private String getHeaderBasicData() {
		return "<noinclude>{{LexWiki Basic Data Header}}</noinclude>\n";
	}
	private String getTrailerBasicData() {
		return "<noinclude>{{LexWiki Basic Data Trailer}}</noinclude>\n";
	}
	private String getHeaderProperties() {
		return "<noinclude>{{LexWiki Concept Property Header}}</noinclude>\n";
	}
	private String getTrailerProperties() {
		return "<noinclude>{{LexWiki Concept Property Trailer}}</noinclude>\n";
	}
	private String getHeaderAssoications() {
		return "<noinclude>{{LexWiki Association Header}}</noinclude>\n";
	}
	private String getTrailerAssoications() {
		return "<noinclude>{{LexWiki Association Trailer}}</noinclude>\n";
	}
	
	private String getHeaderReferences() {
		return "<noinclude>{{LexWiki Reference Header}}</noinclude>\n";
	}
	private String getTrailerReferences() {
		return "<noinclude>{{LexWiki Reference Trailer}}</noinclude>\n";
	}	
	private String getHeaderAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Header}}</noinclude>\n";
	}
	private String getTrailerAssociationsGraph() {
		return "<noinclude>{{LexWiki Association Graph Trailer}}</noinclude>\n";
	}

}
